#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
root <- normalizePath(if (file.exists("DESCRIPTION")) "." else "..")
cores <- if (length(args) >= 1L) as.integer(args[[1L]]) else 1L
stage <- if (length(args) >= 2L) args[[2L]] else "all"
execute <- length(args) >= 3L && identical(args[[3L]], "--execute")
source(file.path(root, "reproducibility", "run_canonical_recomputation.R"))
plan <- run_canonical_recomputation(root, cores, stage, execute)
if (!execute) {
  print(plan, row.names = FALSE)
  cat("Dry run only. See docs/CANONICAL_RECOMPUTATION_PLAN.md before execution.\n")
}
