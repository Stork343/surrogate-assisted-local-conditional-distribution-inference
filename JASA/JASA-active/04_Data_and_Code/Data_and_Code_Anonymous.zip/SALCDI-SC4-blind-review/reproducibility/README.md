# Reproducibility package

This folder contains the audit bundle for the full computational project to reproduce
the formal tables and figures for review.

## 1) 目标文件和结果映射

- 全量模拟与主配置：`simulation/config/scenario_manifest.csv`（共 119 行配置）
- seed 注册表：`reproducibility/seed_registry.csv`
- LaTeX 表 1–4：`simulation/output/tables/*.tex`
- 表 5–6：`analysis/output/public_application/tables/table_epa_primary.csv`、
  `analysis/output/vitaldb_application/tables/table_vitaldb_primary.csv`
- AI 表 7：`simulation/ai_expert/results/summaries/ai_table3_blockA.csv`
- 配对 Monte Carlo 不确定性表 8：由三项应用的 replicate-level 结果生成
- 机器可读结果：`reproducibility/machine_tables/*.csv`（见下）
- 阈值级分布恢复扩展：`reproducibility/distribution_recovery/`，包括预设规格、
  500 次定向重计算、固定 mask 曲线、置信带、QC 与 SHA-256 清单

## 2) 机器可读表映射

- 主张映射：`reproducibility/claim_object_map.csv`
- 统一来源注册：`reproducibility/result_registry.R`
- 模拟表生成脚本：`simulation/summarize/make_tables.R`
- 主文证据与矢量图生成脚本：`reproducibility/build_manuscript_evidence.R`
- 冻结结果验证与 SHA-256 清单：`reproducibility/validate_frozen_results.R`

生成后目录：
- `reproducibility/machine_tables/table1_oracle_mechanism.csv`
- `reproducibility/machine_tables/table2_feasible.csv`
- `reproducibility/machine_tables/table3_scarcity.csv`
- `reproducibility/machine_tables/table4_bands.csv`
- `reproducibility/machine_tables/table5_epa_primary.csv`
- `reproducibility/machine_tables/table6_vitaldb_primary.csv`
- `reproducibility/machine_tables/table7_ai_primary.csv`
- `reproducibility/machine_tables/table8_paired_uncertainty.csv`
- `reproducibility/machine_tables/table9_simulation_headline.csv`
- `reproducibility/machine_tables/table10_application_primary.csv`
- `reproducibility/machine_tables/figure2_transfer_geometry.csv`
- `reproducibility/machine_tables/figure2_vanishing_curvature.csv`
- `reproducibility/machine_tables/figure_scarcity_scaling.csv`
- `reproducibility/machine_tables/figure_band_diagnostics.csv`
- `reproducibility/machine_tables/band_coverage_mcse.csv`
- `reproducibility/machine_tables/band_presubmission_diagnostic.csv` (created by
  `simulation/run/07a_band_presubmission_diagnostic.R` before the final band
  construction is frozen)
- `reproducibility/machine_tables/band_studentized_sensitivity.csv` (created by
  `simulation/run/07b_band_studentized_sensitivity.R` under the pre-specified
  sensitivity plan)
- `reproducibility/machine_tables/band_local_information_diagnostic.csv` and
  `band_coverage_by_minimum_fold.csv` (created from the final 24 frozen band
  objects by `reproducibility/summarize_band_local_information.R`)
- `reproducibility/machine_tables/figure3_application_frontiers.csv`
- `reproducibility/machine_tables/hypothesis_audit.csv`
- `reproducibility/machine_tables/ai_blockA.csv`
- `reproducibility/machine_tables/ai_blockB.csv`
- `reproducibility/machine_tables/ai_equivalent_fraction.csv`
- `reproducibility/machine_tables/ai_band_diagnostics.csv`
- `reproducibility/machine_tables/ai_model_sensitivity.csv`
- `reproducibility/machine_tables/ai_api_call_manifest.csv` 与
  `ai_api_call_manifest_summary.csv`（6,000 个主调用的请求—响应映射）
- `reproducibility/machine_tables/ai_response_cache_manifest.csv` 与
  `ai_response_cache_manifest_summary.csv`（全部缓存响应校验和）

## 3) 运行命令（用于打包时复现）

从已冻结的机器表和阈值级证据一次性重建主文四幅图、两张主表和两张 Supplement 表：

```sh
bash reproducibility/rebuild_submission_artifacts.sh
```

该入口只重建展示层 artifact，不重跑 Monte Carlo 实验或重新估计模型。
图形环境锁定在 `reproducibility/requirements-figures.txt`。
Figure 3 的 Evidence Visualization 交付包位于
`reproducibility/visualization/figure3_scarcity_inference/`，包括冻结结果
manifest、figure spec、caption、alt text、统计与生产审计以及 artifact
manifest；其中源驱动审计由
`python3 reproducibility/build_figure3_visualization_audit.py .` 重建。
完整原始结果汇总与验证入口如下：

```sh
Rscript reproducibility/run_correspondence_gate.R .
Rscript reproducibility/run_canonical_recomputation.R . 4 all
Rscript reproducibility/distribution_recovery/build_distribution_recovery_evidence.R --root=. --simulation-reps=500 --cores=4
Rscript reproducibility/distribution_recovery/build_revised_headline_tables.R --root=.
python reproducibility/generate_submission_figures.py
```

核心工作流主入口：`Rscript reproduce.R`。默认只打印规范重算计划；执行
必须显式提供 `--execute` 和确认环境变量，详见
`docs/CANONICAL_RECOMPUTATION_PLAN.md`。
EPA 主流程：`Rscript analysis/04_public_application.R --reps=500 --cores=4`  
VitalDB 下载与分析：见 `analysis/README.md` 中的两步流程。

统计模拟和冻结 AI 结果体积较大，不在普通 Git checkout 中重复分发。
`pre_fix_frozen_result_manifest.csv` 仅记录失效审计快照。规范重算完成后，
验证脚本从统一 registry 生成新的 `canonical_result_registry.csv` 和
`frozen_result_manifest.csv`。

## 4) 代码与脚本范围（全量 R/Python）

- Simulation 函数：`simulation/R/*.R`
- Simulation 主运行脚本：`simulation/run/*.R`、`analysis/01-03_simulation_*.R`
- AI 实验：`simulation/ai_expert/R/*.R`，`simulation/ai_expert/run/*.R`，
- EPA：`analysis/04_public_application.R` 与 `analysis/public_application_helpers.R`
- EPA fixed-mask diagnostics：
  `Rscript reproducibility/rebuild_epa_fixed_diagnostics.R .`
- VitalDB：`analysis/05_third_party_application.R` 与
  `analysis/vitaldb_application_helpers.R`
- 外部数据抓取 Python：`scripts/audit_vitaldb_oximetry.py`

## 5) AI 试验审计

- Prompt：`simulation/ai_expert/prompts/*.txt`
- Rubric：`simulation/ai_expert/prompts/rubric_primary.txt`
- 模型标识与 API 设置：`simulation/ai_expert/config/api_config.yml`
- 缓存输出：`simulation/ai_expert/cache/deepseek/responses.csv` +
  `simulation/ai_expert/cache/deepseek/*.json`
- 6,000 个主调用的请求与响应校验映射：
  `reproducibility/machine_tables/ai_api_call_manifest.csv`
- 14,576 个主调用与敏感性响应文件的校验和清单：
  `reproducibility/machine_tables/ai_response_cache_manifest.csv`
- 从冻结 dossier、score CSV 和缓存重建并验证该映射：
  `Rscript reproducibility/build_ai_call_manifest.R .`
- 三个永久失败由 call manifest、最终 score CSV 与
  `AI_FAILURE_LOG.md` 共同记录；原始失败 payload 未保留。
- API 可见证据、受保护 truth 和 dossier-only JSONL 分别位于
  `corpus/evidence/`、`corpus/truth/` 和 `corpus/frozen_cases/`；
  `corpus/dossier_manifest.csv` 与 `corpus/truth/truth_manifest.csv`
  分别记录 API 可见材料和受保护 truth 的 SHA-256。
- 控制失败日志：`simulation/ai_expert/audit/AI_FAILURE_LOG.md`
- 实验日志：`simulation/ai_expert/audit/AI_EXPERIMENT_LOG.md`

## 6) 参考掩码与三路折叠

- 参见 `reproducibility/reference_mask_split_map.md`
- VitalDB 的三路折叠函数：`analysis/vitaldb_application_helpers.R` 中的
  `vitaldb_balanced_folds()`
- 参考掩码构建与嵌套性检测也在同文件中（`draw_vitaldb_reference_mask`,
  `vitaldb_masks_are_nested`）。

## 7) 依赖快照

- `R` 会话信息：`reproducibility/session_info.txt`（由 `capture_environment.R` 生成）
- R 包列表：`reproducibility/r_package_inventory.csv`
- 说明文件：`reproducibility/dependency_inventory.md`

## 8) 数据不可直接公开时

当原始数据受限时，请按以下方式共享：
- 公共 EPA：由 `analysis/public_application_helpers.R` 下载并校验官方公开 ZIP（未直接分发）
- VitalDB：由 `scripts/audit_vitaldb_oximetry.py` 下载并生成受控衍生输出，详见
  `data-raw/README.md` 与 `data-raw/vitaldb/README.md`

## 9) 投稿归档

- 匿名评审包：`bash reproducibility/build_blind_review_bundle.sh`。该包使用
  严格 allowlist，仅包含盲审 PDF、补充材料、统计源码和机器可读证据，
  并执行身份与私有路径扫描。
- 完整投稿归档：`bash reproducibility/build_full_submission_archive.sh`。该包
  为非匿名内部冻结，保留受保护 expert outcomes、模型响应缓存和大型结果
  对象；生成的 ZIP 及 SHA sidecar 故意不纳入 Git。
- 两个构建器均在包内记录 `SOURCE_REVISION.txt`，并生成文件级
  `MANIFEST_SHA256.txt`。
