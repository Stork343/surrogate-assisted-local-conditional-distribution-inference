#!/usr/bin/env Rscript

run_correspondence_gate <- function(root = ".", write_report = TRUE) {
  root <- normalizePath(root)
  r_files <- list.files(root, pattern = "[.][Rr]$", recursive = TRUE,
                        full.names = TRUE)
  parse_errors <- character()
  for (path in r_files) {
    tryCatch(parse(path), error = function(error) {
      parse_errors <<- c(parse_errors, paste(path, conditionMessage(error)))
    })
  }
  if (length(parse_errors)) {
    stop("R parse failures: ", paste(parse_errors, collapse = "; "),
         call. = FALSE)
  }

  pkgload::load_all(root, quiet = TRUE)
  source(file.path(root, "simulation", "config", "simulation_constants.R"))
  source_simulation_environment(root)
  qc <- run_qc(root)
  if (!isTRUE(qc$pass)) stop("Shared semantic QC failed.", call. = FALSE)
  testthat::test_dir(
    file.path(root, "tests", "testthat"), reporter = "silent",
    stop_on_failure = TRUE, load_package = "none"
  )

  claim_env <- new.env(parent = globalenv())
  sys.source(file.path(root, "reproducibility", "audit_claim_object_map.R"),
             envir = claim_env)
  claim_map <- claim_env$audit_claim_object_map(root)
  pre_fix_guard <- file.exists(file.path(
    root, "reproducibility", "PRE_FIX_RESULTS_INVALID"
  ))
  canonical_ready <- file.exists(file.path(
    root, "reproducibility", "CANONICAL_RESULTS_READY"
  ))
  if (identical(pre_fix_guard, canonical_ready)) {
    stop("Exactly one result-state marker must be active: the pre-fix guard ",
         "or canonical-results-ready.", call. = FALSE)
  }
  retired_paths <- c(
    file.path(root, "simulation", "summarize", "make_all_outputs.R"),
    file.path(root, "reproducibility", "export_table_results.R")
  )
  retired <- vapply(retired_paths, function(path) {
    paste(readLines(path, warn = FALSE), collapse = "\n")
  }, character(1L))
  if (!all(grepl("is retired", retired, fixed = TRUE))) {
    stop("The duplicate result-generation entry point is still active.",
         call. = FALSE)
  }

  gate <- data.frame(
    gate_id = sprintf("G%02d", seq_len(15L)),
    condition = c(
      "verification_rate_calibration", "bounded_overlap",
      "three_role_disjointness", "complete_evaluation_coverage",
      "fold_estimator_identity", "candidate_path_identity",
      "transfer_identity", "unique_scenario_rng", "discrete_oracle_truth",
      "increasing_rearrangement", "strict_left_inverse",
      "fold_specific_bootstrap", "single_result_source",
      "claim_object_traceability", "api_failure_retry_archive"
    ),
    status = "PASS",
    evidence = c(
      "qc13 + simulation correspondence tests",
      "calibrated-intensity tests",
      "canonical-process tests", "canonical-process tests",
      "canonical-process fold identity", "candidate-path tests",
      "truth-engine transfer identity", "scenario RNG tests",
      "discrete Monte Carlo correspondence", "quantile tests",
      "quantile tests", "multiplier influence tests",
      "versioned selector + unified registry tests",
      paste0(nrow(claim_map), " claim families mapped"),
      "mock invalid-response retry/archive tests"
    ),
    stringsAsFactors = FALSE
  )
  if (isTRUE(write_report)) {
    write.csv(gate, file.path(root, "reproducibility",
                              "correspondence_gate_report.csv"),
              row.names = FALSE)
  }
  invisible(gate)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  root <- if (length(args)) args[[1L]] else "."
  gate <- run_correspondence_gate(root, write_report = TRUE)
  state <- if (file.exists(file.path(
    root, "reproducibility", "CANONICAL_RESULTS_READY"
  ))) "canonical results ready" else "canonical recomputation may begin"
  cat("Correspondence gate passed: ", nrow(gate), " of ", nrow(gate),
      " conditions; ", state, ".\n", sep = "")
}
