#!/usr/bin/env python3
"""Build the source-driven audit, caption, and alt text for main-text Figure 3."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path

import pandas as pd


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sanitize_json_paths(path: Path, project_root: Path) -> None:
    """Replace machine-specific project prefixes in a JSON deliverable."""
    if not path.is_file():
        return
    payload = json.loads(path.read_text(encoding="utf-8"))
    prefix = str(project_root)

    def clean(value):
        if isinstance(value, dict):
            return {key: clean(child) for key, child in value.items()}
        if isinstance(value, list):
            return [clean(child) for child in value]
        if isinstance(value, str):
            return value.replace(prefix + "/", "./").replace(prefix, ".")
        return value

    path.write_text(json.dumps(clean(payload), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def build(project_root: Path) -> None:
    project_root = project_root.resolve()
    package = project_root / "reproducibility/visualization/figure3_scarcity_inference"
    scarcity_path = project_root / "reproducibility/machine_tables/figure_scarcity_scaling.csv"
    band_path = project_root / "reproducibility/machine_tables/figure_band_diagnostics.csv"
    scarcity = pd.read_csv(scarcity_path)
    band = pd.read_csv(band_path)

    require(len(scarcity) == 32, "Figure 3(a) must contain 32 scenario-method rows")
    require(
        not scarcity.duplicated(["scenario_id", "method"]).any(),
        "Figure 3(a) scenario-method keys must be unique",
    )
    method_counts = scarcity.groupby("scenario_id")["method"].nunique()
    require((method_counts == 2).all(), "Every Figure 3(a) scenario must pair Anchor and Adaptive")
    require(set(scarcity["method"]) == {"Anchor", "Adaptive"}, "Unexpected Figure 3(a) method")
    require(len(band) == 24, "Figure 3(b) must contain 24 registered cells")
    require(not band["scenario_id"].duplicated().any(), "Figure 3(b) scenario IDs must be unique")
    require((band["band_replications"] == 1000).all(), "Band cells must use 1,000 replications")
    require((band["nominal_coverage"] == 0.95).all(), "Band nominal coverage must be 0.95")

    scaling = scarcity.groupby(["local_information_rate_index", "method"], sort=True)["scaled_ise"]
    scaling_means = scaling.mean().unstack("method")
    scaling_ranges = scaling.agg(["min", "max"]).reset_index()
    coverage = band["simultaneous_coverage.Adaptive"]
    coverage_mcse = band["coverage_mcse.Adaptive"]
    low_cells = band.loc[
        coverage < 0.93,
        [
            "scenario_id",
            "local_information_rate_index",
            "verification",
            "condition",
            "simultaneous_coverage.Adaptive",
            "coverage_mcse.Adaptive",
        ],
    ]

    source_records = [
        {
            "id": "scarcity_cells",
            "path": "reproducibility/machine_tables/figure_scarcity_scaling.csv",
            "sha256": sha256(scarcity_path),
            "rows": int(len(scarcity)),
            "primary_keys": ["scenario_id", "method"],
        },
        {
            "id": "band_cells",
            "path": "reproducibility/machine_tables/figure_band_diagnostics.csv",
            "sha256": sha256(band_path),
            "rows": int(len(band)),
            "primary_keys": ["scenario_id"],
        },
    ]
    annotations = {
        "coverage_range": {
            "minimum": float(coverage.min()),
            "maximum": float(coverage.max()),
        },
        "coverage_mcse_range": {
            "minimum": float(coverage_mcse.min()),
            "maximum": float(coverage_mcse.max()),
        },
        "low_coverage_count": int((coverage < 0.93).sum()),
        "low_coverage_threshold": 0.93,
        "nominal_coverage": 0.95,
        "band_replications": int(band["band_replications"].iloc[0]),
        "multiplier_draws": 4999,
        "scarcity_rows": int(len(scarcity)),
        "scarcity_scenarios": int(scarcity["scenario_id"].nunique()),
        "band_cells": int(len(band)),
        "scaling_regime_lower_bound": 30,
        "scaling_means": {
            str(index): {method: float(value) for method, value in row.items()}
            for index, row in scaling_means.iterrows()
        },
        "scaling_ranges": scaling_ranges.to_dict(orient="records"),
        "low_coverage_cells": low_cells.to_dict(orient="records"),
    }
    audit = {
        "status": "pass",
        "figure_id": "figure3_scarcity_inference",
        "source_records": source_records,
        "statistical_unit": {
            "panel_a": "registered scarcity-scenario method mean over 1,000 replications",
            "panel_b": "registered band-scenario summary over 1,000 replications",
        },
        "pairing": {
            "panel_a": "Anchor and Adaptive are paired by scenario_id",
            "panel_b": "one row per registered scenario_id",
        },
        "uncertainty_semantics": {
            "panel_a": "setting-level spread; not an uncertainty interval",
            "panel_b": "binomial Monte Carlo standard error of empirical 95% simultaneous-band coverage",
        },
        "computed_annotations": annotations,
        "renderer": {
            "backend": "python-matplotlib",
            "command_backend": "python-matplotlib",
            "command": "python3 reproducibility/generate_submission_figures.py",
            "python": sys.version,
            "platform": platform.platform(),
        },
        "checks": {
            "source_rows_complete": True,
            "primary_keys_unique": True,
            "scenario_pairing_complete": True,
            "coverage_cells_complete": True,
            "nominal_coverage_consistent": True,
            "replication_count_consistent": True,
            "values_recomputed_from_frozen_sources": True,
        },
    }

    caption = (
        "Risk scaling and raw-process simultaneous inference for the kernel-localized target "
        "$F_{h,0}$ under scarce reference outcomes. In panel (a), each thin vertical segment "
        "joins the Anchor and Adaptive mean scaled ISE from the same registered scarcity "
        "scenario; the large points and lines are unweighted cell means at each nominal rate "
        "index. Each scenario uses 1,000 replications, and the shaded region marks the reported "
        "scaling regime $Mp_Mh\\geq30$; the spread across scenarios is not an uncertainty "
        "interval. Panel (b) reports Adaptive empirical coverage of the 95% raw-process "
        "simultaneous band over 1,000 replications and 4999 multiplier draws per replication. "
        "Cell color is centered at 0.95, and outlined bold cells are below 0.93; binomial Monte "
        f"Carlo standard errors range from {coverage_mcse.min():.4f} to {coverage_mcse.max():.4f}. "
        "Supplementary Table S4 gives Anchor coverage and integrated widths, and Table S5 gives "
        "the corresponding local-support diagnostic."
    )
    alt_text = (
        "Two-panel simulation figure on scarce reference outcomes. Panel (a) plots scaled "
        "integrated squared error against the nominal local-information rate index from 7.5 to "
        "480. Thin vertical segments pair Anchor and Adaptive within each registered scenario; "
        "large mean profiles show Adaptive below Anchor at every displayed rate index. A shaded "
        "region begins at rate index 30. Panel (b) is a four-by-six heatmap of Adaptive 95% "
        "simultaneous-band coverage. Columns cross rate indices 30, 60, and 120 with random and "
        "selective verification; rows are strong, moderate, weak, and local-reversal surrogate "
        f"conditions. Coverage ranges from {coverage.min():.3f} to {coverage.max():.3f}; "
        f"{int((coverage < 0.93).sum())} cells below 0.93 are outlined, all in the rate-30 "
        "stress-test columns."
    )

    package.mkdir(parents=True, exist_ok=True)
    (package / "figure_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    (package / "caption.txt").write_text(caption + "\n", encoding="utf-8")
    (package / "alt_text.txt").write_text(alt_text + "\n", encoding="utf-8")
    (package / "caption_alt_text.json").write_text(
        json.dumps(
            {
                "figure_id": "figure3_scarcity_inference",
                "caption": caption,
                "alt_text": alt_text,
                "computed_from": [record["sha256"] for record in source_records],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    for audit_path in sorted((package / "audits").glob("*.json")):
        sanitize_json_paths(audit_path, project_root)
    sanitize_json_paths(package / "figure_manifest.json", project_root)
    print(json.dumps({"status": "pass", "package": str(package)}, indent=2))


if __name__ == "__main__":
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    build(root)
