#!/usr/bin/env Rscript

# Rebuild the two main-manuscript tables from frozen machine-readable evidence.
# This presentation-only entry point does not rerun an estimator.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) normalizePath(args[[1L]]) else normalizePath(".")
machine_dir <- file.path(root, "reproducibility", "machine_tables")
table_dir <- file.path(root, "paper", "tables")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

require_columns <- function(data, columns, source) {
  missing <- setdiff(columns, names(data))
  if (length(missing)) {
    stop(source, " is missing columns: ", paste(missing, collapse = ", "),
         call. = FALSE)
  }
}

write_booktabs_table <- function(path, caption, label, headers, rows,
                                 alignment, note) {
  lines <- c(
    "\\begin{table}[H]", "\\centering", "\\small",
    "\\setlength{\\tabcolsep}{3.5pt}",
    paste0("\\caption{", caption, "}"),
    paste0("\\label{", label, "}"),
    "\\resizebox{\\textwidth}{!}{%",
    paste0("\\begin{tabular}{", alignment, "}"), "\\toprule",
    paste0(paste(headers, collapse = " & "), " \\\\"), "\\midrule",
    paste0(apply(rows, 1L, paste, collapse = " & "), " \\\\"),
    "\\bottomrule", "\\end{tabular}%", "}", "\\vspace{2pt}",
    paste0("\\parbox{0.98\\textwidth}{\\footnotesize ", note, "}"),
    "\\end{table}"
  )
  writeLines(lines, path, useBytes = TRUE)
}

write_application_table <- function(path, caption, label, headers, rows,
                                    alignment, note) {
  lines <- c(
    "\\begin{table}[!t]", "\\centering", "\\footnotesize",
    "\\setlength{\\tabcolsep}{2.5pt}",
    paste0("\\caption{", caption, "}"),
    paste0("\\label{", label, "}"),
    paste0("\\begin{tabular}{", alignment, "}"), "\\toprule",
    paste0(paste(headers, collapse = " & "), " \\\\"), "\\midrule",
    paste0(apply(rows, 1L, paste, collapse = " & "), " \\\\"),
    "\\bottomrule", "\\end{tabular}", "\\vspace{2pt}",
    paste0("\\parbox{0.98\\textwidth}{\\footnotesize ", note, "}"),
    "\\end{table}"
  )
  writeLines(lines, path, useBytes = TRUE)
}

simulation_path <- file.path(machine_dir, "table9_simulation_headline.csv")
simulation <- read.csv(
  simulation_path, stringsAsFactors = FALSE, check.names = FALSE
)
require_columns(
  simulation,
  c(
    "contrast", "setting", "ise.X_anchor", "ise.Full", "ise.Adaptive",
    "relative_gain_percent", "lambda_hat", "negative_transfer.Adaptive",
    "negative_transfer.Full", "row_order"
  ),
  simulation_path
)
if (nrow(simulation) != 9L) {
  stop("Expected 9 main simulation rows; found ", nrow(simulation), ".",
       call. = FALSE)
}
simulation <- simulation[order(simulation$row_order), ]
contrast_display <- ifelse(
  duplicated(simulation$contrast), "", simulation$contrast
)
simulation_rows <- cbind(
  contrast_display,
  simulation$setting,
  formatC(1000 * simulation$ise.X_anchor, digits = 1L, format = "f"),
  formatC(1000 * simulation$ise.Full, digits = 1L, format = "f"),
  formatC(1000 * simulation$ise.Adaptive, digits = 1L, format = "f"),
  formatC(simulation$relative_gain_percent, digits = 1L, format = "f"),
  formatC(simulation$lambda_hat, digits = 3L, format = "f"),
  formatC(simulation$negative_transfer.Adaptive, digits = 3L, format = "f"),
  formatC(simulation$negative_transfer.Full, digits = 3L, format = "f")
)
write_booktabs_table(
  file.path(table_dir, "table_simulation_headline.tex"),
  "Finite-sample performance in the main simulation comparisons. ISE values are multiplied by $10^3$.",
  "tab:simulation-headline",
  c(
    "Contrast", "Setting", "Anchor", "Full", "Adaptive", "Gain (\\%)",
    "$E(\\widehat\\lambda_h)$", "NT Adaptive", "NT Full"
  ),
  simulation_rows,
  "llrrrrrrr",
  paste(
    "Gain is the percentage reduction in mean ISE from the anchor. Full uses",
    "borrowing weight one. NT is the frequency with which a method has larger",
    "ISE than the anchor in the same replication. N5 is the local-reversal setting."
  )
)

application_path <- file.path(machine_dir, "table10_application_primary.csv")
application <- read.csv(
  application_path, stringsAsFactors = FALSE, check.names = FALSE
)
require_columns(
  application,
  c(
    "application", "target", "p", "benchmark", "anchor_ise", "full_ise",
    "mean_ise", "mean_lambda", "risk_ratio", "risk_ratio_low",
    "risk_ratio_high"
  ),
  application_path
)
if (nrow(application) != 9L) {
  stop("Expected 9 main application rows; found ", nrow(application), ".",
       call. = FALSE)
}
expected_benchmark <- ifelse(
  application$application == "AI",
  "F_h0_frozen_population",
  "F_h_emp_complete_data"
)
if (!identical(application$benchmark, expected_benchmark)) {
  stop("Application benchmark labels do not match the frozen study roles.",
       call. = FALSE)
}
study_order <- match(application$application, c("EPA", "VitalDB", "AI"))
target_order <- match(
  application$target,
  c("30\\% RH", "50\\% RH", "70\\% RH", "30 min", "75 min", "180 min",
    "random review")
)
application <- application[order(study_order, target_order, application$p), ]
study_display <- ifelse(
  duplicated(application$application), "", application$application
)
ratio <- paste0(
  formatC(application$risk_ratio, digits = 3L, format = "f"), " [",
  formatC(application$risk_ratio_low, digits = 3L, format = "f"), ", ",
  formatC(application$risk_ratio_high, digits = 3L, format = "f"), "]"
)
application_rows <- cbind(
  study_display,
  ifelse(application$target == "random review", "Random review",
         application$target),
  paste0(formatC(100 * application$p, digits = 1L, format = "f"), "\\%"),
  formatC(1000 * application$anchor_ise, digits = 3L, format = "f"),
  formatC(1000 * application$full_ise, digits = 3L, format = "f"),
  formatC(1000 * application$mean_ise, digits = 3L, format = "f"),
  formatC(application$mean_lambda, digits = 3L, format = "f"),
  ratio
)
write_application_table(
  file.path(table_dir, "table_application_primary.tex"),
  paste(
    "Primary results under controlled reference sampling. EPA and VitalDB use",
    "their localized complete-data empirical benchmarks; AI uses its",
    "population benchmark."
  ),
  "tab:application-primary",
  c(
    "Study", "Target", "Ref. frac.", "Anchor", "Full", "Adaptive",
    "Mean wt.", "Adaptive/Anchor [95\\% MC]"
  ),
  application_rows,
  "llrrrrrl",
  paste(
    "ISE values are multiplied by $10^3$. Risk-ratio intervals use common",
    "reference samples and quantify Monte Carlo variation conditional on the",
    "stated study-specific benchmark; they are not population-sampling confidence intervals."
  )
)

cat("Rebuilt two main tables from frozen machine-readable evidence.\n")
