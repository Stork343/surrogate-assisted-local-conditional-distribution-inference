#!/usr/bin/env Rscript

# Rebuild the three fixed-mask EPA cluster-multiplier diagnostics from the
# frozen canonical application object. This does not rerun the 500-mask study.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) normalizePath(args[[1L]]) else normalizePath(".")
invisible(lapply(
  list.files(file.path(root, "R"), pattern = "[.]R$", full.names = TRUE),
  source
))
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
source(file.path(root, "analysis", "public_application_helpers.R"))

object_path <- file.path(
  root, "analysis", "output", "public_application",
  "epa_public_application.rds"
)
epa <- readRDS(object_path)
targets <- c(-1, 0, 1)
methods <- c("X_anchor", "Adaptive")
rows <- list()
counter <- 0L
for (target_index in seq_along(targets)) {
  x0 <- targets[[target_index]]
  fit <- fit_one_epa_mask(
    epa$data, epa$tau, x0, epa$h,
    p = 0.10, design = "random", replicate = 1L,
    seed_base = epa$seed_base, return_u = TRUE
  )
  for (method in methods) {
    band <- cluster_multiplier_band(
      fit$influence[[method]], fit$estimates[[method]],
      epa$data, epa$h, fit$pi,
      n_boot = 999L,
      seed = epa$seed_base + target_index + match(method, methods)
    )
    cover <- fit$truth >= band$low & fit$truth <= band$high
    counter <- counter + 1L
    rows[[counter]] <- data.frame(
      x0 = x0,
      rh_target = 50 + 20 * x0,
      method = method,
      simultaneous_coverage = all(cover),
      pointwise_coverage = mean(cover),
      integrated_band_width = band$integrated_width,
      critical_value = band$critical_value,
      clusters = band$clusters,
      lambda_hat = fit$lambda_hat,
      full_transfer_signal = fit$full_transfer_signal,
      stringsAsFactors = FALSE
    )
  }
}
output <- do.call(rbind, rows)
output_path <- file.path(
  root, "analysis", "output", "public_application", "example_bands.csv"
)
write.csv(output, output_path, row.names = FALSE)
machine_path <- file.path(
  root, "reproducibility", "machine_tables",
  "epa_fixed_band_diagnostics.csv"
)
write.csv(output, machine_path, row.names = FALSE)

wide <- reshape(
  output[, c("rh_target", "method", "integrated_band_width")],
  idvar = "rh_target", timevar = "method", direction = "wide"
)
reduction <- 100 * (
  1 - wide$integrated_band_width.Adaptive /
    wide$integrated_band_width.X_anchor
)
if (!all(output$simultaneous_coverage[output$method == "Adaptive"]) ||
    min(reduction) < 18.5 || max(reduction) > 30) {
  stop("EPA fixed-mask diagnostic no longer matches its manuscript range.",
       call. = FALSE)
}
cat(
  "Rebuilt EPA fixed-mask diagnostics; Adaptive width reductions:",
  paste(formatC(reduction, digits = 4L, format = "f"), collapse = ", "),
  "percent; machine table:", machine_path, "\n"
)
