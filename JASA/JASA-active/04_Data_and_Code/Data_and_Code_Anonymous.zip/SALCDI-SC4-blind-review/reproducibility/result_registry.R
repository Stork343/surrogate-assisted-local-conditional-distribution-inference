# Unified selector and provenance registry for formal numerical evidence.

registry_sha256 <- function(path) {
  if (!file.exists(path)) stop("Missing result object: ", path, call. = FALSE)
  digest::digest(file = path, algo = "sha256")
}

registry_relative_path <- function(path, root) {
  root_lexical <- path.expand(as.character(root))
  if (!grepl("^/", root_lexical)) {
    root_lexical <- file.path(getwd(), root_lexical)
  }
  root_resolved <- normalizePath(root, winslash = "/", mustWork = TRUE)
  path <- gsub("\\\\", "/", as.character(path))
  path <- gsub("/+", "/", path)
  roots <- unique(gsub("/+", "/", c(root_lexical, root_resolved)))
  roots <- sub("/$", "", roots)
  for (candidate in roots) {
    prefix <- paste0(candidate, "/")
    if (startsWith(path, prefix)) {
      return(substring(path, nchar(prefix) + 1L))
    }
  }
  stop("Result path is not lexically contained in the project root: ", path,
       call. = FALSE)
}

registry_implementation_version <- function(root = ".") {
  constants <- new.env(parent = globalenv())
  sys.source(file.path(root, "simulation", "config", "simulation_constants.R"),
             envir = constants)
  constants$simulation_implementation_version
}

validate_ai_final_object <- function(path, scenario_id, expected_masks,
                                     implementation_version) {
  object <- tryCatch(readRDS(path), error = function(e) NULL)
  required <- c("implementation_version", "scenario_id", "seed")
  if (!is.data.frame(object) || !all(required %in% names(object))) {
    stop("AI object `", basename(path),
         "` lacks canonical provenance fields.", call. = FALSE)
  }
  if (!identical(unique(object$implementation_version),
                 implementation_version)) {
    stop("AI object `", basename(path), "` has an obsolete implementation ",
         "version.", call. = FALSE)
  }
  if (!identical(unique(as.character(object$scenario_id)), scenario_id)) {
    stop("AI scenario identifier mismatch in `", basename(path), "`.",
         call. = FALSE)
  }
  if (length(unique(object$seed)) != expected_masks) {
    stop("AI object `", basename(path), "` does not contain exactly ",
         expected_masks, " mask streams.", call. = FALSE)
  }
  invisible(object)
}

select_ai_final_result_files <- function(root = ".", validate_objects = TRUE,
                                         expected_masks = 2000L) {
  manifest_path <- file.path(root, "simulation", "ai_expert", "config",
                             "ai_scenarios.csv")
  result_dir <- file.path(root, "simulation", "ai_expert", "results", "raw")
  if (!file.exists(manifest_path) || !dir.exists(result_dir)) {
    stop("AI scenario manifest or raw-result directory is missing.",
         call. = FALSE)
  }
  manifest <- read.csv(manifest_path, stringsAsFactors = FALSE)
  manifest <- manifest[manifest$block %in% c("A", "B"), , drop = FALSE]
  implementation_version <- registry_implementation_version(root)
  rows <- lapply(seq_len(nrow(manifest)), function(i) {
    id <- manifest$scenario_id[[i]]
    expected_name <- paste0(id, "_mask", expected_masks, ".rds")
    path <- file.path(result_dir, expected_name)
    if (!file.exists(path)) {
      stop("Missing final AI object `", expected_name, "`.", call. = FALSE)
    }
    if (isTRUE(validate_objects)) {
      validate_ai_final_object(
        path, id, expected_masks, implementation_version
      )
    }
    data.frame(
      artifact_id = paste0("ai:", id), artifact_type = "ai_downstream",
      scenario_id = id, expected_replications = expected_masks,
      implementation_version = implementation_version, path = path,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

select_ai_band_result_files <- function(root = ".", validate_objects = TRUE,
                                        expected_masks = 500L) {
  result_dir <- file.path(root, "simulation", "ai_expert", "results", "raw")
  ids <- c(
    "AIBAND_V1_p0.10_raw", "AIBAND_V1_p0.05_raw",
    "AIBAND_V5_p0.10_raw", "AIBAND_V4_p0.10_raw",
    "AIBAND_V1_p0.10_AI4", "AIBAND_V1_p0.10_AI8"
  )
  implementation_version <- registry_implementation_version(root)
  rows <- lapply(ids, function(id) {
    path <- file.path(result_dir, paste0(id, "_bands", expected_masks, ".rds"))
    if (!file.exists(path)) {
      stop("Missing final AI band object `", basename(path), "`.",
           call. = FALSE)
    }
    if (isTRUE(validate_objects)) {
      validate_ai_final_object(
        path, id, expected_masks, implementation_version
      )
    }
    data.frame(
      artifact_id = paste0("ai_band:", id), artifact_type = "ai_band",
      scenario_id = id, expected_replications = expected_masks,
      implementation_version = implementation_version, path = path,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

validate_application_object <- function(path, application,
                                        expected_metric_rows,
                                        expected_replications,
                                        implementation_version) {
  object <- tryCatch(readRDS(path), error = function(e) NULL)
  if (!is.list(object) ||
      !identical(object$implementation_version, implementation_version) ||
      !is.data.frame(object$metrics)) {
    stop(application, " application object has obsolete or missing canonical ",
         "provenance.", call. = FALSE)
  }
  metrics <- object$metrics
  if (!"implementation_version" %in% names(metrics) ||
      !identical(unique(metrics$implementation_version),
                 implementation_version)) {
    stop(application, " metrics lack the canonical implementation version.",
         call. = FALSE)
  }
  if (nrow(metrics) != expected_metric_rows ||
      length(unique(metrics$replicate)) != expected_replications) {
    stop(application, " application object has the wrong formal run size.",
         call. = FALSE)
  }
  invisible(object)
}

select_application_result_files <- function(root = ".",
                                            validate_objects = TRUE) {
  implementation_version <- registry_implementation_version(root)
  specs <- data.frame(
    application = c("EPA", "VitalDB"),
    artifact_id = c("application:epa", "application:vitaldb"),
    path = c(
      file.path(root, "analysis", "output", "public_application",
                "epa_public_application.rds"),
      file.path(root, "analysis", "output", "vitaldb_application",
                "vitaldb_application.rds")
    ),
    expected_metric_rows = c(36000L, 48000L),
    expected_replications = c(500L, 500L),
    stringsAsFactors = FALSE
  )
  rows <- lapply(seq_len(nrow(specs)), function(i) {
    path <- specs$path[[i]]
    if (!file.exists(path)) {
      stop("Missing final ", specs$application[[i]], " application object.",
           call. = FALSE)
    }
    if (isTRUE(validate_objects)) {
      validate_application_object(
        path, specs$application[[i]], specs$expected_metric_rows[[i]],
        specs$expected_replications[[i]], implementation_version
      )
    }
    data.frame(
      artifact_id = specs$artifact_id[[i]],
      artifact_type = "application", scenario_id = specs$application[[i]],
      expected_replications = specs$expected_replications[[i]],
      implementation_version = implementation_version, path = path,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

build_canonical_result_registry <- function(root = ".",
                                            validate_objects = TRUE) {
  selector_path <- file.path(root, "simulation", "summarize",
                             "result_selector.R")
  selector <- new.env(parent = environment())
  sys.source(selector_path, envir = selector)
  simulation <- selector$select_final_result_files(root, validate_objects)
  simulation_rows <- simulation$registry
  simulation_rows$artifact_id <- paste0("simulation:",
                                        simulation_rows$scenario_id)
  simulation_rows$artifact_type <- ifelse(
    simulation_rows$module == "bands", "simulation_band", "simulation"
  )
  simulation_rows <- simulation_rows[, c(
    "artifact_id", "artifact_type", "scenario_id", "replications",
    "implementation_version", "path"
  )]
  names(simulation_rows)[4L] <- "expected_replications"
  ai_rows <- select_ai_final_result_files(root, validate_objects)
  ai_band_rows <- select_ai_band_result_files(root, validate_objects)
  application_rows <- select_application_result_files(root, validate_objects)
  registry <- rbind(simulation_rows, ai_rows, ai_band_rows, application_rows)
  registry$bytes <- unname(file.info(registry$path)$size)
  registry$sha256 <- vapply(registry$path, registry_sha256, character(1L))
  registry$path <- vapply(
    registry$path, registry_relative_path, character(1L), root = root
  )
  registry <- registry[order(registry$artifact_type, registry$artifact_id), ]
  rownames(registry) <- NULL
  registry
}

write_canonical_result_registry <- function(root = ".", output = NULL) {
  if (is.null(output)) {
    output <- file.path(root, "reproducibility",
                        "canonical_result_registry.csv")
  }
  registry <- build_canonical_result_registry(root, validate_objects = TRUE)
  write.csv(registry, output, row.names = FALSE)
  invisible(registry)
}
