#!/usr/bin/env python3
"""Generate publication-ready manuscript figures from frozen machine tables.

The script changes presentation only. It does not recompute estimators,
Monte Carlo experiments, application masks, or any canonical numerical result.
Outputs are written as vector PDF/SVG plus 360-dpi PNG previews.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable
import math
import os

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm, Normalize
from matplotlib.lines import Line2D
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd
from scipy.interpolate import LSQUnivariateSpline

# Stabilize PDF metadata timestamps and SVG element identifiers so that
# presentation-only regeneration is byte reproducible.
os.environ.setdefault("SOURCE_DATE_EPOCH", "1787356800")

ROOT = Path(__file__).resolve().parents[1]
TABLE_DIR = ROOT / "reproducibility" / "machine_tables"
RECOVERY_DIR = ROOT / "reproducibility" / "distribution_recovery" / "artifacts"
FIG_DIR = ROOT / "paper" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# A restrained, color-vision-deficiency-aware system tuned for white journal pages.
INK = "#20252B"
MUTED = "#626C78"
SOFT = "#8C98A6"
GRID = "#D9DEE5"
PANEL = "#F7F9FC"
WHITE = "#FFFFFF"
BLUE = "#2F6B9A"
INDIGO = "#6B66B3"
TEAL = "#2A7F79"
GREEN = "#2E8B57"
AMBER = "#B7791F"
ORANGE = "#C76E2B"
ROSE = "#D94B70"
SLATE = "#65758B"
PALE_BLUE = "#EAF2FF"
PALE_INDIGO = "#EEEDFF"
PALE_TEAL = "#E8F7F4"
PALE_AMBER = "#FFF5DF"
PALE_ROSE = "#FCECF1"
PALE_SLATE = "#EFF3F7"

mpl.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 8.0,
        "axes.titlesize": 9.1,
        "axes.labelsize": 8.2,
        "xtick.labelsize": 7.0,
        "ytick.labelsize": 7.0,
        "legend.fontsize": 6.9,
        "axes.linewidth": 0.65,
        "lines.linewidth": 1.25,
        "lines.markersize": 4.5,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 2.8,
        "ytick.major.size": 2.8,
        "mathtext.fontset": "stixsans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "svg.hashsalt": "salcdi-canonical-p0d-v2",
        "savefig.facecolor": WHITE,
        "figure.facecolor": WHITE,
        "axes.facecolor": WHITE,
    }
)


def read_table(name: str, required: Iterable[str]) -> pd.DataFrame:
    path = TABLE_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"Missing frozen machine table: {path}")
    df = pd.read_csv(path)
    missing = sorted(set(required) - set(df.columns))
    if missing:
        raise ValueError(f"{path.name} lacks columns: {', '.join(missing)}")
    return df


def save_figure(fig: plt.Figure, stem: str, *, opaque_png: bool = False) -> None:
    for ext in ("pdf", "svg"):
        output_path = FIG_DIR / f"{stem}.{ext}"
        fig.savefig(
            output_path,
            bbox_inches="tight",
            pad_inches=0.025,
            metadata={"Creator": "SALCDI reproducibility/generate_submission_figures.py"},
        )
        if ext == "svg":
            raw = output_path.read_text(encoding="utf-8")
            normalized = "\n".join(line.rstrip() for line in raw.splitlines()) + "\n"
            output_path.write_text(normalized, encoding="utf-8")
    png_path = FIG_DIR / f"{stem}.png"
    fig.savefig(
        png_path,
        dpi=360,
        bbox_inches="tight",
        pad_inches=0.025,
    )
    if opaque_png:
        from PIL import Image

        with Image.open(png_path) as image:
            image.convert("RGB").save(png_path, dpi=(360, 360))
    plt.close(fig)


def panel_label(ax: plt.Axes, label: str, x: float = -0.10, y: float = 1.045) -> None:
    ax.text(
        x,
        y,
        f"({label})",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=9.3,
        fontweight="bold",
        color=INK,
        clip_on=False,
    )


def clean_axis(ax: plt.Axes, grid_axis: str | None = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(SOFT)
    ax.spines["bottom"].set_color(SOFT)
    ax.tick_params(colors=INK)
    if grid_axis:
        ax.grid(axis=grid_axis, color=GRID, linewidth=0.55, zorder=0)
        ax.set_axisbelow(True)


def outlined_text(ax: plt.Axes, x: float, y: float, text: str, **kwargs) -> None:
    artist = ax.text(x, y, text, **kwargs)
    artist.set_path_effects([pe.withStroke(linewidth=2.6, foreground=WHITE)])


def rounded_rect(ax: plt.Axes, x: float, y: float, w: float, h: float,
                 face: str, edge: str, radius: float = 1.2, lw: float = 0.9,
                 zorder: int = 1) -> patches.FancyBboxPatch:
    patch = patches.FancyBboxPatch(
        (x, y), w, h,
        boxstyle=f"round,pad=0.015,rounding_size={radius}",
        facecolor=face, edgecolor=edge, linewidth=lw, zorder=zorder,
    )
    ax.add_patch(patch)
    return patch


METHOD_STYLE = {
    "X_anchor": {"color": SLATE, "linestyle": (0, (4, 2)), "label": "Anchor"},
    "Full": {"color": ORANGE, "linestyle": (0, (1.2, 1.5)), "label": "Full"},
    "Adaptive": {"color": TEAL, "linestyle": "solid", "label": "Adaptive"},
}

FIGURE1_PALE = {
    "X_anchor": "#CAD1DA",
    "Full": "#EBC9B3",
    "Adaptive": "#B8D9D5",
}
FIGURE1_PANELS = [
    ("aligned", "Aligned", r"$p_M=0.10$ · random · strong"),
    ("scarce_selective", "Scarce selective", r"$p_M=0.05$ · selective · moderate"),
    ("local_reversal", "Local reversal", r"$p_M=0.10$ · random · reversed"),
]
FIGURE1_RC = {
    "font.family": "DejaVu Sans",
    "font.size": 8.0,
    "axes.titlesize": 9.0,
    "axes.labelsize": 8.2,
    "xtick.labelsize": 7.1,
    "ytick.labelsize": 7.1,
    "legend.fontsize": 7.2,
    "svg.hashsalt": "salcdi-figure1-candidate-v1",
}


def read_recovery_table(name: str, required: Iterable[str]) -> pd.DataFrame:
    path = RECOVERY_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"Missing distribution-recovery artifact: {path}")
    df = pd.read_csv(path)
    missing = sorted(set(required) - set(df.columns))
    if missing:
        raise ValueError(f"{path.name} lacks columns: {', '.join(missing)}")
    return df


def arrow(ax: plt.Axes, xy1: tuple[float, float], xy2: tuple[float, float],
          color: str = MUTED, lw: float = 1.1, style: str = "-|>",
          connectionstyle: str = "arc3", dashed: bool = False,
          mutation_scale: float = 10) -> None:
    ax.add_patch(
        patches.FancyArrowPatch(
            xy1, xy2, arrowstyle=style, mutation_scale=mutation_scale,
            linewidth=lw, color=color, connectionstyle=connectionstyle,
            linestyle=(0, (3, 2)) if dashed else "solid", zorder=4,
        )
    )


def draw_database_icon(ax: plt.Axes, x: float, y: float, w: float, h: float,
                       edge: str, face: str) -> None:
    ax.add_patch(patches.Rectangle((x, y + 0.12*h), w, 0.76*h,
                                   facecolor=face, edgecolor=edge, linewidth=0.8, zorder=3))
    ax.add_patch(patches.Ellipse((x + w/2, y + 0.88*h), w, 0.24*h,
                                 facecolor=face, edgecolor=edge, linewidth=0.8, zorder=4))
    ax.add_patch(patches.Arc((x + w/2, y + 0.12*h), w, 0.24*h,
                             theta1=180, theta2=360, edgecolor=edge, linewidth=0.8, zorder=4))
    for frac in (0.36, 0.60):
        ax.plot([x, x+w], [y+frac*h, y+frac*h], color=edge, linewidth=0.55, zorder=4)


def draw_model_icon(ax: plt.Axes, x: float, y: float, color: str) -> None:
    pts1 = [(x, y+2.2), (x, y), (x, y-2.2)]
    pts2 = [(x+5.0, y+1.5), (x+5.0, y-1.5)]
    for p1 in pts1:
        for p2 in pts2:
            ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=color, alpha=0.45, linewidth=0.55, zorder=3)
    for px, py in pts1:
        ax.add_patch(patches.Circle((px, py), 0.55, facecolor=WHITE, edgecolor=color, linewidth=0.8, zorder=4))
    for px, py in pts2:
        ax.add_patch(patches.Circle((px, py), 0.65, facecolor=color, edgecolor=WHITE, linewidth=0.5, zorder=4))


def draw_gauge_icon(ax: plt.Axes, x: float, y: float, color: str) -> None:
    ax.add_patch(patches.Wedge((x, y), 3.2, 0, 180, width=0.7,
                               facecolor=PALE_SLATE, edgecolor=color, linewidth=0.75, zorder=3))
    theta = math.radians(52)
    ax.plot([x, x+2.35*math.cos(theta)], [y, y+2.35*math.sin(theta)],
            color=color, linewidth=1.2, zorder=4)
    ax.add_patch(patches.Circle((x, y), 0.45, facecolor=color, edgecolor=WHITE, linewidth=0.45, zorder=4))
    ax.text(x-2.9, y-0.8, "0", fontsize=5.8, color=MUTED, ha="center")
    ax.text(x+2.9, y-0.8, "1", fontsize=5.8, color=MUTED, ha="center")


def draw_cdf_icon(ax: plt.Axes, x: float, y: float, w: float, h: float,
                  color: str, band: bool = False) -> None:
    xs = np.linspace(0, 1, 60)
    ys = 1 / (1 + np.exp(-8*(xs-0.52)))
    if band:
        ax.fill_between(x + xs*w, y + (ys-0.09)*h, y + (ys+0.09)*h,
                        color=color, alpha=0.13, linewidth=0, zorder=2)
    ax.plot(x + xs*w, y + ys*h, color=color, linewidth=1.25, zorder=4)
    ax.plot([x, x], [y, y+h], color=SOFT, linewidth=0.5, zorder=2)
    ax.plot([x, x+w], [y, y], color=SOFT, linewidth=0.5, zorder=2)


def chip(ax: plt.Axes, x: float, y: float, text: str, face: str, edge: str,
         text_color: str = INK, fontsize: float = 6.8) -> None:
    ax.text(x, y, text, ha="center", va="center", fontsize=fontsize,
            color=text_color,
            bbox={"boxstyle": "round,pad=0.28,rounding_size=0.9",
                  "facecolor": face, "edgecolor": edge, "linewidth": 0.65},
            zorder=8)


def draw_method_overview() -> None:
    """Vector methodological overview with an ICML/NeurIPS-style modular layout."""
    fig = plt.figure(figsize=(7.18, 3.78))
    ax = fig.add_axes([0.012, 0.035, 0.976, 0.94])
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 56)
    ax.axis("off")

    # Three visual zones: observation/target, cross-fitting engine, inferential output.
    rounded_rect(ax, 0.5, 4.6, 18.0, 48.2, PANEL, GRID, radius=1.6, lw=0.75, zorder=0)
    rounded_rect(ax, 19.7, 4.6, 59.5, 48.2, "#FBFCFE", GRID, radius=1.6, lw=0.75, zorder=0)
    rounded_rect(ax, 80.5, 4.6, 19.0, 48.2, PANEL, GRID, radius=1.6, lw=0.75, zorder=0)

    headers = [
        (2.0, "Data + target", "two-phase outcomes", BLUE),
        (21.3, "Three-role cross-fitting", "fit  -  calibrate  -  evaluate", INDIGO),
        (82.0, "Distributional output", "shape-corrected inference", TEAL),
    ]
    for x, title, subtitle, color in headers:
        ax.plot([x, x + 4.2], [53.4, 53.4], color=color, linewidth=2.4,
                solid_capstyle="round")
        ax.text(x, 50.8, title, fontsize=8.2, fontweight="bold", color=INK, va="center")
        ax.text(x, 48.4, subtitle, fontsize=6.2, color=MUTED, va="center")

    # Observation block.
    draw_database_icon(ax, 2.8, 36.0, 4.5, 5.7, BLUE, PALE_BLUE)
    ax.text(8.6, 41.6, "Broad sample", fontsize=7.5, fontweight="bold", color=INK, va="top")
    ax.text(8.6, 38.9, r"$X_i,S_i,R_i$ for all units", fontsize=6.6, color=INK, va="top")
    ax.text(8.6, 36.4, r"$Y_i$ only if $R_i=1$", fontsize=6.6, color=INK, va="top")
    ax.text(8.6, 33.9, r"$\pi_i=P(R_i=1\mid W_i)$", fontsize=6.6, color=INK, va="top")

    rounded_rect(ax, 2.1, 21.2, 14.8, 9.7, PALE_INDIGO, INDIGO, radius=1.2, lw=0.8)
    ax.text(3.1, 28.8, "Localized estimand", fontsize=7.1, fontweight="bold", color=INDIGO, va="top")
    ax.text(3.1, 25.7, r"$F_0(y\mid x_0)$", fontsize=8.8, color=INK, va="top")
    ax.text(3.1, 22.8, r"weights $K_h(X_i-x_0)$", fontsize=6.5, color=MUTED, va="top")
    xx = np.linspace(-1, 1, 60)
    yy = np.exp(-3.0 * xx**2)
    ax.plot(11.1 + 4.4 * (xx + 1) / 2, 22.5 + 5.0 * yy, color=INDIGO, linewidth=1.1)
    ax.plot([13.3, 13.3], [22.0, 28.2], color=SOFT, linewidth=0.55, linestyle=(0, (2, 2)))
    ax.text(13.3, 21.6, r"$x_0$", fontsize=5.9, color=MUTED, ha="center", va="top")

    rounded_rect(ax, 2.1, 8.0, 14.8, 7.8, WHITE, "#B8CBED", radius=1.0, lw=0.65)
    ax.text(3.1, 13.8, "Role of the surrogate", fontsize=6.8, fontweight="bold", color=BLUE, va="top")
    ax.text(3.1, 10.9, "$Y$ defines the estimand.\n$S$ only improves precision.",
            fontsize=5.8, color=MUTED, va="top", linespacing=1.30)

    # Two compact chips reserve the top of the cross-fitting zone for the key invariants.
    chip(ax, 37.0, 45.2, r"one $\lambda$ shared over the threshold grid", PALE_BLUE, "#B9CCF2", BLUE, 6.1)
    chip(ax, 63.0, 45.2, r"transfer gate: $2G_h-H_h$", PALE_ROSE, "#E7A8B9", ROSE, 6.1)

    # Three role cards.
    card_specs = [
        (21.7, PALE_BLUE, BLUE, "1", "Fit threshold paths"),
        (41.2, PALE_AMBER, AMBER, "2", "Calibrate borrowing"),
        (60.7, PALE_TEAL, TEAL, "3", "Held-out evaluation"),
    ]
    for x, face, edge, num, title in card_specs:
        rounded_rect(ax, x, 18.2, 16.4, 24.1, face, edge, radius=1.35, lw=0.9)
        ax.add_patch(patches.Circle((x + 2.0, 39.1), 1.25, facecolor=WHITE,
                                    edgecolor=edge, linewidth=0.9, zorder=5))
        ax.text(x + 2.0, 39.1, num, fontsize=6.9, fontweight="bold", color=edge,
                ha="center", va="center", zorder=6)
        ax.text(x + 4.0, 39.1, title, fontsize=7.1, fontweight="bold", color=edge,
                va="center")

    # Role 1: two parallel threshold regressions.
    rounded_rect(ax, 23.1, 31.0, 13.6, 4.2, WHITE, "#B8CBED", radius=0.8, lw=0.6)
    ax.add_patch(patches.Circle((24.8, 33.1), 0.55, facecolor=BLUE, edgecolor=WHITE, linewidth=0.4, zorder=5))
    ax.text(26.0, 33.1, r"anchor  $\widehat q_y(X)$", fontsize=6.2, color=INK, va="center")
    rounded_rect(ax, 23.1, 25.5, 13.6, 4.2, WHITE, "#B8CBED", radius=0.8, lw=0.6)
    ax.add_patch(patches.Circle((24.8, 27.6), 0.55, facecolor=INDIGO, edgecolor=WHITE, linewidth=0.4, zorder=5))
    ax.text(26.0, 27.6, r"surrogate  $\widehat m_y(X,S)$", fontsize=6.2, color=INK, va="center")
    ax.text(29.9, 21.2, "role 1 only", fontsize=5.8, color=MUTED,
            ha="center", va="center")

    # Role 2: discrepancy -> gain/curvature -> clipped coefficient.
    rounded_rect(ax, 42.7, 30.0, 3.5, 4.8, WHITE, "#E9C477", radius=0.75, lw=0.6)
    ax.text(44.45, 32.4, r"$D_y$", fontsize=8.0, color=AMBER, fontweight="bold", ha="center", va="center")
    arrow(ax, (46.4, 32.4), (48.0, 32.4), AMBER, 0.85, mutation_scale=8)
    rounded_rect(ax, 48.2, 29.0, 4.7, 6.8, WHITE, "#E9C477", radius=0.75, lw=0.6)
    ax.text(50.55, 33.4, r"$\widehat G_h$", fontsize=6.5, color=INK, ha="center")
    ax.text(50.55, 30.7, r"$\widehat H_h$", fontsize=6.5, color=INK, ha="center")
    arrow(ax, (53.1, 32.4), (54.4, 32.4), AMBER, 0.85, mutation_scale=8)
    rounded_rect(ax, 54.6, 30.0, 2.4, 4.8, WHITE, "#E9C477", radius=0.75, lw=0.6)
    ax.text(55.8, 32.4, r"$\widehat\lambda_h$", fontsize=6.1, color=AMBER, fontweight="bold", ha="center", va="center")
    ax.text(49.4, 25.8, r"$\widehat\lambda_h=\Pi_{[0,1]}(\widehat G_h/\widehat H_h)$",
            fontsize=6.2, color=INK, ha="center")
    ax.text(49.4, 21.2, "role 2 only", fontsize=5.8, color=MUTED,
            ha="center", va="center")

    # Role 3: AIPW signal and weighted threshold process.
    rounded_rect(ax, 62.1, 31.0, 13.6, 4.2, WHITE, "#9FD8CF", radius=0.8, lw=0.6)
    ax.text(68.9, 33.1, r"$U_y(a)=a+\frac{R}{\pi}(Z_y-a)$", fontsize=6.2,
            color=INK, ha="center", va="center")
    draw_cdf_icon(ax, 63.4, 23.7, 10.9, 5.2, TEAL, band=False)
    ax.text(68.9, 21.2, r"role 3: form $\widehat F_{h,k}^{\rm raw}$", fontsize=5.8,
            color=MUTED, ha="center", va="center")

    # Arrows stay in the gutters.
    arrow(ax, (38.4, 30.2), (40.8, 30.2), BLUE, 1.05)
    arrow(ax, (57.9, 30.2), (60.3, 30.2), AMBER, 1.05)

    # Rotation and aggregation strip.
    rounded_rect(ax, 21.7, 7.0, 55.4, 7.6, PALE_SLATE, GRID, radius=1.1, lw=0.65)
    ax.text(23.4, 11.8, "Rotate roles", fontsize=6.7, fontweight="bold", color=SLATE, va="center")
    centers = [36.5, 45.8, 55.1]
    cols = [BLUE, AMBER, TEAL]
    for cx, num, col in zip(centers, ["1", "2", "3"], cols):
        ax.add_patch(patches.Circle((cx, 10.8), 1.65, facecolor=WHITE,
                                    edgecolor=col, linewidth=0.9, zorder=5))
        ax.text(cx, 10.8, num, fontsize=6.4, fontweight="bold", color=col,
                ha="center", va="center", zorder=6)
    arrow(ax, (38.4, 10.8), (43.7, 10.8), SLATE, 0.8, mutation_scale=7)
    arrow(ax, (47.7, 10.8), (53.0, 10.8), SLATE, 0.8, mutation_scale=7)
    arrow(ax, (56.9, 12.0), (34.7, 12.0), SLATE, 0.7,
          connectionstyle="arc3,rad=-0.22", dashed=True, mutation_scale=7)
    ax.text(69.8, 11.0, "average $K$ held-out processes", fontsize=5.9,
            color=MUTED, ha="center", va="center")

    # Output pipeline.
    stages = [
        (83.0, 39.2, "Average", r"$K$ raw processes"),
        (83.0, 31.3, "Rearrange", "monotone CDF"),
        (83.0, 23.4, "Bootstrap", "simultaneous band"),
    ]
    for idx, (x, y, title, subtitle) in enumerate(stages):
        rounded_rect(ax, x, y, 14.0, 5.3, WHITE, "#A8D7D1", radius=0.85, lw=0.65)
        ax.text(x + 1.1, y + 3.4, title, fontsize=6.6, fontweight="bold", color=TEAL, va="center")
        ax.text(x + 1.1, y + 1.5, subtitle, fontsize=5.8, color=MUTED, va="center")
        if idx < 2:
            arrow(ax, (90.0, y - 0.15), (90.0, y - 1.65), TEAL, 0.75, mutation_scale=7)
    draw_cdf_icon(ax, 83.3, 9.0, 13.2, 9.0, TEAL, band=True)
    ax.text(89.9, 6.7, r"$\widehat F_h^{\rm mon}$, bands, and $\widehat Q_h(\tau\mid x_0)$",
            fontsize=5.8, color=INK, ha="center", va="center")

    arrow(ax, (18.8, 29.8), (21.3, 29.8), BLUE, 1.1)
    arrow(ax, (77.4, 29.8), (80.1, 29.8), TEAL, 1.1)

    save_figure(fig, "figure1_method_overview")


def draw_distribution_recovery() -> None:
    with mpl.rc_context(FIGURE1_RC):
        _draw_distribution_recovery_accepted()


def _draw_distribution_recovery_accepted() -> None:
    data = read_recovery_table(
        "simulation_curve_summary.csv",
        [
            "panel_id", "scenario_id", "estimand", "threshold",
            "threshold_probability", "truth", "method", "mean_estimate",
            "pointwise_bias", "pointwise_rmse", "M", "p", "h",
            "verification_design", "surrogate_quality", "mean_lambda",
            "replications",
        ],
    ).copy()
    if (
        len(data) != 909
        or data.duplicated(["panel_id", "threshold", "method"]).any()
        or set(data["panel_id"]) != {item[0] for item in FIGURE1_PANELS}
        or set(data["method"]) != {"X_anchor", "Full", "Adaptive"}
        or not (data.groupby(["panel_id", "method"]).size() == 101).all()
        or set(data["replications"]) != {500}
        or set(data["estimand"]) != {"F_h"}
        or not np.allclose(data["h"], 0.30)
        or not np.allclose(
            data["pointwise_bias"],
            data["mean_estimate"] - data["truth"],
            atol=2e-15,
        )
        or not (
            data["pointwise_rmse"] + 1e-14
            >= data["pointwise_bias"].abs()
        ).all()
        or data["pointwise_bias"].abs().max() >= 0.01
        or data["pointwise_rmse"].max() >= 0.14
    ):
        raise ValueError("Figure 1 source does not match the accepted 909-row process contract.")

    def smooth_bias(values: pd.DataFrame) -> np.ndarray:
        bias = values["pointwise_bias"].to_numpy()
        variance = np.maximum(
            values["pointwise_rmse"].to_numpy() ** 2 - bias ** 2,
            1e-14,
        )
        mcse = np.sqrt(variance / values["replications"].to_numpy())
        threshold = values["threshold"].to_numpy()
        knots = np.quantile(threshold, np.linspace(0, 1, 7)[1:-1])
        return LSQUnivariateSpline(
            threshold, bias, t=knots, w=1 / mcse, k=3
        )(threshold)

    fig, axes = plt.subplots(
        2, 3, figsize=(7.18, 4.05), sharex="col",
        gridspec_kw={"height_ratios": [0.78, 1.18]},
    )
    fig.subplots_adjust(
        left=0.078, right=0.987, top=0.81, bottom=0.18,
        wspace=0.22, hspace=0.13,
    )

    for col, (panel_id, title, subtitle) in enumerate(FIGURE1_PANELS):
        panel = data[data["panel_id"] == panel_id].copy()
        ax_bias = axes[0, col]
        ax_rmse = axes[1, col]
        for method in ("X_anchor", "Full", "Adaptive"):
            style = METHOD_STYLE[method]
            values = panel[panel["method"] == method].sort_values("threshold")
            ax_bias.scatter(
                values["threshold"], 1000 * values["pointwise_bias"],
                s=5.0, marker="o", facecolor=FIGURE1_PALE[method],
                edgecolor="none", zorder=1,
            )
            ax_bias.plot(
                values["threshold"], 1000 * smooth_bias(values),
                color=style["color"], linestyle=style["linestyle"],
                linewidth=1.25, zorder=2,
            )
            ax_rmse.plot(
                values["threshold"], values["pointwise_rmse"],
                color=style["color"], linestyle=style["linestyle"],
                linewidth=1.25, zorder=2,
            )
        mean_lambda = float(panel["mean_lambda"].iloc[0])
        ax_bias.axhline(
            0, color=SOFT, linewidth=0.75, linestyle=(0, (3, 2)), zorder=1
        )
        ax_bias.set_ylim(-10, 10)
        ax_bias.set_yticks([-10, -5, 0, 5, 10])
        ax_rmse.set_ylim(0, 0.14)
        ax_rmse.set_yticks([0, 0.035, 0.070, 0.105, 0.140])
        ax_rmse.set_xticks([-1, 0, 1])
        ax_rmse.set_xlabel(r"threshold $y$")
        ax_bias.set_title(
            f"({chr(ord('a') + col)})  {title}", loc="left", pad=35,
            fontweight="bold",
        )
        ax_bias.text(
            0.0, 1.105, subtitle, transform=ax_bias.transAxes,
            ha="left", va="bottom", fontsize=6.3, color=MUTED,
        )
        ax_bias.text(
            0.98, 1.02, rf"mean $\widehat\lambda_h={mean_lambda:.3f}$",
            transform=ax_bias.transAxes, ha="right", va="bottom",
            fontsize=6.2, color=INK, clip_on=False,
        )
        if col == 0:
            ax_bias.set_ylabel(r"$10^3\times$ pointwise bias")
            ax_rmse.set_ylabel("pointwise RMSE")
        else:
            ax_bias.tick_params(labelleft=False)
            ax_rmse.tick_params(labelleft=False)
        clean_axis(ax_bias, grid_axis="y")
        clean_axis(ax_rmse, grid_axis="y")

    handles = [
        Line2D(
            [0], [0], color=METHOD_STYLE[method]["color"],
            linestyle=METHOD_STYLE[method]["linestyle"], linewidth=1.35,
            label=METHOD_STYLE[method]["label"],
        )
        for method in ("X_anchor", "Full", "Adaptive")
    ]
    fig.legend(
        handles=handles, frameon=False, ncol=3, loc="lower center",
        bbox_to_anchor=(0.5, 0.025), columnspacing=1.4,
        handlelength=2.5, handletextpad=0.55,
    )
    save_figure(fig, "figure1_distribution_recovery", opaque_png=True)


def draw_transfer_geometry() -> None:
    df = read_table(
        "figure2_transfer_geometry.csv",
        [
            "scenario_id", "row_id", "mechanism_label", "path_variant",
            "display_order", "verification", "transfer_signal", "realized_gain",
            "lambda_star", "lambda_hat", "lambda_q10", "lambda_q90",
            "lambda_replications",
        ],
    ).copy()
    expected_rows = ["M1", "M2", "M3", "M4", "M4_raw", "M5", "M6", "M7", "M8"]
    if (
        len(df) != 18
        or set(df["row_id"]) != set(expected_rows)
        or not (df.groupby("row_id").size() == 2).all()
        or not (df.groupby("row_id")["verification"].nunique() == 2).all()
        or set(df["display_order"]) != set(range(1, 10))
        or set(df["verification"]) != {"R1", "R2"}
    ):
        raise ValueError("Figure 2 must contain nine paired R1/R2 mechanism rows.")
    if (
        (df["lambda_q10"] > df["lambda_q90"]).any()
        or (df[["lambda_q10", "lambda_q90"]] < 0).any().any()
        or (df[["lambda_q10", "lambda_q90"]] > 1).any().any()
        or not (
            ((df["path_variant"] == "raw") &
             (df["lambda_replications"] == 1000)) |
            ((df["path_variant"] != "raw") &
             (df["lambda_replications"] == 2000))
        ).all()
    ):
        raise ValueError("Figure 2 borrowing ranges do not match the frozen replication design.")

    df["gain1000"] = 1000 * df["realized_gain"]
    row_metadata = (
        df[["row_id", "mechanism_label", "display_order"]]
        .drop_duplicates()
        .sort_values("display_order")
    )
    row_metadata["y"] = np.arange(len(row_metadata) - 1, -1, -1)
    y_map = dict(zip(row_metadata["row_id"], row_metadata["y"]))
    display_code = row_metadata["row_id"].replace({"M4_raw": "M4 raw"})
    row_metadata["display_label"] = (
        display_code + "  " + row_metadata["mechanism_label"]
    )

    fig, axes = plt.subplots(
        1, 3, figsize=(7.18, 3.65), sharey=True,
        gridspec_kw={"width_ratios": [1.0, 1.0, 1.18]},
    )
    ax_a, ax_b, ax_c = axes
    fig.subplots_adjust(
        left=0.255, right=0.985, top=0.78, bottom=0.20, wspace=0.25
    )

    design_style = {
        "R1": {"color": BLUE, "marker": "o", "offset": 0.12},
        "R2": {"color": ORANGE, "marker": "s", "offset": -0.12},
    }
    for ax in axes:
        clean_axis(ax, grid_axis="y")
        ax.set_ylim(-0.55, len(row_metadata) - 0.45)
        ax.set_yticks(row_metadata["y"])
        ax.set_yticklabels(row_metadata["display_label"])
    for ax in (ax_b, ax_c):
        ax.tick_params(axis="y", labelleft=False, length=0)

    profile_specs = [
        (ax_a, "transfer_signal", (-1.16, 0.94)),
        (ax_b, "gain1000", (-2.08, 1.58)),
    ]
    for ax, _, limits in profile_specs:
        ax.set_xlim(*limits)
        ax.axvspan(limits[0], 0, color=PALE_ROSE, alpha=0.48, zorder=-2)
        ax.axvspan(0, limits[1], color=PALE_TEAL, alpha=0.62, zorder=-2)
        ax.axvline(
            0, color=SOFT, linewidth=0.8, linestyle=(0, (3, 2)), zorder=1
        )

    for row_id, group in df.groupby("row_id", sort=False):
        base_y = y_map[row_id]
        for ax, value_name, _ in profile_specs:
            paired = []
            for _, row in group.sort_values("verification").iterrows():
                style = design_style[row["verification"]]
                paired.append((row[value_name], base_y + style["offset"]))
            ax.plot(
                [point[0] for point in paired],
                [point[1] for point in paired],
                color=SOFT, linewidth=0.55, alpha=0.72, zorder=1,
            )
            for _, row in group.iterrows():
                style = design_style[row["verification"]]
                ax.scatter(
                    row[value_name], base_y + style["offset"],
                    s=28, marker=style["marker"],
                    facecolor=style["color"], edgecolor=WHITE,
                    linewidth=0.55, zorder=3,
                )

    ax_c.set_xlim(-0.035, 1.035)
    ax_c.set_xticks([0, 0.25, 0.50, 0.75, 1.00])
    ax_c.grid(axis="x", color=GRID, linewidth=0.55, zorder=0)
    for row_id, group in df.groupby("row_id", sort=False):
        base_y = y_map[row_id]
        for _, row in group.iterrows():
            style = design_style[row["verification"]]
            y_value = base_y + style["offset"]
            ax_c.plot(
                [row["lambda_q10"], row["lambda_q90"]],
                [y_value, y_value], color=style["color"],
                linewidth=1.15, alpha=0.80, zorder=2,
            )
            ax_c.scatter(
                row["lambda_hat"], y_value,
                s=29, marker=style["marker"],
                facecolor=style["color"], edgecolor=WHITE,
                linewidth=0.55, zorder=4,
            )
            ax_c.plot(
                [row["lambda_star"], row["lambda_star"]],
                [y_value - 0.10, y_value + 0.10],
                color=INK, linewidth=1.15, zorder=5,
            )

    sign_agreement = (
        np.sign(df["transfer_signal"]) == np.sign(df["realized_gain"])
    )
    agreement_count = int(sign_agreement.sum())
    mae = float(np.mean(np.abs(df["lambda_hat"] - df["lambda_star"])))

    ax_a.set_title("(a)  Transfer criterion", loc="left", pad=10,
                   fontweight="bold")
    ax_b.set_title("(b)  Realized ISE gain", loc="left", pad=10,
                   fontweight="bold")
    ax_c.set_title("(c)  Borrowing-weight recovery", loc="left", pad=10,
                   fontweight="bold")
    ax_a.set_xlabel(r"$2G_h-H_h$")
    ax_b.set_xlabel(r"Anchor $-$ Full ISE ($\times10^3$)")
    ax_c.set_xlabel(r"borrowing weight $\lambda$")
    ax_a.text(
        0.02, 1.02, "avoid Full", transform=ax_a.transAxes,
        ha="left", va="bottom", fontsize=6.1, color=MUTED,
    )
    ax_a.text(
        0.98, 1.02, "favor Full", transform=ax_a.transAxes,
        ha="right", va="bottom", fontsize=6.1, color=TEAL,
    )
    ax_b.text(
        0.02, 1.02, "Full worse", transform=ax_b.transAxes,
        ha="left", va="bottom", fontsize=6.1, color=MUTED,
    )
    ax_b.text(
        0.98, 1.02, "Full better", transform=ax_b.transAxes,
        ha="right", va="bottom", fontsize=6.1, color=TEAL,
    )
    fig.text(
        0.49, 0.855,
        f"All {agreement_count} cells agree in sign",
        ha="center", va="bottom", fontsize=6.8,
        fontweight="bold", color=INK,
    )
    ax_c.text(
        0.98, 1.02, f"cell-mean MAE = {mae:.3f}",
        transform=ax_c.transAxes, ha="right", va="bottom",
        fontsize=6.2, fontweight="bold", color=INK,
    )

    handles = [
        Line2D(
            [0], [0], marker="o", color="none", markerfacecolor=BLUE,
            markeredgecolor=WHITE, markersize=5.0, label="R1 random",
        ),
        Line2D(
            [0], [0], marker="s", color="none", markerfacecolor=ORANGE,
            markeredgecolor=WHITE, markersize=5.0, label="R2 selective",
        ),
        Line2D(
            [0], [0], marker="|", color="none", markeredgecolor=INK,
            markersize=9.0, markeredgewidth=1.2,
            label=r"path-oracle $\lambda_h^{\rm or}$",
        ),
        Line2D(
            [0], [0], color=SOFT, linewidth=1.2,
            label="10\N{EN DASH}90% range of " + r"$\widehat\lambda_h$",
        ),
    ]
    fig.legend(
        handles=handles, frameon=False, ncol=4, loc="upper center",
        bbox_to_anchor=(0.61, 0.985), columnspacing=0.95,
        handlelength=1.8, handletextpad=0.4,
    )

    save_figure(fig, "figure2_transfer_geometry")


def draw_scarcity_inference() -> None:
    scaling = read_table(
        "figure_scarcity_scaling.csv",
        [
            "scenario_id", "M", "p", "local_information_rate_index",
            "method", "scaled_ise",
        ],
    ).copy()
    bands = read_table(
        "figure_band_diagnostics.csv",
        [
            "scenario_id", "verification", "condition",
            "condition_label", "coverage_column",
            "simultaneous_coverage.Adaptive", "coverage_mcse.Adaptive",
            "local_information_rate_index", "band_replications",
            "nominal_coverage", "below_0.93", "width_ratio",
        ],
    ).copy()

    if (
        len(scaling) != 32
        or scaling.duplicated(["scenario_id", "method"]).any()
        or set(scaling["method"]) != {"Anchor", "Adaptive"}
        or not (scaling.groupby("scenario_id")["method"].nunique() == 2).all()
    ):
        raise ValueError("Figure 3 risk source must contain 16 paired Anchor/Adaptive cells.")
    coverage_columns = ["30_R1", "30_R2", "60_R1", "60_R2", "120_R1", "120_R2"]
    condition_order = ["strong", "moderate", "weak", "locally_failed"]
    if (
        len(bands) != 24
        or bands["scenario_id"].duplicated().any()
        or set(bands["coverage_column"]) != set(coverage_columns)
        or set(bands["condition"]) != set(condition_order)
        or set(bands["band_replications"]) != {1000}
        or set(bands["nominal_coverage"]) != {0.95}
    ):
        raise ValueError("Figure 3 coverage source must contain the 24 registered band cells.")

    fig = plt.figure(figsize=(7.18, 3.35))
    gs = fig.add_gridspec(
        1, 2, width_ratios=[1.08, 1.34],
        left=0.09, right=0.985, top=0.82, bottom=0.21, wspace=0.34,
    )
    ax_a = fig.add_subplot(gs[0,0])
    ax_b = fig.add_subplot(gs[0,1])

    # A: paired registered cells and unweighted cell means over the ordered rate index.
    information_levels = sorted(scaling["local_information_rate_index"].unique())
    scenario_meta = scaling[
        ["scenario_id", "local_information_rate_index"]
    ].drop_duplicates()
    display_x = {}
    for information in information_levels:
        ids = sorted(
            scenario_meta.loc[
                scenario_meta["local_information_rate_index"] == information,
                "scenario_id",
            ]
        )
        offsets = np.linspace(-0.10, 0.10, len(ids)) if len(ids) > 1 else np.array([0.0])
        for scenario_id, offset in zip(ids, offsets):
            display_x[scenario_id] = information * (2.0 ** float(offset))
    for scenario_id, group in scaling.groupby("scenario_id", sort=False):
        pair = group.set_index("method")["scaled_ise"]
        x_value = display_x[scenario_id]
        ax_a.plot(
            [x_value, x_value], [pair["Adaptive"], pair["Anchor"]],
            color="#C5CFDB", linewidth=0.65, zorder=1,
        )
        ax_a.scatter(
            x_value, pair["Anchor"], s=15, marker="s", facecolor=SLATE,
            edgecolor=WHITE, linewidth=0.4, alpha=0.34, zorder=2,
        )
        ax_a.scatter(
            x_value, pair["Adaptive"], s=16, marker="o", facecolor=TEAL,
            edgecolor=WHITE, linewidth=0.4, alpha=0.34, zorder=2,
        )
    scaling_means = (
        scaling.groupby(["local_information_rate_index", "method"], as_index=False)
        ["scaled_ise"].mean()
    )
    method_styles = {
        "Anchor": {"color": SLATE, "marker": "s", "linestyle": (0, (4, 2))},
        "Adaptive": {"color": TEAL, "marker": "o", "linestyle": "solid"},
    }
    for method in ["Anchor", "Adaptive"]:
        values = scaling_means[
            scaling_means["method"] == method
        ].sort_values("local_information_rate_index")
        style = method_styles[method]
        ax_a.plot(
            values["local_information_rate_index"], values["scaled_ise"],
            color=style["color"], marker=style["marker"],
            linestyle=style["linestyle"], linewidth=1.35, markersize=5.1,
            markeredgecolor=WHITE, markeredgewidth=0.5, label=method, zorder=4,
        )
    ax_a.axvspan(30, 600, color=PALE_TEAL, alpha=0.35, zorder=-2)
    ax_a.axvline(30, color=SOFT, linewidth=0.75, linestyle=(0, (3, 2)), zorder=1)
    ax_a.set_xscale("log", base=2)
    ax_a.set_xticks(information_levels)
    ax_a.set_xticklabels([f"{value:g}" for value in information_levels])
    ax_a.set_xlim(6.3, 580)
    ax_a.set_ylim(0.23, 0.37)
    ax_a.set_yticks([0.24, 0.27, 0.30, 0.33, 0.36])
    ax_a.set_xlabel(r"nominal local-information rate index $Mp_Mh$")
    ax_a.set_ylabel(r"scaled ISE: $\mathrm{ISE}\times Mp_Mh$")
    ax_a.set_title("(a)  Scaled CDF risk", loc="left", pad=10,
                   fontweight="bold")
    ax_a.text(
        0.98, 0.97, r"reported regime: $Mp_Mh\geq30$",
        transform=ax_a.transAxes, ha="right", va="top",
        fontsize=6.1, color=TEAL,
    )
    ax_a.legend(frameon=False, ncol=2, loc="lower left",
                bbox_to_anchor=(0.0, 0.02), columnspacing=0.9,
                handlelength=1.7, handletextpad=0.4)
    clean_axis(ax_a, grid_axis="y")
    ax_a.grid(axis="x", color=GRID, linewidth=0.5, zorder=0)

    # B: Adaptive coverage over every verification-condition-information cell.
    cond_labels = ["Strong", "Moderate", "Weak", "Local reversal"]
    cols = [(30,"R1"),(30,"R2"),(60,"R1"),(60,"R2"),(120,"R1"),(120,"R2")]
    mat = np.full((len(condition_order), len(cols)), np.nan)
    below = np.zeros((len(condition_order), len(cols)), dtype=bool)
    for i, cond in enumerate(condition_order):
        for j, (eff, ver) in enumerate(cols):
            sub = bands[
                (bands["condition"] == cond)
                & (bands["local_information_rate_index"] == eff)
                & (bands["verification"] == ver)
            ]
            if not sub.empty:
                mat[i,j] = float(sub["simultaneous_coverage.Adaptive"].iloc[0])
                below[i,j] = mat[i,j] < 0.93
    cov_cmap = LinearSegmentedColormap.from_list(
        "coverage", ["#F2D7C9", WHITE, "#D9E8F2", BLUE]
    )
    norm = TwoSlopeNorm(vmin=0.900, vcenter=0.95, vmax=0.960)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            val = mat[i,j]
            ax_b.add_patch(
                patches.Rectangle(
                    (j - 0.5, i - 0.5), 1, 1,
                    facecolor=cov_cmap(norm(val)),
                    edgecolor=ORANGE if below[i,j] else WHITE,
                    linewidth=1.15 if below[i,j] else 0.5, zorder=1,
                )
            )
            ax_b.text(j, i, f"{val:.3f}", ha="center", va="center",
                      fontsize=6.1, color=INK,
                      fontweight="bold" if below[i,j] else "normal", zorder=2)
    ax_b.set_xlim(-0.5, mat.shape[1] - 0.5)
    ax_b.set_ylim(mat.shape[0] - 0.5, -0.5)
    ax_b.set_yticks(range(len(cond_labels))); ax_b.set_yticklabels(cond_labels)
    ax_b.set_xticks(range(len(cols)))
    verification_labels = {"R1": "R1\nrandom", "R2": "R2\nselective"}
    ax_b.set_xticklabels([verification_labels[ver] for _,ver in cols])
    ax_b.set_xlabel("verification design within nominal rate index")
    ax_b.set_title("(b)  Adaptive simultaneous coverage", loc="left", pad=24,
                   fontweight="bold")
    for center, label in [(0.5, "30 (stress)"), (2.5, "60"), (4.5, "120")]:
        ax_b.text(
            center, 1.025, rf"$Mp_Mh={label}$" if label.isdigit() else rf"$Mp_Mh=30$ (stress)",
            transform=ax_b.get_xaxis_transform(), ha="center", va="bottom",
            fontsize=6.2, color=INK, clip_on=False,
        )
    for k in [1.5,3.5]:
        ax_b.axvline(k, color=WHITE, linewidth=2.2)
    for spine in ax_b.spines.values(): spine.set_visible(False)
    ax_b.tick_params(length=0, colors=INK)

    save_figure(fig, "figure3_scarcity_inference", opaque_png=True)


def draw_application_evidence() -> None:
    curves = read_recovery_table(
        "application_curves.csv",
        [
            "study", "panel_id", "threshold", "truth", "method", "estimate",
            "lambda_hat", "benchmark",
        ],
    ).copy()
    bands = read_recovery_table(
        "application_bands.csv",
        [
            "panel_id", "threshold", "method", "band_low_display",
            "band_high_display", "simultaneous_containment",
        ],
    ).copy()
    panels = [
        ("epa_rh50", "EPA air sensors", "50% relative humidity",
         r"PM$_{2.5}$ threshold ($\mu$g/m$^3$)"),
        ("vitaldb_75min", "VitalDB oximetry", "75 minutes",
         r"SaO$_2$ threshold (%)"),
        ("ai_random10", "AI-assisted review", "10% random review",
         "expert-score threshold"),
    ]

    fig, axes = plt.subplots(1, 3, figsize=(7.18, 2.95), sharey=False)
    fig.subplots_adjust(left=0.075, right=0.985, top=0.82, bottom=0.25,
                        wspace=0.24)
    for col, (panel_id, title, subtitle, xlabel) in enumerate(panels):
        ax = axes[col]
        panel = curves[curves["panel_id"] == panel_id].copy()
        if panel.empty:
            raise ValueError(f"No application recovery rows for {panel_id}")
        truth = (
            panel[["threshold", "truth"]]
            .drop_duplicates()
            .sort_values("threshold")
        )
        adaptive_band = bands[
            (bands["panel_id"] == panel_id) & (bands["method"] == "Adaptive")
        ].sort_values("threshold")
        step_mode = "post" if panel_id == "vitaldb_75min" else None
        ax.fill_between(
            adaptive_band["threshold"], adaptive_band["band_low_display"],
            adaptive_band["band_high_display"], color=TEAL, alpha=0.14,
            linewidth=0, step=step_mode, zorder=1,
        )
        for method in ("X_anchor", "Full", "Adaptive"):
            style = METHOD_STYLE[method]
            values = panel[panel["method"] == method].sort_values("threshold")
            if step_mode:
                ax.step(
                    values["threshold"], values["estimate"], where="post",
                    color=style["color"], linestyle=style["linestyle"],
                    linewidth=1.25, zorder=2,
                )
            else:
                ax.plot(
                    values["threshold"], values["estimate"],
                    color=style["color"], linestyle=style["linestyle"],
                    linewidth=1.25, zorder=2,
                )
        if step_mode:
            ax.step(
                truth["threshold"], truth["truth"], where="post",
                color=INK, linewidth=1.55, zorder=3,
            )
        else:
            ax.plot(
                truth["threshold"], truth["truth"], color=INK,
                linewidth=1.55, zorder=3,
            )

        ax.set_title(title, loc="left", pad=13)
        ax.text(
            0.0, 1.025, subtitle, transform=ax.transAxes,
            ha="left", va="bottom", fontsize=6.2, color=MUTED,
        )
        if panel_id == "vitaldb_75min":
            ax.set_ylim(-0.01, 0.62)
            ax.set_yticks([0, 0.15, 0.30, 0.45, 0.60])
        else:
            ax.set_ylim(-0.02, 1.02)
            ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        ax.set_xlabel(xlabel)
        if col == 0:
            ax.set_ylabel("kernel-localized CDF")
        clean_axis(ax, grid_axis="y")
        panel_label(ax, chr(ord("a") + col), -0.12, 1.04)

    handles = [
        Line2D([0], [0], color=INK, linewidth=1.55, label="Benchmark")
    ] + [
        Line2D(
            [0], [0], color=METHOD_STYLE[method]["color"],
            linestyle=METHOD_STYLE[method]["linestyle"], linewidth=1.4,
            label=METHOD_STYLE[method]["label"],
        )
        for method in ("X_anchor", "Full", "Adaptive")
    ] + [
        patches.Patch(facecolor=TEAL, alpha=0.14, edgecolor="none",
                      label="Adaptive 95% band")
    ]
    fig.legend(
        handles=handles, frameon=False, ncol=5, loc="lower center",
        bbox_to_anchor=(0.5, 0.045), columnspacing=0.85, handlelength=2.1,
        handletextpad=0.4,
    )
    save_figure(fig, "figure4_application_evidence")


def main() -> None:
    draw_distribution_recovery()
    draw_transfer_geometry()
    draw_scarcity_inference()
    draw_application_evidence()
    print(f"Generated publication figures in {FIG_DIR}")


if __name__ == "__main__":
    main()
