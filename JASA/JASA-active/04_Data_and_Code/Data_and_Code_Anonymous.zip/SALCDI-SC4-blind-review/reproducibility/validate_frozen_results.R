#!/usr/bin/env Rscript

validate_canonical_results <- function(root = ".", allow_pending_marker = FALSE,
                                       write_manifests = TRUE) {
  root <- normalizePath(root)
  invalid_marker <- file.path(root, "reproducibility",
                              "PRE_FIX_RESULTS_INVALID")
  if (file.exists(invalid_marker) && !isTRUE(allow_pending_marker)) {
    stop(
      "Canonical results are not finalized while PRE_FIX_RESULTS_INVALID is ",
      "present. Use the explicit finalization audit only after all formal ",
      "objects have been recomputed.", call. = FALSE
    )
  }
  registry_env <- new.env(parent = globalenv())
  sys.source(file.path(root, "reproducibility", "result_registry.R"),
             envir = registry_env)
  registry <- registry_env$build_canonical_result_registry(
    root, validate_objects = TRUE
  )
  counts <- table(registry$artifact_type)
  expected <- c(
    simulation = 95L, simulation_band = 24L,
    ai_downstream = 115L, ai_band = 6L, application = 2L
  )
  observed <- setNames(integer(length(expected)), names(expected))
  observed[names(counts)] <- as.integer(counts)
  if (!identical(observed, expected)) {
    stop("Canonical result registry has unexpected artifact counts: ",
         paste(names(observed), observed, sep = "=", collapse = ", "),
         call. = FALSE)
  }
  if (anyDuplicated(registry$artifact_id) || anyDuplicated(registry$path)) {
    stop("Canonical result registry contains duplicate IDs or source paths.",
         call. = FALSE)
  }
  if (isTRUE(write_manifests)) {
    write.csv(
      registry,
      file.path(root, "reproducibility", "canonical_result_registry.csv"),
      row.names = FALSE
    )
    write.csv(
      registry[, c("path", "bytes", "sha256")],
      file.path(root, "reproducibility", "frozen_result_manifest.csv"),
      row.names = FALSE
    )
  }
  invisible(registry)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  root <- if (length(args)) args[[1L]] else "."
  allow <- identical(Sys.getenv("SALCDI_ALLOW_CANONICAL_FINALIZATION", "0"),
                     "1")
  registry <- validate_canonical_results(
    root, allow_pending_marker = allow, write_manifests = TRUE
  )
  cat("Validated", nrow(registry),
      "canonical simulation, AI, and application source objects.\n")
}
