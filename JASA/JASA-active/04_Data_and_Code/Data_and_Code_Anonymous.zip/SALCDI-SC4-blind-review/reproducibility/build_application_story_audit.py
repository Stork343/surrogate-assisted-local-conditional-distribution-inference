#!/usr/bin/env python3
"""Validate Section 5 application-story sources and rendered artifacts."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from pypdf import PdfReader


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def artifact_summary(root: Path, stem: str, width_mm: float, height_mm: float) -> list[dict]:
    summaries: list[dict] = []
    for suffix in ("pdf", "svg", "png", "tiff"):
        path = root / "paper" / "figures" / f"{stem}.{suffix}"
        require(path.is_file() and path.stat().st_size > 0, f"Missing {path}")
        item = {
            "path": str(path.relative_to(root)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
        if suffix == "pdf":
            reader = PdfReader(path)
            require(len(reader.pages) == 1, f"{stem}.pdf must have one page")
            box = reader.pages[0].mediabox
            item["page_width_mm"] = float(box.width) * 25.4 / 72
            item["page_height_mm"] = float(box.height) * 25.4 / 72
            require(abs(item["page_width_mm"] - width_mm) < 1.0, f"{stem} PDF width mismatch")
            require(abs(item["page_height_mm"] - height_mm) < 1.0, f"{stem} PDF height mismatch")
        if suffix in {"png", "tiff"}:
            with Image.open(path) as image:
                item["pixels"] = [image.width, image.height]
                item["mode"] = image.mode
                item["dpi"] = [float(v) for v in image.info.get("dpi", (0, 0))]
                require(image.width > 1000 and image.height > 500, f"{stem} raster too small")
                require(image.mode in {"RGB", "RGBA"}, f"{stem} unexpected raster mode")
        summaries.append(item)
    return summaries


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    data_dir = root / "reproducibility" / "application_story"
    audit_dir = root / "reproducibility" / "visualization" / "application_story_v2"
    audit_dir.mkdir(parents=True, exist_ok=True)

    manifest = pd.read_csv(data_dir / "artifact_manifest.csv")
    for row in manifest.itertuples(index=False):
        path = root / row.path
        require(path.is_file(), f"Manifest path missing: {row.path}")
        require(sha256(path) == row.sha256, f"Hash mismatch: {row.path}")
        require(len(pd.read_csv(path)) == int(row.rows), f"Row mismatch: {row.path}")

    epa_cal = pd.read_csv(data_dir / "epa_calibration_points.csv")
    epa_cdf = pd.read_csv(data_dir / "epa_complete_data_local_cdf.csv")
    epa_risk = pd.read_csv(data_dir / "epa_risk_frontier.csv")
    require(len(epa_cal) == 2814, "EPA observation count mismatch")
    require(epa_cdf.groupby("target_label").size().eq(101).all(), "EPA CDF grid mismatch")
    require(epa_cdf.groupby("target_label")["localized_cdf"].apply(
        lambda x: bool(np.all(np.diff(x) >= -1e-12))).all(), "EPA CDF not monotone")
    require(len(epa_risk) == 9 and (epa_risk.relative_risk_high < 1).all(),
            "EPA frontier mismatch")

    vital_pairs = pd.read_csv(data_dir / "vitaldb_pair_counts.csv")
    vital_cdf = pd.read_csv(data_dir / "vitaldb_complete_data_local_cdf.csv")
    vital_risk = pd.read_csv(data_dir / "vitaldb_risk_frontier.csv")
    require(int(vital_pairs["count"].sum()) == 3178, "VitalDB pair count mismatch")
    require(vital_cdf.groupby("target_label").size().eq(30).all(), "VitalDB CDF grid mismatch")
    require(vital_cdf.groupby("target_label")["localized_cdf"].apply(
        lambda x: bool(np.all(np.diff(x) >= -1e-12))).all(), "VitalDB CDF not monotone")
    require(len(vital_risk) == 12 and (vital_risk.relative_risk_high < 1).all(),
            "VitalDB frontier mismatch")

    ai_cal = pd.read_csv(data_dir / "ai_calibration_bins.csv")
    ai_cal_summary = pd.read_csv(data_dir / "ai_calibration_summary.csv")
    ai_error = pd.read_csv(data_dir / "ai_local_error_by_complexity.csv")
    ai_review = pd.read_csv(data_dir / "ai_review_designs_p010.csv")
    ai_reversal = pd.read_csv(data_dir / "ai_local_reversal_risk.csv")
    require(int(ai_cal["count"].sum()) == 2998, "AI valid-case count mismatch")
    require(len(ai_cal_summary) == 1, "AI calibration summary mismatch")
    require(len(ai_error) == 17 and ai_error.n.sum() == 2998, "AI error-bin mismatch")
    require(len(ai_review) == 5 and (ai_review.replications == 2000).all(),
            "AI review-design mismatch")
    require(len(ai_reversal) == 6 and (ai_reversal.replications == 2000).all(),
            "AI reversal mismatch")

    audits = {
        "figure4_epa_application": {
            "figure_id": "figure4_epa_application",
            "status": "pass",
            "source_rows": {"site_days": 2814, "cdf_values": 303, "risk_cells": 9},
            "computed": {
                "paired_log_correlation": float(epa_cal.reference_log_pm25.corr(
                    epa_cal.surrogate_log_pm25)),
                "relative_risk_range": [float(epa_risk.relative_risk.min()),
                                         float(epa_risk.relative_risk.max())],
                "all_interval_upper_below_one": bool((epa_risk.relative_risk_high < 1).all()),
            },
            "computed_annotations": {
                "site_days": 2814,
                "target_30": 30,
                "target_50": 50,
                "target_70": 70,
                "budget_5": 5,
                "budget_10": 10,
                "budget_20": 20,
                "replications": 500,
                "pm_subscript": 2.5,
            },
            "uncertainty": "paired 95% Monte Carlo intervals over 500 common reference masks",
            "artifacts": artifact_summary(root, "figure4_epa_application", 170, 77),
        },
        "figure5_vitaldb_application": {
            "figure_id": "figure5_vitaldb_application",
            "status": "pass",
            "source_rows": {"subject_pairs": 3178, "unique_pairs": len(vital_pairs),
                            "cdf_values": 90, "risk_cells": 12},
            "computed": {
                "sao2_mass_at_100": float(
                    vital_pairs.loc[vital_pairs.sao2 == 100, "count"].sum()
                    / vital_pairs["count"].sum()
                ),
                "relative_risk_range": [float(vital_risk.relative_risk.min()),
                                         float(vital_risk.relative_risk.max())],
                "all_interval_upper_below_one": bool((vital_risk.relative_risk_high < 1).all()),
            },
            "computed_annotations": {
                "subject_pairs": 3178,
                "target_30": 30,
                "target_75": 75,
                "target_180": 180,
                "threshold_min": 70,
                "threshold_max": 99,
                "budget_5": 5,
                "budget_10": 10,
                "budget_20": 20,
                "budget_40": 40,
                "replications": 500,
                "mass_location": 100,
            },
            "uncertainty": "paired 95% Monte Carlo intervals over 500 common reference masks",
            "artifacts": artifact_summary(root, "figure5_vitaldb_application", 170, 77),
        },
        "figure6_ai_review": {
            "figure_id": "figure6_ai_review",
            "status": "pass",
            "source_rows": {"valid_scores": 2998,
                            "calibration_grid_cells": len(ai_cal),
                            "complexity_bins": 17,
                            "review_designs": 5, "reversal_cells": 6},
            "computed": {
                "score_correlation": float(ai_cal_summary.score_correlation.iloc[0]),
                "maximum_absolute_binned_bias": float(ai_error.mean_bias.abs().max()),
                "review_design_relative_risk_range": [float(ai_review.relative_risk.min()),
                                                       float(ai_review.relative_risk.max())],
                "adaptive_reversal_relative_risk_range": [
                    float(ai_reversal.loc[ai_reversal.method == "Adaptive", "relative_risk"].min()),
                    float(ai_reversal.loc[ai_reversal.method == "Adaptive", "relative_risk"].max()),
                ],
                "full_reversal_relative_risk_range": [
                    float(ai_reversal.loc[ai_reversal.method == "Full", "relative_risk"].min()),
                    float(ai_reversal.loc[ai_reversal.method == "Full", "relative_risk"].max()),
                ],
            },
            "computed_annotations": {
                "valid_scores": 2998,
                "complexity_bins": 17,
                "lower_error_percentile": 10,
                "upper_error_percentile": 90,
                "review_fraction": 10,
                "replications": 2000,
                "full_risk_min": float(
                    ai_reversal.loc[ai_reversal.method == "Full", "relative_risk"].min()
                ),
                "full_risk_max": float(
                    ai_reversal.loc[ai_reversal.method == "Full", "relative_risk"].max()
                ),
            },
            "uncertainty": (
                "panel b uses empirical within-bin 10th--90th error ranges; "
                "panels c-d use paired 95% Monte Carlo intervals over 2,000 common masks"
            ),
            "artifacts": artifact_summary(root, "figure6_ai_review", 170, 119),
        },
    }

    created = datetime.now(timezone.utc).isoformat()
    for stem, audit in audits.items():
        audit["created_at"] = created
        path = audit_dir / f"{stem}_audit.json"
        path.write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n")

    summary = {
        "created_at": created,
        "status": "pass",
        "figures": {key: value["computed"] for key, value in audits.items()},
    }
    (audit_dir / "suite_audit.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
