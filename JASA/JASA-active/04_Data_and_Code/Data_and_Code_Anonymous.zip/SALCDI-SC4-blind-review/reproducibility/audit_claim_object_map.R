#!/usr/bin/env Rscript

audit_claim_object_map <- function(root = ".") {
  map_path <- file.path(root, "reproducibility", "claim_object_map.csv")
  stale_path <- file.path(root, "reproducibility", "stale_claim_patterns.txt")
  if (!file.exists(map_path) || !file.exists(stale_path)) {
    stop("Claim map or stale-pattern registry is missing.", call. = FALSE)
  }
  claim_map <- read.csv(map_path, stringsAsFactors = FALSE)
  required <- c("claim_id", "manuscript_file", "marker", "status",
                "source_family", "machine_table")
  if (!all(required %in% names(claim_map)) || anyDuplicated(claim_map$claim_id)) {
    stop("Claim-object map schema or claim IDs are invalid.", call. = FALSE)
  }
  allowed <- c("PENDING_RECOMPUTATION", "READY")
  if (any(!claim_map$status %in% allowed)) {
    stop("Claim-object map contains an unsupported status.", call. = FALSE)
  }

  mapped_paths <- unique(file.path(root, claim_map$manuscript_file))
  supplementary_path <- file.path(
    root, "supplement", "sections", "S9_additional_simulations.tex"
  )
  context_paths <- file.path(
    root, "paper", "sections",
    c("00_abstract.tex", "01_introduction.tex", "06_discussion.tex")
  )
  pending_paths <- unique(c(mapped_paths, supplementary_path))
  manuscript_paths <- unique(c(pending_paths, context_paths))
  if (!all(file.exists(manuscript_paths))) {
    stop("A mapped manuscript file is missing.", call. = FALSE)
  }
  manuscript <- setNames(
    lapply(manuscript_paths, function(path) paste(readLines(path, warn = FALSE),
                                                  collapse = "\n")),
    manuscript_paths
  )
  for (i in seq_len(nrow(claim_map))) {
    row <- claim_map[i, ]
    text <- manuscript[[file.path(root, row$manuscript_file)]]
    pending_marker <- paste0("% CLAIM_PENDING: ", row$marker)
    ready_marker <- paste0("% CLAIM_READY: ", row$marker)
    if (row$status == "PENDING_RECOMPUTATION") {
      if (!grepl(pending_marker, text, fixed = TRUE) ||
          grepl(ready_marker, text, fixed = TRUE)) {
        stop("Pending claim marker mismatch for ", row$claim_id, ".",
             call. = FALSE)
      }
    } else {
      if (!grepl(ready_marker, text, fixed = TRUE) ||
          grepl(pending_marker, text, fixed = TRUE)) {
        stop("Ready claim marker mismatch for ", row$claim_id, ".",
             call. = FALSE)
      }
      if (!file.exists(file.path(root, row$machine_table))) {
        stop("Ready claim lacks its machine table: ", row$claim_id, ".",
             call. = FALSE)
      }
    }
  }

  all_text <- paste(unlist(manuscript, use.names = FALSE), collapse = "\n")
  marker_hits <- regmatches(
    all_text,
    gregexpr("% CLAIM_(?:PENDING|READY): [A-Za-z0-9-]+", all_text,
             perl = TRUE)
  )[[1L]]
  marker_ids <- sub("^% CLAIM_(?:PENDING|READY): ", "", marker_hits,
                    perl = TRUE)
  if (!setequal(marker_ids, claim_map$marker)) {
    stop("Manuscript claim markers and claim-object map are not one-to-one.",
         call. = FALSE)
  }

  stale <- readLines(stale_path, warn = FALSE)
  stale <- stale[nzchar(stale)]
  hits <- stale[vapply(stale, grepl, logical(1L), x = all_text, fixed = TRUE)]
  if (length(hits)) {
    stop("Pre-fix numerical claim or artifact reference remains: ",
         paste(hits, collapse = ", "), call. = FALSE)
  }
  pending_visible <- vapply(manuscript[pending_paths], function(text) {
    grepl("PENDING\\_RECOMPUTATION", text, fixed = TRUE)
  }, logical(1L))
  if (any(claim_map$status == "PENDING_RECOMPUTATION")) {
    if (!all(pending_visible)) {
      stop("Each numerical manuscript section must display its pending status.",
           call. = FALSE)
    }
  } else if (any(pending_visible)) {
    stop("A numerical manuscript section still displays a pending marker ",
         "after all mapped claims were marked READY.", call. = FALSE)
  }
  invisible(claim_map)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  root <- if (length(args)) args[[1L]] else "."
  map <- audit_claim_object_map(root)
  cat("Claim-object audit passed for", nrow(map), "mapped claim families.\n")
}
