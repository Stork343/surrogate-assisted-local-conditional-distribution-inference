#!/usr/bin/env Rscript

stop(
  "`reproducibility/export_table_results.R` is retired. It copied secondary ",
  "CSV summaries and created a competing evidence chain. Use the single ",
  "versioned-registry pipeline in `build_manuscript_evidence.R`.",
  call. = FALSE
)
