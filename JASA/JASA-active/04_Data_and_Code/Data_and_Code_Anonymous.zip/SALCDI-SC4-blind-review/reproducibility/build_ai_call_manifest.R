#!/usr/bin/env Rscript

# Build a canonical, API-free linkage from the 6,000 frozen primary dossiers
# to request hashes, final score rows, and cached response-file checksums.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) normalizePath(args[[1L]]) else normalizePath(".")
ai_root <- file.path(root, "simulation", "ai_expert")
machine_dir <- file.path(root, "reproducibility", "machine_tables")
dir.create(machine_dir, recursive = TRUE, showWarnings = FALSE)

ai_r_dir <- file.path(ai_root, "R")
invisible(lapply(
  list.files(ai_r_dir, pattern = "[.]R$", full.names = TRUE), source
))

sha256_file <- function(path) {
  digest::digest(file = path, algo = "sha256")
}
sha256_text <- function(text) {
  digest::digest(enc2utf8(text), algo = "sha256", serialize = FALSE)
}
same_numeric <- function(left, right) {
  if (is.na(left) && is.na(right)) return(TRUE)
  isTRUE(all.equal(as.numeric(left), as.numeric(right), tolerance = 1e-12))
}
same_value <- function(left, right) {
  if (is.na(left) && is.na(right)) return(TRUE)
  identical(as.character(left), as.character(right))
}

config_path <- file.path(ai_root, "config", "api_config.yml")
system_path <- file.path(ai_root, "prompts", "system_primary.txt")
rubric_path <- file.path(ai_root, "prompts", "rubric_primary.txt")
cache_dir <- file.path(ai_root, "cache", "deepseek")
cache_index_path <- file.path(cache_dir, "responses.csv")
corpus_dir <- file.path(ai_root, "corpus")

cfg <- ai_api_config(config_path)
system_prompt <- paste(readLines(system_path, warn = FALSE), collapse = "\n")
rubric <- paste(readLines(rubric_path, warn = FALSE), collapse = "\n")
responses <- utils::read.csv(
  cache_index_path, stringsAsFactors = FALSE, check.names = FALSE
)
if (anyDuplicated(responses$request_hash)) {
  stop("responses.csv contains duplicated request hashes.", call. = FALSE)
}
if (!all(responses$prompt_hash == responses$request_hash, na.rm = TRUE)) {
  stop("Legacy prompt_hash no longer has the documented request-hash alias.",
       call. = FALSE)
}

dossier_manifest <- utils::read.csv(
  file.path(corpus_dir, "dossier_manifest.csv"),
  stringsAsFactors = FALSE, colClasses = "character"
)
truth_manifest <- utils::read.csv(
  file.path(corpus_dir, "truth", "truth_manifest.csv"),
  stringsAsFactors = FALSE, colClasses = "character"
)

system_file_sha <- sha256_file(system_path)
rubric_file_sha <- sha256_file(rubric_path)
corpus_ids <- c("A", "B", "C")
manifest_parts <- vector("list", length(corpus_ids))

for (corpus_index in seq_along(corpus_ids)) {
  corpus_id <- corpus_ids[[corpus_index]]
  corpus <- ai_load_corpus_bundle(
    corpus_dir, corpus_id, include_truth = FALSE, verify_hashes = TRUE
  )
  score_rel <- file.path(
    "simulation", "ai_expert", "results", "raw",
    paste0("ai_scores_primary_corpus", corpus_id, ".csv")
  )
  scores <- utils::read.csv(
    file.path(root, score_rel), stringsAsFactors = FALSE, check.names = FALSE
  )
  if (nrow(scores) != nrow(corpus) ||
      !identical(as.character(scores$case_id), as.character(corpus$case_id))) {
    stop("Score-to-corpus row mapping failed for corpus ", corpus_id, ".",
         call. = FALSE)
  }

  dossier_row <- dossier_manifest[
    dossier_manifest$corpus_id == corpus_id, , drop = FALSE
  ]
  truth_row <- truth_manifest[
    truth_manifest$corpus_id == corpus_id, , drop = FALSE
  ]
  if (nrow(dossier_row) != 1L || nrow(truth_row) != 1L) {
    stop("Corpus manifest mapping failed for corpus ", corpus_id, ".",
         call. = FALSE)
  }

  rows <- vector("list", nrow(corpus))
  for (i in seq_len(nrow(corpus))) {
    dossier <- ai_dossier_text(corpus[i, ], seed = 20260812L + i)
    user_prompt <- paste(
      rubric, dossier, "Return only valid JSON.", sep = "\n\n"
    )
    params <- list(
      temperature = cfg$temperature,
      thinking = FALSE,
      max_tokens = cfg$max_tokens,
      response_format = cfg$response_format
    )
    request_hash <- ai_request_hash(
      cfg$model_primary, system_prompt, user_prompt, params
    )
    response_index <- match(request_hash, responses$request_hash)
    score_failed <- isTRUE(scores$api_failure[[i]])
    response_rel <- file.path(
      "simulation", "ai_expert", "cache", "deepseek",
      paste0(request_hash, ".json")
    )
    response_abs <- file.path(root, response_rel)

    if (is.na(response_index)) {
      if (!score_failed || file.exists(response_abs)) {
        stop("Missing-cache status mismatch for ", corpus_id, " row ", i,
             ".", call. = FALSE)
      }
      status <- "permanent_failure"
      response_rel_value <- NA_character_
      response_sha <- NA_character_
      cache_row <- NA_integer_
      timestamp <- fingerprint <- finish_reason <- NA_character_
      input_tokens <- output_tokens <- retry_count <- NA_real_
      failure_evidence <- paste0(
        score_rel, "#csv_line=", i + 1L,
        ";simulation/ai_expert/corpus/", dossier_row$dossier_file,
        "#line=", i,
        ";simulation/ai_expert/audit/AI_FAILURE_LOG.md"
      )
    } else {
      cached <- responses[response_index, , drop = FALSE]
      if (score_failed || !file.exists(response_abs) ||
          cached$model[[1L]] != cfg$model_primary ||
          !same_numeric(cached$parsed_score[[1L]], scores$parsed_score[[i]]) ||
          !same_numeric(cached$parsed_confidence[[1L]],
                        scores$parsed_confidence[[i]]) ||
          !same_value(cached$parsed_review_needed[[1L]],
                      scores$parsed_review_needed[[i]]) ||
          !same_value(cached$parsed_grade[[1L]], scores$parsed_grade[[i]])) {
        stop("Successful cache-to-score validation failed for ", corpus_id,
             " row ", i, ".", call. = FALSE)
      }
      status <- "success"
      response_rel_value <- response_rel
      response_sha <- sha256_file(response_abs)
      cache_row <- response_index
      timestamp <- cached$timestamp_utc[[1L]]
      fingerprint <- cached$system_fingerprint[[1L]]
      finish_reason <- cached$finish_reason[[1L]]
      input_tokens <- cached$input_tokens[[1L]]
      output_tokens <- cached$output_tokens[[1L]]
      retry_count <- cached$retry_count[[1L]]
      failure_evidence <- NA_character_
    }

    rows[[i]] <- data.frame(
      corpus_id = corpus_id,
      corpus_row = i,
      case_id = corpus$case_id[[i]],
      status = status,
      model_requested = cfg$model_primary,
      thinking_mode = FALSE,
      temperature = cfg$temperature,
      max_tokens = cfg$max_tokens,
      response_format = cfg$response_format,
      prompt_id = "P0",
      system_prompt_file_sha256 = system_file_sha,
      rubric_file_sha256 = rubric_file_sha,
      corpus_dossier_file_sha256 = dossier_row$dossier_sha256,
      corpus_evidence_file_sha256 = dossier_row$evidence_sha256,
      corpus_truth_file_sha256 = truth_row$truth_sha256,
      dossier_text_sha256 = sha256_text(dossier),
      user_prompt_sha256 = sha256_text(user_prompt),
      request_hash = request_hash,
      response_path = response_rel_value,
      response_sha256 = response_sha,
      timestamp_utc = timestamp,
      system_fingerprint = fingerprint,
      finish_reason = finish_reason,
      input_tokens = input_tokens,
      output_tokens = output_tokens,
      retry_count = retry_count,
      parsed_score = scores$parsed_score[[i]],
      parsed_confidence = scores$parsed_confidence[[i]],
      parsed_review_needed = scores$parsed_review_needed[[i]],
      parsed_grade = scores$parsed_grade[[i]],
      api_failure = score_failed,
      source_score_file = score_rel,
      source_score_row = i,
      source_score_csv_line = i + 1L,
      source_cache_index_row = cache_row,
      failure_evidence = failure_evidence,
      reference_version = truth_row$reference_version,
      stringsAsFactors = FALSE
    )
  }
  manifest_parts[[corpus_index]] <- do.call(rbind, rows)
}

manifest <- do.call(rbind, manifest_parts)
expected_success <- c(A = 2998L, B = 1499L, C = 1500L)
observed_success <- table(factor(
  manifest$corpus_id[manifest$status == "success"], levels = corpus_ids
))
if (!identical(as.integer(observed_success), as.integer(expected_success)) ||
    sum(manifest$status == "success") != 5997L ||
    sum(manifest$status == "permanent_failure") != 3L) {
  stop("Primary-call success/failure counts do not match the frozen design.",
       call. = FALSE)
}
if (anyDuplicated(manifest[c("corpus_id", "corpus_row", "request_hash")])) {
  stop("Canonical call-manifest key is not unique.", call. = FALSE)
}

manifest_path <- file.path(machine_dir, "ai_api_call_manifest.csv")
utils::write.csv(manifest, manifest_path, row.names = FALSE, na = "")

summary <- data.frame(
  corpus_id = corpus_ids,
  total_calls = vapply(
    corpus_ids, function(id) sum(manifest$corpus_id == id), integer(1L)
  ),
  successful_calls = as.integer(observed_success),
  permanent_failures = vapply(
    corpus_ids,
    function(id) sum(
      manifest$corpus_id == id & manifest$status == "permanent_failure"
    ),
    integer(1L)
  ),
  model = cfg$model_primary,
  thinking_mode = FALSE,
  temperature = cfg$temperature,
  stringsAsFactors = FALSE
)
utils::write.csv(
  summary, file.path(machine_dir, "ai_api_call_manifest_summary.csv"),
  row.names = FALSE
)

cache_columns <- c(
  "case_id", "request_hash", "model", "thinking_mode", "temperature",
  "prompt_id", "timestamp_utc", "system_fingerprint", "finish_reason",
  "input_tokens", "output_tokens", "retry_count", "parsed_score",
  "parsed_confidence", "parsed_review_needed", "parsed_grade", "api_failure"
)
if (!all(cache_columns %in% names(responses)) || nrow(responses) != 14576L ||
    any(as.logical(responses$api_failure), na.rm = TRUE)) {
  stop("DeepSeek response-cache index does not match the frozen audit schema.",
       call. = FALSE)
}
cache_manifest <- responses[, cache_columns, drop = FALSE]
cache_manifest$response_path <- file.path(
  "simulation", "ai_expert", "cache", "deepseek",
  paste0(cache_manifest$request_hash, ".json")
)
response_paths <- file.path(root, cache_manifest$response_path)
if (any(!file.exists(response_paths))) {
  stop("At least one indexed DeepSeek response file is missing.", call. = FALSE)
}
cache_manifest$response_sha256 <- vapply(
  response_paths, sha256_file, character(1L)
)
cache_manifest$legacy_prompt_hash_alias <- TRUE
utils::write.csv(
  cache_manifest,
  file.path(machine_dir, "ai_response_cache_manifest.csv"),
  row.names = FALSE, na = ""
)

cache_summary <- aggregate(
  rep(1L, nrow(cache_manifest)),
  by = list(
    model = cache_manifest$model,
    thinking_mode = cache_manifest$thinking_mode,
    temperature = cache_manifest$temperature,
    prompt_id = cache_manifest$prompt_id
  ),
  FUN = sum
)
names(cache_summary)[ncol(cache_summary)] <- "cached_responses"
utils::write.csv(
  cache_summary,
  file.path(machine_dir, "ai_response_cache_manifest_summary.csv"),
  row.names = FALSE, na = ""
)

cat(
  "Validated and wrote 6,000 primary AI calls:",
  sum(manifest$status == "success"), "successes and",
  sum(manifest$status == "permanent_failure"), "permanent failures;",
  nrow(cache_manifest), "cached responses checksummed.\n"
)
