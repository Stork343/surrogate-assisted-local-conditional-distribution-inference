#!/usr/bin/env Rscript

# Rebuild Supplement Tables S5--S6 from frozen machine-readable evidence.
# This presentation-only entry point does not rerun an estimator.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) normalizePath(args[[1L]]) else normalizePath(".")
machine_dir <- file.path(root, "reproducibility", "machine_tables")
table_dir <- file.path(root, "paper", "tables")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

coverage_path <- file.path(
  machine_dir, "band_coverage_by_minimum_fold.csv"
)
coverage <- read.csv(
  coverage_path, stringsAsFactors = FALSE, check.names = FALSE
)
required_coverage <- c(
  "method", "minimum_fold_bin", "replications", "raw_coverage"
)
if (!all(required_coverage %in% names(coverage))) {
  stop("Band local-information table is missing required columns.",
       call. = FALSE)
}
bins <- c("0--3", "4--5", "6--9", "10+")
adaptive <- coverage[
  coverage$method == "Adaptive",
  required_coverage,
  drop = FALSE
]
anchor <- coverage[
  coverage$method == "X_anchor",
  required_coverage,
  drop = FALSE
]
adaptive <- adaptive[match(bins, adaptive$minimum_fold_bin), ]
anchor <- anchor[match(bins, anchor$minimum_fold_bin), ]
if (anyNA(adaptive$minimum_fold_bin) || anyNA(anchor$minimum_fold_bin) ||
    !identical(adaptive$replications, anchor$replications)) {
  stop("Band local-information rows do not match across methods.",
       call. = FALSE)
}
coverage_rows <- vapply(seq_along(bins), function(index) {
  paste0(
    bins[[index]], " & ",
    format(adaptive$replications[[index]], big.mark = ",",
           scientific = FALSE), " & ",
    formatC(adaptive$raw_coverage[[index]], digits = 3L, format = "f"),
    " & ",
    formatC(anchor$raw_coverage[[index]], digits = 3L, format = "f"),
    " \\\\"
  )
}, character(1L))
writeLines(
  c(
    "\\begin{table}[p]",
    "\\centering",
    "\\small",
    paste0(
      "\\caption{Raw-process coverage by the minimum number of verified ",
      "kernel-support observations in any role fold, pooled over the 24 band ",
      "cells.}"
    ),
    "\\label{tab:band-local-information}",
    "\\begin{tabular}{lrrr}",
    "\\toprule",
    paste0(
      "Minimum role-fold count & Replications & Adaptive & Anchor ",
      "\\\\"
    ),
    "\\midrule",
    coverage_rows,
    "\\bottomrule",
    "\\end{tabular}",
    "\\end{table}"
  ),
  file.path(table_dir, "table_band_local_information.tex"),
  useBytes = TRUE
)

vanishing_path <- file.path(
  machine_dir, "figure2_vanishing_curvature.csv"
)
vanishing <- read.csv(
  vanishing_path, stringsAsFactors = FALSE, check.names = FALSE
)
required_vanishing <- c(
  "candidate_scale", "relative_curvature", "lambda_hat",
  "effective_correction_scale", "adaptive_oracle_ise_gap"
)
if (!all(required_vanishing %in% names(vanishing)) || nrow(vanishing) != 5L) {
  stop("Vanishing-path table does not match its frozen schema.",
       call. = FALSE)
}
vanishing <- vanishing[order(vanishing$candidate_scale, decreasing = TRUE), ]
vanishing_rows <- vapply(seq_len(nrow(vanishing)), function(index) {
  paste0(
    formatC(vanishing$candidate_scale[[index]], digits = 3L, format = "f"),
    " & ",
    formatC(vanishing$relative_curvature[[index]], digits = 4L, format = "f"),
    " & ",
    formatC(vanishing$lambda_hat[[index]], digits = 4L, format = "f"),
    " & ",
    formatC(vanishing$effective_correction_scale[[index]],
            digits = 4L, format = "f"),
    " & ",
    formatC(1e5 * vanishing$adaptive_oracle_ise_gap[[index]],
            digits = 3L, format = "f"),
    " \\\\"
  )
}, character(1L))
writeLines(
  c(
    "\\begin{table}[p]",
    "\\centering",
    "\\small",
    paste0(
      "\\caption{Vanishing-path components as the candidate-path scale ",
      "$s$ approaches zero. The final column is the mean ",
      "Adaptive-minus-path-oracle ISE gap multiplied by $10^5$.}"
    ),
    "\\label{tab:sim-vanishing}",
    "\\begin{tabular}{@{}rrrrr@{}}",
    "\\toprule",
    "$s$ & Relative curvature & $E(\\widehat\\lambda_h)$ &",
    paste0(
      "$s\\,E(\\widehat\\lambda_h)$ & ISE gap $(\\times10^5)$ ",
      "\\\\"
    ),
    "\\midrule",
    vanishing_rows,
    "\\bottomrule",
    "\\end{tabular}",
    "\\end{table}"
  ),
  file.path(table_dir, "table5_vanishing_path.tex"),
  useBytes = TRUE
)

cat("Rebuilt Supplement Tables S5--S6 from frozen machine evidence.\n")
