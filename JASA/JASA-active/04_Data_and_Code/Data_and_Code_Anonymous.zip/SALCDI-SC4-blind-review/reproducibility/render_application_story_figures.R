# Academic Figure Skill Asset Confirmation (verified against assets/figures/)
# EPA (a), AI (a): calibration density -> MarginalDensity/KernelDensity semantic mismatch -> param inherit
# EPA (b-c), VitalDB (b-c), AI (b,d): CDF and statistical trends -> LineTrend cross-type inherit -> param inherit
# VitalDB (a): paired discrete count display -> Bubble Scatter cross-type inherit -> param inherit
# AI (c): paired Monte Carlo interval forest -> Forest cross-type inherit -> param inherit
# RULE: "native run" = load pre-rendered PNG via Image.open().ax.imshow().
#       "param inherit" = drawing function below that copies Class A/B/C values.
#       No panel is marked native run; every panel remains vector in the final PDF/SVG.

# Academic Figure Skill Typography Baseline — COPY VERBATIM, place at TOP of script
library(ggplot2)
theme_cns <- theme_bw(base_size = 8, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 8),
    axis.text = element_text(size = 7, color = "#333333"),
    legend.title = element_text(size = 8, face = "bold"),
    legend.text = element_text(size = 7),
    strip.text = element_text(size = 8, face = "bold"),
    panel.grid = element_blank(),
    legend.background = element_blank(),
    legend.key = element_blank()
  )

# Academic Figure Skill Nature/Cell/Science Color Palette -- COPY VERBATIM
categorical <- c("#2166AC", "#B2182B", "#1B7837", "#F1A340", "#762A83", "#666666")
categorical_extended <- c(
  "#2166AC", "#B2182B", "#1B7837", "#F1A340", "#762A83", "#666666",
  "#4393C3", "#D6604D", "#5AAE61", "#B35806", "#9970AB", "#999999"
)
diverging  <- c("#2166AC", "#F7F7F7", "#B2182B")
sequential <- c("#F7FBFF", "#6BAED6", "#08306B")
accent_red <- "#B2182B"
grey       <- "#999999"
black      <- "#222222"

# Academic Figure Skill Export Baseline — COPY VERBATIM
save_cns_figure <- function(plot, filename, width_mm = 183, height_mm = NULL) {
  ggsave(paste0(filename, ".pdf"), plot, device = cairo_pdf,
         width = width_mm, height = height_mm, units = "mm", dpi = 300)
  png(paste0(filename, ".png"), width = width_mm, height = height_mm,
      units = "mm", res = 300, type = "cairo")
  print(plot)
  dev.off()
}

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) normalizePath(args[[1L]]) else normalizePath(".")
data_dir <- file.path(root, "reproducibility", "application_story")
out_dir <- file.path(root, "paper", "figures")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("patchwork", "svglite", "ragg", "scales")
missing <- required[!vapply(required, requireNamespace, logical(1L), quietly = TRUE)]
if (length(missing)) stop("Missing packages: ", paste(missing, collapse = ", "))

read_story <- function(name, required_columns) {
  path <- file.path(data_dir, name)
  if (!file.exists(path)) stop("Missing application-story source: ", path)
  x <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  absent <- setdiff(required_columns, names(x))
  if (length(absent)) stop(name, " missing columns: ", paste(absent, collapse = ", "))
  x
}

# Manuscript-consistent method roles.
INK <- "#20252B"
TEAL <- "#2A7F79"
ORANGE <- "#C76E2B"
SLATE <- "#65758B"
GRID <- "#D8DEE6"
PALE_SLATE <- "#EFF3F7"
TARGET_COLORS <- c("30% RH" = categorical[1], "50% RH" = categorical[4],
                   "70% RH" = categorical[3],
                   "30 min" = categorical[1], "75 min" = categorical[4],
                   "180 min" = categorical[3])
TARGET_TYPES <- c("30% RH" = "solid", "50% RH" = "longdash", "70% RH" = "dotted",
                  "30 min" = "solid", "75 min" = "longdash", "180 min" = "dotted")

theme_jasa <- theme_cns +
  theme(
    panel.border = element_blank(),
    axis.line = element_line(color = SLATE, linewidth = 0.35),
    axis.ticks = element_line(color = SLATE, linewidth = 0.35),
    panel.grid.major.y = element_line(color = GRID, linewidth = 0.25),
    panel.grid.minor = element_blank(),
    plot.title = element_text(size = 8.2, face = "bold", color = INK,
                              hjust = 0, margin = margin(b = 4)),
    plot.tag = element_text(size = 9.5, face = "bold", color = INK),
    plot.tag.position = c(0.01, 0.99),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.box = "horizontal",
    legend.margin = margin(t = 1, b = 0),
    legend.key.width = grid::unit(10, "pt"),
    plot.margin = margin(5, 5, 4, 5)
  )

save_figure_set <- function(plot, stem, width_mm, height_mm) {
  base <- file.path(out_dir, stem)
  ggplot2::ggsave(paste0(base, ".pdf"), plot, device = grDevices::cairo_pdf,
                  width = width_mm, height = height_mm, units = "mm", dpi = 360,
                  bg = "white")
  svglite::svglite(paste0(base, ".svg"), width = width_mm / 25.4,
                   height = height_mm / 25.4, bg = "white")
  print(plot)
  grDevices::dev.off()
  grDevices::png(paste0(base, ".png"), width = width_mm / 25.4,
                 height = height_mm / 25.4, units = "in", res = 360,
                 type = "cairo", bg = "white")
  print(plot)
  grDevices::dev.off()
  ragg::agg_tiff(paste0(base, ".tiff"), width = width_mm, height = height_mm,
                 units = "mm", res = 600, compression = "lzw", background = "white")
  print(plot)
  grDevices::dev.off()
}

target_scales <- function(labels) {
  list(
    scale_color_manual(values = TARGET_COLORS[labels], breaks = labels, name = NULL),
    scale_linetype_manual(values = TARGET_TYPES[labels], breaks = labels, name = NULL)
  )
}

# EPA figure: observed relation, localized reference distributions, and
# paired repeated-mask risk over ordered reference fractions.
epa_cal <- read_story(
  "epa_calibration_points.csv",
  c("reference_log_pm25", "surrogate_log_pm25", "relative_humidity")
)
epa_cdf <- read_story(
  "epa_complete_data_local_cdf.csv",
  c("target_label", "threshold_raw", "localized_cdf")
)
epa_frontier <- read_story(
  "epa_risk_frontier.csv",
  c("target", "p", "relative_risk", "relative_risk_low", "relative_risk_high")
)
stopifnot(nrow(epa_cal) == 2814L, nrow(epa_cdf) == 303L, nrow(epa_frontier) == 9L)
epa_cdf$target_label <- factor(epa_cdf$target_label,
                               levels = c("30% RH", "50% RH", "70% RH"))
epa_frontier$target <- factor(epa_frontier$target,
                              levels = c("30% RH", "50% RH", "70% RH"))

epa_a <- ggplot(epa_cal, aes(reference_log_pm25, surrogate_log_pm25)) +
  geom_bin_2d(bins = 30) +
  geom_abline(intercept = 0, slope = 1, color = SLATE, linewidth = 0.45,
              linetype = "dashed") +
  scale_fill_gradientn(colors = sequential, trans = "sqrt", guide = "none") +
  coord_equal(xlim = c(0, 5.1), ylim = c(0, 5.1), expand = FALSE) +
  labs(title = "Sensor vs reference",
       x = expression(log(1 + reference~PM[2.5])),
       y = expression(log(1 + PurpleAir~PM[2.5]))) +
  theme_jasa

epa_b <- ggplot(epa_cdf, aes(threshold_raw, localized_cdf,
                             color = target_label, linetype = target_label)) +
  geom_line(linewidth = 0.85) +
  target_scales(levels(epa_cdf$target_label)) +
  scale_x_continuous(breaks = c(5, 10, 15, 20, 25)) +
  scale_y_continuous(limits = c(0, 1), breaks = c(0, .25, .5, .75, 1),
                     expand = expansion(mult = c(0, .01))) +
  labs(title = "Local reference CDFs",
       x = expression(reference~PM[2.5]~threshold~(mu*g/m^3)),
       y = expression(F[h*","*emp](y~"|"~x[0]))) +
  theme_jasa

epa_c <- ggplot(epa_frontier, aes(p, relative_risk, color = target,
                                  linetype = target, group = target)) +
  geom_hline(yintercept = 1, color = SLATE, linewidth = 0.45,
             linetype = "dashed") +
  geom_errorbar(aes(ymin = relative_risk_low, ymax = relative_risk_high),
                width = 0.006, linewidth = 0.45) +
  geom_line(linewidth = 0.7) +
  geom_point(shape = 21, fill = "white", stroke = 0.65, size = 2.0) +
  target_scales(levels(epa_frontier$target)) +
  scale_x_continuous(breaks = c(.05, .10, .20),
                     labels = scales::label_percent(accuracy = 1)) +
  scale_y_continuous(limits = c(.25, 1.02), breaks = c(.3, .5, .7, .9, 1)) +
  labs(title = "Risk across budgets",
       x = "reference fraction", y = "Adaptive / Anchor ISE") +
  theme_jasa + guides(color = "none", linetype = "none")

epa_figure <- (epa_a | epa_b | epa_c) +
  patchwork::plot_layout(widths = c(1.02, 1, 1), guides = "collect") +
  patchwork::plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size = 9.5, face = "bold"),
        legend.position = "bottom")
save_figure_set(epa_figure, "figure4_epa_application", 170, 77)

# VitalDB figure: discrete agreement, target-time local distributions, and
# reference efficiency across the complete budget grid.
vital_pairs <- read_story("vitaldb_pair_counts.csv", c("sao2", "spo2", "count"))
vital_cdf <- read_story(
  "vitaldb_complete_data_local_cdf.csv",
  c("target_label", "threshold", "localized_cdf")
)
vital_frontier <- read_story(
  "vitaldb_risk_frontier.csv",
  c("target", "p", "relative_risk", "relative_risk_low", "relative_risk_high")
)
stopifnot(sum(vital_pairs$count) == 3178L, nrow(vital_cdf) == 90L,
          nrow(vital_frontier) == 12L)
vital_cdf$target_label <- factor(vital_cdf$target_label,
                                 levels = c("30 min", "75 min", "180 min"))
vital_frontier$target <- factor(vital_frontier$target,
                                levels = c("30 min", "75 min", "180 min"))

vital_a <- ggplot(vital_pairs, aes(spo2, sao2, size = count)) +
  geom_abline(intercept = 0, slope = 1, color = SLATE, linewidth = 0.45,
              linetype = "dashed") +
  geom_point(shape = 21, fill = "#6BAED6", color = INK, stroke = 0.25) +
  scale_size_area(max_size = 5.0, guide = "none") +
  coord_equal(xlim = c(50, 103), ylim = c(50, 103), expand = FALSE) +
  scale_x_continuous(breaks = seq(50, 100, 10)) +
  scale_y_continuous(breaks = seq(50, 100, 10)) +
  labs(title = expression(SpO[2]~"vs"~SaO[2]),
       x = expression(SpO[2]~"(%)"), y = expression(SaO[2]~"(%)")) +
  theme_jasa

vital_b <- ggplot(vital_cdf, aes(threshold, localized_cdf,
                                 color = target_label, linetype = target_label)) +
  geom_line(linewidth = 0.9) +
  target_scales(levels(vital_cdf$target_label)) +
  scale_x_continuous(breaks = c(70, 80, 90, 95, 99)) +
  scale_y_continuous(limits = c(0, .60), breaks = c(0, .15, .30, .45, .60),
                     expand = expansion(mult = c(0, .01))) +
  labs(title = "Local reference CDFs",
       x = expression(SaO[2]~threshold~"(%)"),
       y = expression(F[h*","*emp](y~"|"~x[0]))) +
  theme_jasa

vital_c <- ggplot(vital_frontier, aes(p, relative_risk, color = target,
                                      linetype = target, group = target)) +
  geom_hline(yintercept = 1, color = SLATE, linewidth = 0.45,
             linetype = "dashed") +
  geom_errorbar(aes(ymin = relative_risk_low, ymax = relative_risk_high),
                width = 0.012, linewidth = 0.45) +
  geom_line(linewidth = 0.7) +
  geom_point(shape = 21, fill = "white", stroke = 0.65, size = 2.0) +
  target_scales(levels(vital_frontier$target)) +
  scale_x_continuous(breaks = c(.05, .10, .20, .40),
                     labels = scales::label_percent(accuracy = 1)) +
  scale_y_continuous(limits = c(.75, 1.005), breaks = c(.8, .85, .9, .95, 1)) +
  labs(title = "Risk across budgets",
       x = "reference fraction", y = "Adaptive / Anchor ISE") +
  theme_jasa + guides(color = "none", linetype = "none")

vital_figure <- (vital_a | vital_b | vital_c) +
  patchwork::plot_layout(widths = c(1.03, 1, 1), guides = "collect") +
  patchwork::plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size = 9.5, face = "bold"),
        legend.position = "bottom")
save_figure_set(vital_figure, "figure5_vitaldb_application", 170, 77)

# Controlled AI review figure: score calibration, local error, review design,
# and the adverse local-reversal mechanism.
ai_cal <- read_story(
  "ai_calibration_bins.csv",
  c("expert_mid", "automated_mid", "count", "bin_width")
)
ai_error <- read_story(
  "ai_local_error_by_complexity.csv",
  c("complexity_midpoint", "n", "mean_bias", "error_q10", "error_q90")
)
ai_review <- read_story(
  "ai_review_designs_p010.csv",
  c("design_label", "relative_risk", "relative_risk_low", "relative_risk_high",
    "replications")
)
ai_reversal <- read_story(
  "ai_local_reversal_risk.csv",
  c("method", "p", "relative_risk", "relative_risk_low", "relative_risk_high",
    "replications")
)
stopifnot(sum(ai_cal$count) == 2998L, nrow(ai_error) == 17L,
          nrow(ai_review) == 5L, nrow(ai_reversal) == 6L)
ai_review$design_label <- factor(
  ai_review$design_label,
  levels = c("Random", "Confidence", "Low score", "Hybrid", "Locally reduced")
)
ai_reversal$method <- factor(ai_reversal$method, levels = c("Adaptive", "Full"))

ai_a <- ggplot(ai_cal, aes(expert_mid, automated_mid, fill = count)) +
  geom_tile(width = unique(ai_cal$bin_width), height = unique(ai_cal$bin_width)) +
  geom_abline(intercept = 0, slope = 1, color = SLATE, linewidth = 0.45,
              linetype = "dashed") +
  scale_fill_gradientn(colors = sequential, trans = "sqrt", guide = "none") +
  coord_equal(xlim = c(35, 100), ylim = c(35, 100), expand = FALSE) +
  scale_x_continuous(breaks = c(40, 60, 80, 100)) +
  scale_y_continuous(breaks = c(40, 60, 80, 100)) +
  labs(title = "Automated vs expert",
       x = "expert-panel score", y = "automated score") +
  theme_jasa

ai_b <- ggplot(ai_error, aes(complexity_midpoint, mean_bias)) +
  geom_hline(yintercept = 0, color = SLATE, linewidth = 0.45,
             linetype = "dashed") +
  geom_ribbon(aes(ymin = error_q10, ymax = error_q90), fill = PALE_SLATE,
              color = NA) +
  geom_line(color = TEAL, linewidth = 0.85) +
  geom_point(shape = 21, fill = "white", color = TEAL, stroke = 0.65, size = 1.9) +
  scale_x_continuous(limits = c(-1, 1), breaks = c(-1, -.5, 0, .5, 1)) +
  scale_y_continuous(limits = c(-5.5, 5.8), breaks = c(-5, -2.5, 0, 2.5, 5)) +
  labs(title = "Error by complexity",
       x = "standardized complexity", y = "automated - expert score") +
  theme_jasa

ai_c <- ggplot(ai_review, aes(design_label, relative_risk)) +
  geom_hline(yintercept = 1, color = SLATE, linewidth = 0.45,
             linetype = "dashed") +
  geom_errorbar(aes(ymin = relative_risk_low, ymax = relative_risk_high),
                width = 0.18, color = TEAL, linewidth = 0.5) +
  geom_point(shape = 21, fill = "white", color = TEAL, stroke = 0.7, size = 2.2) +
  coord_flip() +
  scale_y_continuous(limits = c(.32, 1.01), breaks = c(.4, .6, .8, 1)) +
  labs(title = "Review designs (10%)",
       x = NULL, y = "Adaptive / Anchor ISE") +
  theme_jasa + theme(panel.grid.major.x = element_line(color = GRID, linewidth = .25),
                     panel.grid.major.y = element_blank())

ai_d <- ggplot(ai_reversal, aes(p, relative_risk, color = method,
                                linetype = method, group = method)) +
  geom_hline(yintercept = 1, color = SLATE, linewidth = 0.45,
             linetype = "dashed") +
  geom_errorbar(aes(ymin = relative_risk_low, ymax = relative_risk_high),
                width = 0.006, linewidth = 0.5) +
  geom_line(linewidth = 0.8) +
  geom_point(shape = 21, fill = "white", stroke = 0.7, size = 2.1) +
  scale_color_manual(values = c("Adaptive" = TEAL, "Full" = ORANGE), name = NULL) +
  scale_linetype_manual(values = c("Adaptive" = "solid", "Full" = "dotted"),
                        name = NULL) +
  scale_x_continuous(breaks = c(.05, .10, .20),
                     labels = scales::label_percent(accuracy = 1)) +
  scale_y_continuous(limits = c(.9, 1.9), breaks = c(1, 1.2, 1.4, 1.6, 1.8)) +
  labs(title = "Local reversal",
       x = "review fraction", y = "method / Anchor ISE") +
  theme_jasa

ai_figure <- ((ai_a | ai_b) / (ai_c | ai_d)) +
  patchwork::plot_layout(guides = "collect", heights = c(1, 1)) +
  patchwork::plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size = 9.5, face = "bold"),
        legend.position = "bottom")
save_figure_set(ai_figure, "figure6_ai_review", 170, 119)

cat("Rendered Section 5 application figures in", out_dir, "\n")
