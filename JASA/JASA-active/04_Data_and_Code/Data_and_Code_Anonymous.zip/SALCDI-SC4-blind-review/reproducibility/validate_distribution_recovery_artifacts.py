#!/usr/bin/env python3
"""Validate frozen threshold-level distribution-recovery artifacts."""

from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path


PRESENTATION_OBJECTS = {
    "simulation_curve_summary",
    "application_curves",
    "application_bands",
    "qc",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--presentation-only", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    manifest_path = (
        root
        / "reproducibility"
        / "distribution_recovery"
        / "artifacts"
        / "distribution_recovery_manifest.csv"
    )
    with manifest_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))

    selected = [
        row
        for row in rows
        if not args.presentation_only or row["object"] in PRESENTATION_OBJECTS
    ]
    errors: list[str] = []
    for row in selected:
        raw_path = row["path"]
        prefix = "$CANONICAL_ARTIFACT_ROOT/"
        relative = raw_path[len(prefix) :] if raw_path.startswith(prefix) else raw_path
        path = root / relative
        if not path.is_file():
            errors.append(f"{row['object']}: missing {relative}")
            continue
        observed_bytes = path.stat().st_size
        observed_sha = sha256_file(path)
        if observed_bytes != int(row["bytes"]):
            errors.append(
                f"{row['object']}: bytes {observed_bytes} != {row['bytes']}"
            )
        if observed_sha != row["sha256"]:
            errors.append(
                f"{row['object']}: sha256 {observed_sha} != {row['sha256']}"
            )

    if errors:
        raise SystemExit("\n".join(errors))
    mode = "presentation" if args.presentation_only else "full"
    print(f"Distribution-recovery {mode} manifest: {len(selected)}/{len(selected)} PASS")


if __name__ == "__main__":
    main()
