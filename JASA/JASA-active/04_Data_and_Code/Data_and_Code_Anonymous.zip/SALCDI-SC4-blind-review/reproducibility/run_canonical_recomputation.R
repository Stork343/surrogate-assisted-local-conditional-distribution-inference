#!/usr/bin/env Rscript

canonical_recomputation_commands <- function(root = ".", cores = 1L) {
  root <- normalizePath(root)
  cores <- as.integer(cores)
  simulation_scripts <- sprintf("simulation/run/%02d_%s.R", 1:10, c(
    "oracle_mechanism", "feasible", "selective_verification", "scarcity",
    "nuisance_stress", "distribution_stress", "bootstrap",
    "estimated_propensity", "supplementary", "vanishing_curvature"
  ))
  rows <- lapply(simulation_scripts, function(script) {
    data.frame(stage = "simulation", script = script,
               arg1 = root, arg2 = as.character(cores),
               stringsAsFactors = FALSE)
  })
  rows <- c(rows, list(
    data.frame(stage = "application", script = "analysis/04_public_application.R",
               arg1 = "--reps=500", arg2 = paste0("--cores=", cores),
               stringsAsFactors = FALSE),
    data.frame(stage = "application", script = "analysis/05_third_party_application.R",
               arg1 = "--reps=500", arg2 = paste0("--cores=", cores),
               stringsAsFactors = FALSE),
    data.frame(stage = "ai", script = "simulation/ai_expert/run/01_generate_corpus.R",
               arg1 = root, arg2 = NA_character_, stringsAsFactors = FALSE),
    data.frame(stage = "ai", script = "simulation/ai_expert/run/07_controlled_failures.R",
               arg1 = root, arg2 = NA_character_, stringsAsFactors = FALSE),
    data.frame(stage = "ai", script = "simulation/ai_expert/run/08_reference_masking.R",
               arg1 = root, arg2 = NA_character_, stringsAsFactors = FALSE),
    data.frame(stage = "ai", script = "simulation/ai_expert/run/09_salcdii_analysis.R",
               arg1 = root, arg2 = as.character(cores), stringsAsFactors = FALSE),
    data.frame(stage = "ai", script = "simulation/ai_expert/run/12_ai_bands.R",
               arg1 = root, arg2 = as.character(cores), stringsAsFactors = FALSE),
    data.frame(stage = "ai", script = "simulation/ai_expert/run/13_ai_report.R",
               arg1 = root, arg2 = NA_character_, stringsAsFactors = FALSE)
  ))
  do.call(rbind, rows)
}

run_canonical_recomputation <- function(root = ".", cores = 1L,
                                        stage = "all", execute = FALSE) {
  root <- normalizePath(root)
  ready_markers <- file.path(
    root, "reproducibility",
    c("CANONICAL_RECOMPUTATION_READY", "CANONICAL_RESULTS_READY")
  )
  if (!any(file.exists(ready_markers))) {
    stop("The P0-D correspondence gate has not authorized recomputation.",
         call. = FALSE)
  }
  gate_env <- new.env(parent = globalenv())
  sys.source(file.path(root, "reproducibility", "run_correspondence_gate.R"),
             envir = gate_env)
  gate_env$run_correspondence_gate(root, write_report = FALSE)
  commands <- canonical_recomputation_commands(root, cores)
  if (!identical(stage, "all")) {
    commands <- commands[commands$stage == stage, , drop = FALSE]
  }
  if (!isTRUE(execute)) return(commands)
  if (!identical(Sys.getenv("SALCDI_CONFIRM_FULL_RECOMPUTATION", ""), "YES")) {
    stop("Set SALCDI_CONFIRM_FULL_RECOMPUTATION=YES to execute the printed ",
         "formal plan. Dry-run planning does not require confirmation.",
         call. = FALSE)
  }
  old <- Sys.getenv("SALCDI_FORCE_CANONICAL_RERUN", unset = NA_character_)
  old_wd <- getwd()
  on.exit({
    if (is.na(old)) Sys.unsetenv("SALCDI_FORCE_CANONICAL_RERUN") else
      Sys.setenv(SALCDI_FORCE_CANONICAL_RERUN = old)
    setwd(old_wd)
  }, add = TRUE)
  Sys.setenv(SALCDI_FORCE_CANONICAL_RERUN = "1")
  setwd(root)
  for (i in seq_len(nrow(commands))) {
    script <- file.path(root, commands$script[[i]])
    arguments <- unname(unlist(commands[i, c("arg1", "arg2")],
                               use.names = FALSE))
    arguments <- arguments[!is.na(arguments)]
    status <- system2("Rscript", c(script, arguments))
    if (!identical(status, 0L)) {
      stop("Canonical recomputation failed at ", commands$script[[i]], ".",
           call. = FALSE)
    }
  }
  invisible(commands)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  root <- if (length(args) >= 1L) args[[1L]] else "."
  cores <- if (length(args) >= 2L) as.integer(args[[2L]]) else 1L
  stage <- if (length(args) >= 3L) args[[3L]] else "all"
  execute <- length(args) >= 4L && identical(args[[4L]], "--execute")
  plan <- run_canonical_recomputation(root, cores, stage, execute)
  if (!execute) print(plan, row.names = FALSE)
}
