# Internal Reproducibility Review

Mirror of JASA reproducibility criteria.

- [ ] Data availability is clear.
- [ ] Data represent the original inputs as closely as permitted.
- [ ] Data dictionary and metadata exist.
- [ ] Code availability is clear.
- [ ] Code is readable line by line.
- [ ] Workflow documents script order, inputs, outputs, parameters, and system requirements.
- [ ] Key manuscript results map to reproducible workflow targets.
- [ ] Fresh-environment execution has been attempted and logged.
- [ ] Foundational software packages are cited in the manuscript.
- [ ] ACC information is complete.
