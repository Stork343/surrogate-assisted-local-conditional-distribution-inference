# Statistics and reproducibility report

## Figure 4: EPA

- Panel (a) uses all 2,814 frozen site-days. Each bin count is descriptive; no observations are sampled or dropped. The dashed line is equality on the `log(1 + PM2.5)` scale.
- Panel (b) uses the complete paired data and the registered Epanechnikov bandwidth `h=0.5` on standardized relative humidity. Curves are finite-population kernel-localized empirical CDFs, not estimates with sampling intervals.
- Panel (c) uses 500 common reference masks per target--budget cell. Points are ratios of mean final-CDF ISE. Intervals transform the paired Anchor-minus-Adaptive normal Monte Carlo interval to the risk-ratio scale. They quantify mask-to-mask Monte Carlo variation conditional on the complete-data benchmark.
- Source: `analysis/output/public_application/epa_public_application.rds` and the canonical application frontier. Builder: `Rscript reproducibility/build_application_story_evidence.R .`.

## Figure 5: VitalDB

- Panel (a) uses all 3,178 frozen subject-level pairs. Point area represents the exact count at an integer SaO2--SpO2 pair.
- Panel (b) uses the complete paired cohort, the registered bandwidth `h=0.55` on log elapsed minutes, and thresholds 70--99. Curves are finite-population kernel-localized empirical CDFs.
- Panel (c) uses 500 common reference masks per target--budget cell. Risk ratios and intervals use the same paired construction as Figure 4.
- Source: `analysis/output/vitaldb_application/vitaldb_application.rds` and the canonical application frontier. Builder: `Rscript reproducibility/build_application_story_evidence.R .`.

## Figure 6: controlled AI review

- Panel (a) uses a fixed 28-by-28 score grid formed from all 2,998 valid frozen
  Corpus-A API scores and `fixed-expert-bias-v2` expert outcomes. Only occupied
  cell counts and aggregate calibration statistics are exported; case-level
  expert outcomes, dossier text, and identifiers remain outside the presentation
  layer and anonymous package.
- Panel (b) uses 17 fixed equal-width bins spanning standardized complexity from -1 to 1. The line is the within-bin mean automated-minus-expert error. The envelope is the empirical 10th--90th range, not an inferential interval.
- Panel (c) uses 2,000 common expert-review masks in each of five review designs at `p=0.10`. Intervals use paired Anchor-minus-Adaptive ISE differences.
- Panel (d) uses 2,000 common masks at each review fraction for the AI4 local-reversal perturbation under V5 locally reduced review. Adaptive and Full are paired separately with the same Anchor masks.
- Source: frozen evidence, truth, API-score, and canonical downstream RDS objects listed in `reproducibility/application_story/source_manifest.csv`.

No hypothesis test or multiple-comparison correction is displayed. The only inferential-looking ranges are explicitly identified as paired Monte Carlo intervals or empirical within-bin quantile ranges.
