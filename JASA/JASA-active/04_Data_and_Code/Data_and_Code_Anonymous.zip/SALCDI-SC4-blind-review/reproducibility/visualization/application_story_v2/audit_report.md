# Application visualization audit

## Release decision

Figures 4--6 pass the frozen-source, statistical-semantics, caption-claim,
rendering, and manuscript-role gates. They are approved for the main article.
The former fixed-mask CDF triptych is retained in the Supplement.

## Evidence checks

- The results manifest validates all eleven plotted or audit-supporting sources by path, row count,
  schema, and SHA-256 hash.
- Figure 4 uses 2,814 EPA site-days, three complete-data localized CDFs, and all
  nine registered random-reference risk cells.
- Figure 5 uses 3,178 VitalDB subject pairs, three complete-data localized CDFs,
  and all twelve registered random-reference risk cells.
- Figure 6 uses 2,998 valid frozen scores, all 17 fixed complexity bins, all
  five review designs at the 10% budget, and all six registered local-reversal
  method--budget cells.
- Paired Monte Carlo intervals preserve the common-mask comparison used in the
  manuscript. The AI local-error envelope is labeled as an empirical percentile
  range rather than an inferential interval.

## Manuscript-role checks

- The application-role audit identifies controlled-sampling empirical
  validation as the governing design. The article separately identifies EPA
  and VitalDB as real-data applications and the AI analysis as a controlled
  synthetic benchmark.
- The Section 5 JASA prose heuristic reports no configured high, medium, or low
  finding after the local CDF target was stated explicitly.
- The caption--prose overlap audit reports no finding. Numeric-density flags
  were reviewed against the user's request for a fuller empirical account and
  are documented in `exception_ledger.md`.

## Production checks

- PDF and SVG are vector outputs; PNG is 360 dpi and TIFF is 600 dpi.
- The final width is 170 mm. Figure heights are 77 mm for Figures 4--5 and
  119 mm for Figure 6.
- The renderer's academic-figure validator reports no clipped labels, invalid
  dimensions, missing outputs, or font-size violations.
- PDF/SVG/PNG visual audits report only the declared non-shared-scale warning.
  The accepted exceptions are recorded in `exception_ledger.md`.

## Reproducibility

Run `Rscript reproducibility/render_application_story_figures.R .` to rebuild
all twelve release files from the derived frozen CSV evidence. The underlying
CSV evidence is created from registered frozen objects by
`Rscript reproducibility/build_application_story_evidence.R .`; its source and
artifact checksums are recorded under `reproducibility/application_story/`.
