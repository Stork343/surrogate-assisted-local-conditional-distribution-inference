# Visualization exception ledger

| Scope | Audit code | Disposition | Statistical reason | Verification |
|---|---|---|---|---|
| Figures 4--6 | `V090` / `A050` | Accepted | The panels display different quantities: paired measurements, localized CDFs, risk ratios, and, for Figure 6, local score errors. A shared vertical scale would be dimensionally invalid. Each panel has its own labeled axis and no cross-panel magnitude comparison is claimed. | Figure specifications contain an explicit `scale_exception`; final-size PDF, SVG, and PNG audits found no clipping or unreadable labels. |
| TIFF inspection copies | audit-tool serialization defect | Workaround accepted | The JASA visual-output audit currently cannot serialize TIFF `IFDRational` metadata. This is a tool-format issue, not a rendered-figure failure. | The R renderer checks every TIFF for the registered pixel dimensions, 600-dpi metadata, nonzero size, and SHA-256 hash. PDF, SVG, and PNG versions pass the independent visual audit. |
| Section 5 numeric-density audit | `ND01` | Retained after review | The flagged paragraphs report representative target-specific effects, local correlations, borrowing weights, and adverse-case diagnostics requested for a substantive main-text account. Complete grids remain in tables or the Supplement; no table row is narrated exhaustively. | Caption--prose overlap has no finding, the prose audit has zero high/medium/low findings, and every retained number maps to frozen machine evidence. |

No exception changes a plotted value, uncertainty definition, target, comparison,
or manuscript claim.
