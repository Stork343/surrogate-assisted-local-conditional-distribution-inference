#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${PROJECT_ROOT}"

# Presentation-only rebuild from frozen machine tables and threshold-level
# evidence. This command does not rerun Monte Carlo experiments or estimators.
python3 reproducibility/validate_distribution_recovery_artifacts.py \
  --root "${PROJECT_ROOT}" --presentation-only
Rscript reproducibility/render_main_tables_from_machine.R "${PROJECT_ROOT}"
Rscript reproducibility/render_supplement_tables_from_machine.R "${PROJECT_ROOT}"
python3 reproducibility/generate_submission_figures.py
python3 reproducibility/build_figure3_visualization_audit.py "${PROJECT_ROOT}"
Rscript reproducibility/render_application_story_figures.R "${PROJECT_ROOT}"
python3 reproducibility/build_application_story_audit.py

required_outputs=(
  paper/tables/table_simulation_headline.tex
  paper/tables/table_application_data_roles.tex
  paper/tables/table_application_primary.tex
  paper/tables/table_band_local_information.tex
  paper/tables/table5_vanishing_path.tex
  paper/figures/figure1_distribution_recovery.pdf
  paper/figures/figure2_transfer_geometry.pdf
  paper/figures/figure3_scarcity_inference.pdf
  paper/figures/figure4_application_evidence.pdf
  paper/figures/figure4_epa_application.pdf
  paper/figures/figure4_epa_application.svg
  paper/figures/figure4_epa_application.png
  paper/figures/figure4_epa_application.tiff
  paper/figures/figure5_vitaldb_application.pdf
  paper/figures/figure5_vitaldb_application.svg
  paper/figures/figure5_vitaldb_application.png
  paper/figures/figure5_vitaldb_application.tiff
  paper/figures/figure6_ai_review.pdf
  paper/figures/figure6_ai_review.svg
  paper/figures/figure6_ai_review.png
  paper/figures/figure6_ai_review.tiff
  reproducibility/visualization/figure3_scarcity_inference/figure_audit.json
  reproducibility/visualization/figure3_scarcity_inference/caption.txt
  reproducibility/visualization/figure3_scarcity_inference/alt_text.txt
  reproducibility/visualization/application_story_v2/suite_audit.json
  reproducibility/visualization/application_story_v2/figure4_epa_application_audit.json
  reproducibility/visualization/application_story_v2/figure5_vitaldb_application_audit.json
  reproducibility/visualization/application_story_v2/figure6_ai_review_audit.json
)
for output in "${required_outputs[@]}"; do
  if [[ ! -s "${output}" ]]; then
    echo "Missing or empty rebuilt artifact: ${output}" >&2
    exit 1
  fi
done

echo "Rebuilt six main figures, the fixed-mask Supplement diagnostic, three main tables, two Supplement tables, and the figure evidence audits from frozen evidence."
