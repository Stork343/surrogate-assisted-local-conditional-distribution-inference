# Reference mask and split configuration

## EPA (third-party public dataset)
- Primary script: `analysis/04_public_application.R`
- Helper module: `analysis/public_application_helpers.R`
- Raw data fetch:
  - `acquire_epa_processed_data()` downloads from URL in `analysis/public_application_helpers.R` and validates SHA-256.
- Reference-mask design:
  - `fit_one_epa_mask(data, design, ...)` supports `design = c("random", "selective")`.
  - Random masks use Bernoulli draws at probability `p` using fixed seeds.
  - Selective masks use design-linked propensity scores as implemented in helper functions.
- Output tables:
  - `analysis/output/public_application/tables/table_epa_primary.csv`

## VitalDB
- Acquisition script: `scripts/audit_vitaldb_oximetry.py`
- Main analysis driver: `analysis/05_third_party_application.R`
- Helper module: `analysis/vitaldb_application_helpers.R`
- Data check and read:
  - `read_vitaldb_primary()` validates SHA-256 against `vitaldb_primary_sha256`.
- Reference masks:
  - `draw_vitaldb_reference_mask(data, p, design, replicate, seed_base, ...)`
  - Random (`"random"`) and selective (`"selective"`) designs.
  - Random seed: `vitaldb_mask_seed(design, replicate, seed_base)`.
- Three-way split:
  - `vitaldb_balanced_folds(subjectid, k = 3L)` is used to define 3-way fold structure.
  - Masks are checked for nestedness via `vitaldb_masks_are_nested(data, budgets, designs, replicates, seed_base)`.

## Cross-check and reproducibility
- Nestedness and mask diagnostics are saved by `analysis/05_third_party_application.R` to:
  - `analysis/output/vitaldb_application/mask_manifest.csv`
  - `analysis/output/vitaldb_application/qc_summary.csv`
  - `analysis/output/vitaldb_application/data_diagnostics.csv`
- These files are consumed by manuscript checks and are part of the auditable trail.
