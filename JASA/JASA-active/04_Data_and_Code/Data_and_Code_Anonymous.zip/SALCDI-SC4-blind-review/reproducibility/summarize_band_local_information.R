#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) normalizePath(args[[1L]]) else normalizePath(".")
output_dir <- file.path(root, "simulation", "output")
machine_dir <- file.path(root, "reproducibility", "machine_tables")

files <- list.files(
  output_dir, pattern = "^B_.*_band_rep1000[.]rds$", full.names = TRUE
)
if (length(files) != 24L) {
  stop("Expected 24 final multiplier-band objects; found ", length(files),
       ".", call. = FALSE)
}
raw <- do.call(rbind, lapply(files, readRDS))
required <- c(
  "band_result_version", "multiplier_draws", "band_construction",
  "verified_support_total", "verified_support_min_fold",
  "kernel_verified_weight_min_fold", "simultaneous_coverage",
  "simultaneous_coverage_rearranged"
)
if (!all(required %in% names(raw)) ||
    !identical(unique(raw$band_result_version), "salcdi-band-repro-v1") ||
    !identical(unique(raw$multiplier_draws), 4999L) ||
    !identical(unique(raw$band_construction),
               "unstudentized_raw_supremum")) {
  stop("Final band objects do not share the frozen reproducible schema.",
       call. = FALSE)
}

quantile_value <- function(value, probability) {
  unname(stats::quantile(value, probability, names = FALSE, type = 8L))
}

scenario_groups <- split(raw, interaction(
  raw$scenario_id, raw$method, drop = TRUE, lex.order = TRUE
))
scenario_summary <- do.call(rbind, lapply(scenario_groups, function(data) {
  data.frame(
    scenario_id = data$scenario_id[[1L]],
    method = data$method[[1L]],
    p = data$p[[1L]],
    verification_design = data$verification_design[[1L]],
    nominal_rate_index = data$M[[1L]] * data$p[[1L]] * data$h[[1L]],
    raw_coverage = mean(data$simultaneous_coverage),
    rearranged_endpoint_coverage = mean(
      data$simultaneous_coverage_rearranged
    ),
    mean_verified_support_total = mean(data$verified_support_total),
    mean_verified_support_min_fold = mean(data$verified_support_min_fold),
    q10_verified_support_min_fold = quantile_value(
      data$verified_support_min_fold, 0.10
    ),
    median_verified_support_min_fold = stats::median(
      data$verified_support_min_fold
    ),
    frequency_min_fold_le_3 = mean(data$verified_support_min_fold <= 3),
    frequency_min_fold_lt_10 = mean(data$verified_support_min_fold < 10),
    mean_kernel_verified_weight_min_fold = mean(
      data$kernel_verified_weight_min_fold
    ),
    stringsAsFactors = FALSE
  )
}))
rownames(scenario_summary) <- NULL
scenario_summary <- scenario_summary[order(
  scenario_summary$scenario_id, scenario_summary$method
), ]
write.csv(
  scenario_summary,
  file.path(machine_dir, "band_local_information_diagnostic.csv"),
  row.names = FALSE
)

raw$minimum_fold_bin <- cut(
  raw$verified_support_min_fold,
  breaks = c(-Inf, 3, 5, 9, Inf),
  labels = c("0--3", "4--5", "6--9", "10+"),
  right = TRUE
)
bin_groups <- split(raw, interaction(
  raw$method, raw$minimum_fold_bin, drop = TRUE, lex.order = TRUE
))
bin_summary <- do.call(rbind, lapply(bin_groups, function(data) {
  data.frame(
    method = data$method[[1L]],
    minimum_fold_bin = as.character(data$minimum_fold_bin[[1L]]),
    replications = nrow(data),
    raw_coverage = mean(data$simultaneous_coverage),
    rearranged_endpoint_coverage = mean(
      data$simultaneous_coverage_rearranged
    ),
    mean_band_width = mean(data$integrated_band_width),
    stringsAsFactors = FALSE
  )
}))
rownames(bin_summary) <- NULL
write.csv(
  bin_summary,
  file.path(machine_dir, "band_coverage_by_minimum_fold.csv"),
  row.names = FALSE
)

adaptive <- bin_summary[bin_summary$method == "Adaptive", ]
anchor <- bin_summary[bin_summary$method == "X_anchor", ]
coverage_table <- merge(
  adaptive[, c("minimum_fold_bin", "replications", "raw_coverage")],
  anchor[, c("minimum_fold_bin", "raw_coverage")],
  by = "minimum_fold_bin", suffixes = c("_adaptive", "_anchor")
)
coverage_table$minimum_fold_bin <- factor(
  coverage_table$minimum_fold_bin,
  levels = c("0--3", "4--5", "6--9", "10+")
)
coverage_table <- coverage_table[order(coverage_table$minimum_fold_bin), ]
table_lines <- c(
  "\\begin{table}[p]",
  "\\centering",
  "\\small",
  paste0(
    "\\caption{Raw-process coverage by the minimum number of verified ",
    "kernel-support observations in any role fold, pooled over the 24 band ",
    "cells.}"
  ),
  "\\label{tab:band-local-information}",
  "\\begin{tabular}{lrrr}",
  "\\toprule",
  "Minimum role-fold count & Replications & Adaptive & Anchor \\\\",
  "\\midrule",
  vapply(seq_len(nrow(coverage_table)), function(index) {
    paste0(
      as.character(coverage_table$minimum_fold_bin[[index]]), " & ",
      format(coverage_table$replications[[index]], big.mark = ",",
             scientific = FALSE), " & ",
      formatC(coverage_table$raw_coverage_adaptive[[index]],
              digits = 3L, format = "f"), " & ",
      formatC(coverage_table$raw_coverage_anchor[[index]],
              digits = 3L, format = "f"), " \\\\"
    )
  }, character(1L)),
  "\\bottomrule",
  "\\end{tabular}",
  "\\end{table}"
)
writeLines(
  table_lines,
  file.path(root, "paper", "tables", "table_band_local_information.tex"),
  useBytes = TRUE
)

cat("Wrote local-information diagnostics for", nrow(scenario_summary),
    "scenario-method cells.\n")
