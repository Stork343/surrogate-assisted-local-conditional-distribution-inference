# Summaries and manuscript-ready data frames belong here.
# No plotting code should recompute estimators.
