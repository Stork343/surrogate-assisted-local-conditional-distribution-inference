#!/usr/bin/env Rscript

# Formal VitalDB benchmark: scarce ABG reference outcomes with pulse-oximetry
# surrogates. Reference scarcity is imposed by a known-probability design on a
# fully paired gold-standard pool; it is not the natural ABG ordering process.

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(flag, default) {
  hit <- grep(paste0("^", flag, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", flag, "="), "", hit[[1L]])
}

root <- normalizePath(if (file.exists("DESCRIPTION")) "." else "..")
n_rep <- as.integer(arg_value("--reps", "500"))
cores <- as.integer(arg_value(
  "--cores", as.character(max(1L, min(4L, parallel::detectCores() - 1L)))
))
band_boot <- as.integer(arg_value("--band-boot", "1999"))
frontier_boot <- as.integer(arg_value("--frontier-boot", "999"))
seed_base <- as.integer(arg_value("--seed", "20260814"))
if (!is.finite(n_rep) || n_rep < 1L) stop("--reps must be positive.")
if (!is.finite(cores) || cores < 1L) stop("--cores must be positive.")
if (!is.finite(band_boot) || band_boot < 99L) {
  stop("--band-boot must be at least 99.")
}
if (!is.finite(frontier_boot) || frontier_boot < 99L) {
  stop("--frontier-boot must be at least 99.")
}

invisible(lapply(
  list.files(file.path(root, "R"), pattern = "[.]R$", full.names = TRUE),
  source
))
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source(file.path(root, "simulation", "R", "borrowing_estimators.R"))
source(file.path(root, "analysis", "vitaldb_application_helpers.R"))

out_dir <- file.path(root, "analysis", "output", "vitaldb_application")
fig_dir <- file.path(out_dir, "figures")
table_dir <- file.path(out_dir, "tables")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
primary_path <- file.path(out_dir, "vitaldb_primary_one_per_subject.csv")
audit_path <- file.path(out_dir, "cohort_audit.json")
if (!file.exists(primary_path) || !file.exists(audit_path)) {
  stop(
    "Run scripts/audit_vitaldb_oximetry.py before the VitalDB analysis.",
    call. = FALSE
  )
}

data <- read_vitaldb_primary(primary_path)
folds <- vitaldb_balanced_folds(data$subjectid, k = 3L)
tau <- vitaldb_tau
target_minutes <- vitaldb_target_minutes
h <- vitaldb_bandwidth
budgets <- c(0.05, 0.10, 0.20, 0.40)
designs <- c("random", "selective")

cells <- expand.grid(
  p = budgets, design = designs, replicate = seq_len(n_rep),
  stringsAsFactors = FALSE
)
worker <- function(i) {
  cell <- cells[i, ]
  fit_one_vitaldb_mask(
    data = data, p = cell$p, design = cell$design,
    replicate = cell$replicate, seed_base = seed_base,
    target_minutes = target_minutes, h = h, tau = tau, folds = folds,
    return_u = FALSE
  )$metrics
}

message(
  "Running ", nrow(cells), " VitalDB masks (", n_rep,
  " per budget/design) on ", cores, " core(s)."
)
if (cores == 1L || .Platform$OS.type == "windows") {
  fits <- lapply(seq_len(nrow(cells)), worker)
} else {
  fits <- parallel::mclapply(
    seq_len(nrow(cells)), worker, mc.cores = cores, mc.preschedule = TRUE
  )
}
metrics <- do.call(rbind, fits)
rownames(metrics) <- NULL
summary_table <- summarize_vitaldb_metrics(metrics)

# Paired Full-versus-Adaptive contrasts target the method's safety claim.
pair_key <- c("p", "design", "target_minutes", "replicate")
full <- metrics[metrics$method == "Full",
                c(pair_key, "ise", "tail_ise", "abs_error_pr_y_lt_88",
                  "abs_error_pr_y_lt_90", "negative_transfer")]
adaptive <- metrics[metrics$method == "Adaptive",
                    c(pair_key, "ise", "tail_ise", "abs_error_pr_y_lt_88",
                      "abs_error_pr_y_lt_90", "negative_transfer")]
names(full)[5:9] <- c(
  "full_ise", "full_tail_ise", "full_abs_error_lt_88",
  "full_abs_error_lt_90", "full_nt"
)
names(adaptive)[5:9] <- c(
  "adaptive_ise", "adaptive_tail_ise", "adaptive_abs_error_lt_88",
  "adaptive_abs_error_lt_90", "adaptive_nt"
)
paired <- merge(full, adaptive, by = pair_key, sort = FALSE)
paired$full_minus_adaptive_ise <- paired$full_ise - paired$adaptive_ise
paired$full_minus_adaptive_tail_ise <-
  paired$full_tail_ise - paired$adaptive_tail_ise
paired$full_minus_adaptive_abs_error_lt_88 <-
  paired$full_abs_error_lt_88 - paired$adaptive_abs_error_lt_88
paired$full_minus_adaptive_abs_error_lt_90 <-
  paired$full_abs_error_lt_90 - paired$adaptive_abs_error_lt_90
paired$adaptive_beats_full <- paired$adaptive_ise < paired$full_ise
paired$adaptive_protects_nt <- paired$full_nt - paired$adaptive_nt

anchor <- metrics[metrics$method == "X_anchor",
                  c(pair_key, "ise", "tail_ise", "negative_transfer")]
names(anchor)[5:7] <- c("anchor_ise", "anchor_tail_ise", "anchor_nt")
adaptive_anchor <- merge(anchor, adaptive, by = pair_key, sort = FALSE)
adaptive_anchor$anchor_minus_adaptive_ise <-
  adaptive_anchor$anchor_ise - adaptive_anchor$adaptive_ise
adaptive_anchor$anchor_minus_adaptive_tail_ise <-
  adaptive_anchor$anchor_tail_ise - adaptive_anchor$adaptive_tail_ise

paired_cell <- interaction(
  paired$p, paired$design, paired$target_minutes, drop = TRUE
)
contrast_rows <- lapply(split(paired, paired_cell), function(z) {
  delta <- z$full_minus_adaptive_ise
  delta_tail <- z$full_minus_adaptive_tail_ise
  delta_lt_88 <- z$full_minus_adaptive_abs_error_lt_88
  delta_lt_90 <- z$full_minus_adaptive_abs_error_lt_90
  delta_nt <- z$adaptive_protects_nt
  critical <- stats::qt(0.975, df = nrow(z) - 1L)
  data.frame(
    p = z$p[1L], design = z$design[1L],
    target_minutes = z$target_minutes[1L],
    mean_full_minus_adaptive_ise = mean(delta),
    mcse_full_minus_adaptive_ise = stats::sd(delta) / sqrt(nrow(z)),
    mc_low_full_minus_adaptive_ise = mean(delta) -
      stats::qt(0.975, df = nrow(z) - 1L) * stats::sd(delta) / sqrt(nrow(z)),
    mc_high_full_minus_adaptive_ise = mean(delta) +
      stats::qt(0.975, df = nrow(z) - 1L) * stats::sd(delta) / sqrt(nrow(z)),
    mean_full_minus_adaptive_tail_ise = mean(delta_tail),
    mcse_full_minus_adaptive_tail_ise = stats::sd(delta_tail) / sqrt(nrow(z)),
    mean_full_minus_adaptive_abs_error_lt_88 = mean(delta_lt_88),
    mcse_full_minus_adaptive_abs_error_lt_88 =
      stats::sd(delta_lt_88) / sqrt(nrow(z)),
    mean_full_minus_adaptive_abs_error_lt_90 = mean(delta_lt_90),
    mcse_full_minus_adaptive_abs_error_lt_90 =
      stats::sd(delta_lt_90) / sqrt(nrow(z)),
    adaptive_win_rate = mean(z$adaptive_beats_full),
    negative_transfer_protection = mean(delta_nt),
    mcse_negative_transfer_protection = stats::sd(delta_nt) / sqrt(nrow(z)),
    mc_low_negative_transfer_protection = mean(delta_nt) -
      critical * stats::sd(delta_nt) / sqrt(nrow(z)),
    mc_high_negative_transfer_protection = mean(delta_nt) +
      critical * stats::sd(delta_nt) / sqrt(nrow(z)),
    reps = nrow(z), stringsAsFactors = FALSE
  )
})
contrasts <- do.call(rbind, contrast_rows)
contrasts <- contrasts[
  order(contrasts$design, contrasts$p, contrasts$target_minutes),
]
rownames(contrasts) <- NULL

adaptive_anchor_cell <- interaction(
  adaptive_anchor$p, adaptive_anchor$design,
  adaptive_anchor$target_minutes, drop = TRUE
)
adaptive_anchor_contrasts <- do.call(rbind, lapply(
  split(adaptive_anchor, adaptive_anchor_cell), function(z) {
    delta <- z$anchor_minus_adaptive_ise
    delta_tail <- z$anchor_minus_adaptive_tail_ise
    critical <- stats::qt(0.975, df = nrow(z) - 1L)
    data.frame(
      p = z$p[1L], design = z$design[1L],
      target_minutes = z$target_minutes[1L],
      mean_anchor_minus_adaptive_ise = mean(delta),
      mcse_anchor_minus_adaptive_ise = stats::sd(delta) / sqrt(nrow(z)),
      mc_low_anchor_minus_adaptive_ise = mean(delta) -
        critical * stats::sd(delta) / sqrt(nrow(z)),
      mc_high_anchor_minus_adaptive_ise = mean(delta) +
        critical * stats::sd(delta) / sqrt(nrow(z)),
      mean_anchor_minus_adaptive_tail_ise = mean(delta_tail),
      mcse_anchor_minus_adaptive_tail_ise =
        stats::sd(delta_tail) / sqrt(nrow(z)),
      adaptive_win_rate_vs_anchor = mean(delta > 0),
      reps = nrow(z), stringsAsFactors = FALSE
    )
  }
))
adaptive_anchor_contrasts <- adaptive_anchor_contrasts[
  order(adaptive_anchor_contrasts$design, adaptive_anchor_contrasts$p,
        adaptive_anchor_contrasts$target_minutes),
]
rownames(adaptive_anchor_contrasts) <- NULL

# A mask manifest is also an internal reproducibility check: all target rows
# for a given design/budget/replicate must share one seed and verified count.
manifest_key <- interaction(
  metrics$p, metrics$design, metrics$replicate, drop = TRUE
)
manifest_rows <- lapply(split(metrics, manifest_key), function(z) {
  data.frame(
    p = z$p[1L], design = z$design[1L], replicate = z$replicate[1L],
    seed = z$seed[1L], n_verified = z$n_verified[1L],
    min_local_verified = min(z$local_actual_verified),
    max_local_verified = max(z$local_actual_verified),
    target_count = length(unique(z$target_minutes)),
    method_count = length(unique(z$method)), stringsAsFactors = FALSE
  )
})
mask_manifest <- do.call(rbind, manifest_rows)
mask_manifest <- mask_manifest[
  order(mask_manifest$design, mask_manifest$p, mask_manifest$replicate),
]
rownames(mask_manifest) <- NULL

# Diagnostics are computed on the complete paired benchmark, never used to
# fit the scarce-reference estimators.
diagnostic_rows <- lapply(seq_along(target_minutes), function(j) {
  x0 <- log1p(target_minutes[j])
  w <- salcdi_local_weights(data$x, x0, h, kernel = "epanechnikov")
  support <- w > 0
  error <- data$s - data$y
  safe_cor <- function(a, b, weights) {
    keep <- weights > 0 & is.finite(a) & is.finite(b)
    if (sum(keep) < 3L || stats::sd(a[keep]) == 0 || stats::sd(b[keep]) == 0) {
      return(NA_real_)
    }
    stats::cor(a[keep], b[keep])
  }
  data.frame(
    target_minutes = target_minutes[j], x0 = x0, h = h,
    local_support = sum(support), local_effective_n = 1 / sum(w^2),
    local_mae = sum(w * abs(error)), local_bias = sum(w * error),
    unweighted_local_pearson = safe_cor(data$y, data$s, w),
    truth_pr_y_lt_88 = sum(w * (data$y <= 87)),
    truth_pr_y_lt_90 = sum(w * (data$y <= 89)),
    truth_pr_y_lt_92 = sum(w * (data$y <= 91)),
    hidden_hypoxemia_probability = sum(w * (data$y <= 87 & data$s >= 92)),
    truth_mass_y_100 = sum(w * (data$y == 100)), stringsAsFactors = FALSE
  )
})
data_diagnostics <- do.call(rbind, diagnostic_rows)

audit <- jsonlite::fromJSON(audit_path, simplifyVector = TRUE)
flow_names <- names(audit$exclusion_flow)
cohort_flow <- data.frame(
  stage = seq_along(flow_names), item = flow_names,
  count = as.numeric(unlist(audit$exclusion_flow, use.names = FALSE)),
  stringsAsFactors = FALSE
)

truth_rows <- lapply(seq_along(target_minutes), function(j) {
  data.frame(
    target_minutes = target_minutes[j], x0 = log1p(target_minutes[j]),
    h = h, tau = tau,
    cdf = vitaldb_full_target(data, tau, log1p(target_minutes[j]), h),
    stringsAsFactors = FALSE
  )
})
local_truth <- do.call(rbind, truth_rows)

# Signal calibration is deliberately descriptive: G/H are defined on raw
# candidate paths whereas ISE is scored after shape correction.
signal_source <- unique(metrics[
  metrics$method == "Full",
  c("p", "design", "target_minutes", "replicate",
    "full_transfer_signal", "ise")
])
anchor_source <- metrics[
  metrics$method == "X_anchor",
  c("p", "design", "target_minutes", "replicate", "ise")
]
names(anchor_source)[5L] <- "anchor_ise"
signal_source <- merge(signal_source, anchor_source, by = pair_key, sort = FALSE)
signal_source$realized_full_gain <- signal_source$anchor_ise - signal_source$ise
signal_cell <- interaction(
  signal_source$p, signal_source$design, signal_source$target_minutes,
  drop = TRUE
)
signal_calibration <- do.call(rbind, lapply(
  split(signal_source, signal_cell), function(z) {
    data.frame(
      p = z$p[1L], design = z$design[1L],
      target_minutes = z$target_minutes[1L],
      mean_signal = mean(z$full_transfer_signal),
      positive_signal_rate = mean(z$full_transfer_signal > 0),
      mean_realized_full_gain = mean(z$realized_full_gain),
      full_win_rate = mean(z$realized_full_gain > 0),
      within_cell_correlation = if (stats::sd(z$full_transfer_signal) > 0 &&
        stats::sd(z$realized_full_gain) > 0) {
        stats::cor(z$full_transfer_signal, z$realized_full_gain)
      } else NA_real_,
      reps = nrow(z), stringsAsFactors = FALSE
    )
  }
))

# Equivalent designed-reference fraction. The anchor curve is monotonized in
# log-risk; interpolation is confined to the evaluated budget grid.
equivalent_fraction <- function(p_grid, anchor_risk, adaptive_risk, p_current) {
  ordering <- order(p_grid)
  p_grid <- p_grid[ordering]
  anchor_risk <- anchor_risk[ordering]
  monotone_log_risk <- -stats::isoreg(
    log(p_grid), -log(anchor_risk)
  )$yf
  monotone_risk <- exp(monotone_log_risk)
  if (monotone_risk[1L] <= adaptive_risk) {
    return(c(p_eq = p_grid[1L], multiplier = p_grid[1L] / p_current,
             status_code = -1))
  }
  if (monotone_risk[length(monotone_risk)] > adaptive_risk) {
    return(c(p_eq = p_grid[length(p_grid)],
             multiplier = p_grid[length(p_grid)] / p_current,
             status_code = 1))
  }
  right <- which(monotone_risk <= adaptive_risk)[1L]
  left <- right - 1L
  if (abs(log(monotone_risk[right]) - log(monotone_risk[left])) < 1e-12) {
    p_eq <- p_grid[right]
  } else {
    fraction <- (log(adaptive_risk) - log(monotone_risk[left])) /
      (log(monotone_risk[right]) - log(monotone_risk[left]))
    p_eq <- exp(log(p_grid[left]) + fraction *
                  (log(p_grid[right]) - log(p_grid[left])))
  }
  c(p_eq = p_eq, multiplier = p_eq / p_current, status_code = 0)
}

random_metrics <- metrics[metrics$design == "random", ]
frontier_rows <- list()
frontier_counter <- 0L
set.seed(seed_base + 900000L, kind = "L'Ecuyer-CMRG")
bootstrap_ids <- replicate(
  frontier_boot,
  sample(seq_len(n_rep), size = n_rep, replace = TRUE),
  simplify = FALSE
)
for (target in target_minutes) {
  target_data <- random_metrics[random_metrics$target_minutes == target, ]
  anchor_data <- target_data[target_data$method == "X_anchor", ]
  adaptive_data <- target_data[target_data$method == "Adaptive", ]
  anchor_mean <- vapply(budgets, function(p) {
    mean(anchor_data$ise[anchor_data$p == p])
  }, numeric(1))
  for (p_current in budgets) {
    adaptive_mean <- mean(adaptive_data$ise[adaptive_data$p == p_current])
    point <- equivalent_fraction(
      budgets, anchor_mean, adaptive_mean, p_current
    )
    boot_values <- vapply(bootstrap_ids, function(ids) {
      boot_anchor <- vapply(budgets, function(p) {
        values <- anchor_data$ise[anchor_data$p == p]
        mean(values[ids])
      }, numeric(1))
      values <- adaptive_data$ise[adaptive_data$p == p_current]
      equivalent_fraction(
        budgets, boot_anchor, mean(values[ids]), p_current
      )[["multiplier"]]
    }, numeric(1))
    frontier_counter <- frontier_counter + 1L
    frontier_rows[[frontier_counter]] <- data.frame(
      target_minutes = target, p = p_current,
      adaptive_mean_ise = adaptive_mean,
      equivalent_reference_fraction = point[["p_eq"]],
      reference_multiplier = point[["multiplier"]],
      status = c("upper_bound", "interpolated", "lower_bound")[
        point[["status_code"]] + 2L
      ],
      multiplier_mc_low = unname(stats::quantile(
        boot_values, 0.025, names = FALSE
      )),
      multiplier_mc_high = unname(stats::quantile(
        boot_values, 0.975, names = FALSE
      )),
      bootstrap_reps = frontier_boot, stringsAsFactors = FALSE
    )
  }
}
resource_frontier <- do.call(rbind, frontier_rows)

# One frozen-mask multiplier diagnostic. It is not a coverage study.
band_fit <- fit_one_vitaldb_mask(
  data, p = 0.10, design = "random", replicate = 1L,
  seed_base = seed_base, target_minutes = target_minutes, h = h, tau = tau,
  folds = folds, return_u = TRUE
)
band_rows <- list()
example_rows <- list()
counter <- 0L
for (j in seq_along(target_minutes)) {
  target <- band_fit$targets[[j]]
  for (method in c("X_anchor", "Full", "Adaptive")) {
    counter <- counter + 1L
    estimate <- vitaldb_correct_cdf(target$raw_estimates[[method]])
    example_rows[[counter]] <- data.frame(
      target_minutes = target_minutes[j], method = method, tau = tau,
      estimate = estimate, truth = target$truth, stringsAsFactors = FALSE
    )
    if (method %in% c("X_anchor", "Adaptive")) {
      band <- vitaldb_multiplier_band(
        target$influence[[method]], target$raw_estimates[[method]],
        data, h, band_fit$mask$pi, n_boot = band_boot,
        seed = seed_base + 100L * j + match(method, c("X_anchor", "Adaptive"))
      )
      cover <- target$truth >= band$low & target$truth <= band$high
      band_rows[[length(band_rows) + 1L]] <- data.frame(
        target_minutes = target_minutes[j], method = method,
        containment_all_thresholds = all(cover),
        pointwise_containment = mean(cover),
        integrated_width = band$integrated_width,
        critical_value = band$critical_value, n_boot = band$n_boot,
        diagnostic_only = TRUE, stringsAsFactors = FALSE
      )
    }
  }
}
example_cdfs <- do.call(rbind, example_rows)
band_diagnostics <- do.call(rbind, band_rows)

# Fail-hard reproducibility checks.
expected_metric_rows <- nrow(cells) * length(target_minutes) * 4L
checks <- data.frame(
  check = c(
    "replicate_metrics_complete", "finite_primary_metrics",
    "same_mask_across_targets", "three_targets_per_mask",
    "four_methods_and_no_fallback", "fixed_folds_balanced",
    "nested_budget_masks_by_construction"
  ),
  passed = c(
    nrow(metrics) == expected_metric_rows,
    all(is.finite(metrics$ise)) && all(is.finite(metrics$tail_ise)),
    all(vapply(split(metrics$seed, manifest_key), function(z) length(unique(z)) == 1L,
               logical(1))),
    all(mask_manifest$target_count == length(target_minutes)),
    all(mask_manifest$method_count == 4L) &&
      all(metrics$min_nuisance_verified >= 20L) &&
      all(metrics$n_q_fallback == 0L) && all(metrics$n_m_fallback == 0L),
    max(table(folds)) - min(table(folds)) <= 1L,
    vitaldb_masks_are_nested(
      data, budgets, designs, seq_len(n_rep), seed_base = seed_base
    )
  ),
  stringsAsFactors = FALSE
)
if (!all(checks$passed)) {
  write.csv(checks, file.path(out_dir, "qc_summary.csv"), row.names = FALSE)
  stop("A VitalDB reproducibility check failed.", call. = FALSE)
}

metrics$implementation_version <- simulation_implementation_version
write.csv(metrics, file.path(out_dir, "replicate_metrics.csv"), row.names = FALSE)
write.csv(summary_table, file.path(out_dir, "method_summary.csv"), row.names = FALSE)
write.csv(contrasts, file.path(out_dir, "adaptive_full_contrasts.csv"),
          row.names = FALSE)
write.csv(adaptive_anchor_contrasts,
          file.path(out_dir, "adaptive_anchor_contrasts.csv"),
          row.names = FALSE)
write.csv(mask_manifest, file.path(out_dir, "mask_manifest.csv"), row.names = FALSE)
write.csv(cohort_flow, file.path(out_dir, "cohort_flow.csv"), row.names = FALSE)
write.csv(data_diagnostics, file.path(out_dir, "data_diagnostics.csv"),
          row.names = FALSE)
write.csv(local_truth, file.path(out_dir, "local_truth.csv"), row.names = FALSE)
write.csv(signal_calibration, file.path(out_dir, "signal_calibration.csv"),
          row.names = FALSE)
write.csv(resource_frontier, file.path(out_dir, "resource_frontier.csv"),
          row.names = FALSE)
write.csv(example_cdfs, file.path(out_dir, "example_cdfs.csv"), row.names = FALSE)
write.csv(band_diagnostics, file.path(out_dir, "band_diagnostics.csv"),
          row.names = FALSE)
write.csv(checks, file.path(out_dir, "qc_summary.csv"), row.names = FALSE)

# Primary table: p=0.10 random, explicitly retaining Full.
primary <- summary_table[
  summary_table$design == "random" & summary_table$p == 0.10 &
    summary_table$method %in% c("X_anchor", "Full", "Adaptive"),
  c("target_minutes", "method", "mean_ise", "mcse_ise",
    "mean_tail_ise", "mean_risk_gain_pct", "mean_tail_risk_gain_pct",
    "negative_transfer_rate",
    "mean_lambda", "mean_full_transfer_signal")
]
write.csv(primary, file.path(table_dir, "table_vitaldb_primary.csv"),
          row.names = FALSE)

# Publication figures use base R for a dependency-light reproduction path.
colors <- c(X_anchor = "#333333", Full = "#D55E00", Adaptive = "#0072B2")
symbols <- c(X_anchor = 16, Full = 17, Adaptive = 15)
target_colors <- c(`30` = "#009E73", `75` = "#CC79A7", `180` = "#0072B2")
plot_summary <- summary_table[
  summary_table$design == "random" &
    summary_table$method %in% names(colors),
]
png(file.path(fig_dir, "fig_vitaldb_frontier.png"), width = 1800,
    height = 1000, res = 180)
old_par <- par(mfrow = c(1, 3), mar = c(4.3, 4.8, 3, 1), las = 1)
for (target in target_minutes) {
  z <- plot_summary[plot_summary$target_minutes == target, ]
  plot(range(z$p), range(z$mean_ise), log = "xy", type = "n",
       xlab = "Designed reference fraction", ylab = "Mean CDF ISE",
       main = paste0(target, " minutes"))
  for (method in names(colors)) {
    zz <- z[z$method == method, ]
    lines(zz$p, zz$mean_ise, type = "b", lwd = 2,
          col = colors[method], pch = symbols[method])
  }
  if (target == target_minutes[1L]) {
    legend("topright", names(colors), col = colors, pch = symbols,
           lwd = 2, bty = "n")
  }
}
par(old_par)
dev.off()

png(file.path(fig_dir, "fig_vitaldb_resource.png"), width = 1100,
    height = 850, res = 180)
plot(range(resource_frontier$p), range(resource_frontier$reference_multiplier),
     log = "x", type = "n", xlab = "Adaptive reference fraction",
     ylab = "Equivalent anchor fraction / adaptive fraction",
     main = "Designed-reference information multiplier")
abline(h = 1, lty = 2, col = "grey50")
for (target in target_minutes) {
  z <- resource_frontier[
    resource_frontier$target_minutes == target &
      resource_frontier$status == "interpolated",
  ]
  segments(z$p, z$multiplier_mc_low, z$p, z$multiplier_mc_high,
           col = target_colors[as.character(target)])
  lines(z$p, z$reference_multiplier, type = "b", pch = 16, lwd = 2,
        col = target_colors[as.character(target)])
}
legend("topright", paste(target_minutes, "min"), col = target_colors,
       pch = 16, lwd = 2, bty = "n")
dev.off()

png(file.path(fig_dir, "fig_vitaldb_adaptation.png"), width = 2100,
    height = 900, res = 180)
old_par <- par(mfrow = c(1, 2), mar = c(4.5, 5.5, 3, 1), las = 1)
random_contrast <- contrasts[contrasts$design == "random", ]
offset <- c(`30` = -0.006, `75` = 0, `180` = 0.006)
delta_scale <- 1e5
plot(range(random_contrast$p) + c(-0.01, 0.01),
     delta_scale * range(c(random_contrast$mc_low_full_minus_adaptive_ise,
                           random_contrast$mc_high_full_minus_adaptive_ise)),
     type = "n", xlab = "Designed reference fraction",
     ylab = expression(10^5 %*% " (Full ISE - Adaptive ISE)"),
     main = "Paired adaptive advantage")
abline(h = 0, lty = 2, col = "grey50")
for (target in target_minutes) {
  z <- random_contrast[random_contrast$target_minutes == target, ]
  xx <- z$p + offset[as.character(target)]
  segments(xx, delta_scale * z$mc_low_full_minus_adaptive_ise,
           xx, delta_scale * z$mc_high_full_minus_adaptive_ise,
           col = target_colors[as.character(target)], lwd = 2)
  points(xx, delta_scale * z$mean_full_minus_adaptive_ise, pch = 16,
         col = target_colors[as.character(target)])
}
legend("topright", paste(target_minutes, "min"), col = target_colors,
       pch = 16, bty = "n")
plot(random_contrast$p, random_contrast$negative_transfer_protection,
     type = "n", ylim = range(random_contrast$negative_transfer_protection),
     xlab = "Designed reference fraction",
     ylab = "NT rate: Full minus Adaptive",
     main = "Negative-transfer protection")
abline(h = 0, lty = 2, col = "grey50")
for (target in target_minutes) {
  z <- random_contrast[random_contrast$target_minutes == target, ]
  lines(z$p, z$negative_transfer_protection, type = "b", lwd = 2,
        pch = 16, col = target_colors[as.character(target)])
}
par(old_par)
dev.off()

png(file.path(fig_dir, "fig_vitaldb_cdf.png"), width = 1800,
    height = 1000, res = 180)
old_par <- par(mfrow = c(1, 3), mar = c(4.3, 4.5, 3, 1), las = 1)
for (target in target_minutes) {
  z <- example_cdfs[example_cdfs$target_minutes == target, ]
  truth <- unique(z[c("tau", "truth")])
  plot(truth$tau, truth$truth, type = "l", lwd = 3, col = "black",
       xlab = expression(SaO[2] ~ "threshold (%)"), ylab = "Local CDF",
       main = paste0(target, " minutes"), ylim = c(0, 0.55))
  abline(v = c(87, 89), lty = 3, col = "grey70")
  for (method in names(colors)) {
    zz <- z[z$method == method, ]
    lines(zz$tau, zz$estimate, col = colors[method], lwd = 2,
          lty = if (method == "X_anchor") 2 else 1)
  }
  if (target == target_minutes[1L]) {
    legend("topleft", c("Complete benchmark", names(colors)),
           col = c("black", colors), lwd = c(3, 2, 2, 2),
           lty = c(1, 2, 1, 1), bty = "n")
  }
}
par(old_par)
dev.off()

saveRDS(
  list(
    implementation_version = simulation_implementation_version,
    data = data, tau = tau, target_minutes = target_minutes, h = h,
    budgets = budgets, designs = designs, seed_base = seed_base,
    folds = folds, cells = cells, metrics = metrics, summary = summary_table,
    contrasts = contrasts,
    adaptive_anchor_contrasts = adaptive_anchor_contrasts,
    data_diagnostics = data_diagnostics,
    resource_frontier = resource_frontier,
    primary_sha256 = vitaldb_primary_sha256
  ),
  file.path(out_dir, "vitaldb_application.rds")
)
session <- c(
  paste("Run date:", format(Sys.time(), tz = "UTC", usetz = TRUE)),
  paste("Command args:", paste(args, collapse = " ")),
  paste("Primary CSV SHA-256:", vitaldb_primary_sha256),
  paste("Master seed:", seed_base),
  paste("Masks per cell:", n_rep),
  paste("Analysis script SHA-256:", vitaldb_file_sha256(
    file.path(root, "analysis", "05_third_party_application.R")
  )),
  paste("Helper script SHA-256:", vitaldb_file_sha256(
    file.path(root, "analysis", "vitaldb_application_helpers.R")
  )),
  paste("Acquisition script SHA-256:", vitaldb_file_sha256(
    file.path(root, "scripts", "audit_vitaldb_oximetry.py")
  )),
  capture.output(sessionInfo())
)
writeLines(session, file.path(out_dir, "session_info.txt"))
message("VitalDB formal application complete: ", out_dir)
