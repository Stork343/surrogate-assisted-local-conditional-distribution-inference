# Simulation configuration registry.
# Add final configurations only after the estimator and theorem targets are frozen.

simulation_registry <- list(
  S02_local_bias = list(
    purpose = "Verify the sign criterion 2G-H under local surrogate bias",
    status = "planned"
  ),
  S07_scarce_reference = list(
    purpose = "Verify the sqrt(M p_M h^d) scaling under vanishing reference fraction",
    status = "planned"
  ),
  S08_bad_surrogate = list(
    purpose = "Evaluate first-order safety under deliberately harmful surrogate information",
    status = "planned"
  )
)
