# Simulation execution belongs here after configurations are frozen.
# Keep this script thin: call package functions and save raw replication-level output.

run_simulation_configuration <- function(config_id, config, seed) {
  stop("Simulation engine is intentionally not frozen before theory/API closure.", call. = FALSE)
}
