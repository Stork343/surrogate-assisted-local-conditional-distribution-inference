# Analysis layer

Scripts in this directory call functions from the `salcdi` package. They may configure, run, and summarize analyses but must not contain duplicate implementations of statistical methods.

Planned order:

1. `01_simulation_design.R` — freeze configuration objects;
2. `02_simulation_run.R` — execute one configuration;
3. `03_simulation_summarize.R` — aggregate raw runs;
4. `04_public_application.R` — reproducible validation study;
5. `05_third_party_application.R` — substantive evaluation study.

The public application can be run directly from the project root:

```sh
Rscript analysis/04_public_application.R --reps=500 --cores=4
```

It acquires and verifies the official EPA processed archive, constructs the
site-day analysis file in memory, runs 9,000 documented reference-budget
masks, and writes all derived results under
`analysis/output/public_application/`. Raw data provenance and the frozen
estimand are documented in `data-raw/epa_long_term/README.md` and
`docs/EMPIRICAL_REGISTER.md`.

The formal VitalDB reference-budget benchmark has two reproducible stages:

```sh
python3 scripts/audit_vitaldb_oximetry.py \
  --cache-dir data-raw/vitaldb \
  --output analysis/output/vitaldb_application/vitaldb_oximetry_pairs.csv \
  --primary-output analysis/output/vitaldb_application/vitaldb_primary_one_per_subject.csv \
  --summary analysis/output/vitaldb_application/cohort_audit.json \
  --workers 8

Rscript analysis/05_third_party_application.R \
  --reps=500 --cores=4 --band-boot=1999 --frontier-boot=999
```

The first command retrieves official VitalDB API files, creates the frozen
one-second SpO2--ABG matches, records input and output hashes, and constructs
the independent one-row-per-subject cohort. The second command runs the
locked random and selective known-probability reference masks and writes
all derived results under `analysis/output/vitaldb_application/`. The
estimand, analysis grid, and interpretation constraints are documented in
`docs/EMPIRICAL_REGISTER.md`.

All final workflow orchestration is registered in `_targets.R`.
