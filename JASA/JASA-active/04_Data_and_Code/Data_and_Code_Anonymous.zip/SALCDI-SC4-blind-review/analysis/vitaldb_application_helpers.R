# Helpers for the VitalDB pulse-oximetry application.

vitaldb_primary_sha256 <-
  "61400e0b0f1e57a5fae949cb20fe9e7b9ad9320aced0ac8b12b498497a59b671"

vitaldb_tau <- 70:99
vitaldb_target_minutes <- c(30, 75, 180)
vitaldb_bandwidth <- 0.55

vitaldb_file_sha256 <- function(path) {
  path <- normalizePath(path, mustWork = TRUE)
  command <- if (nzchar(Sys.which("shasum"))) "shasum" else "sha256sum"
  args <- if (identical(command, "shasum")) c("-a", "256", path) else path
  value <- system2(command, args, stdout = TRUE, stderr = TRUE)
  status <- attr(value, "status")
  if (!is.null(status) && status != 0L) {
    stop("Could not calculate the VitalDB file SHA-256.", call. = FALSE)
  }
  strsplit(value[[1L]], "[[:space:]]+")[[1L]][[1L]]
}

read_vitaldb_primary <- function(path,
                                 expected_sha256 = vitaldb_primary_sha256) {
  if (!is.null(expected_sha256)) {
    observed <- vitaldb_file_sha256(path)
    if (!identical(tolower(observed), tolower(expected_sha256))) {
      stop("The VitalDB primary cohort failed the SHA-256 check.",
           call. = FALSE)
    }
  }
  data <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  required <- c(
    "caseid", "subjectid", "lab_time_seconds", "sao2", "spo2",
    "abs_time_delta_seconds"
  )
  missing <- setdiff(required, names(data))
  if (length(missing)) {
    stop("VitalDB primary data are missing: ", paste(missing, collapse = ", "),
         call. = FALSE)
  }
  if (anyDuplicated(data$subjectid)) {
    stop("The primary VitalDB cohort must contain one row per subject.",
         call. = FALSE)
  }
  numeric_required <- c(
    "subjectid", "caseid", "lab_time_seconds", "sao2", "spo2",
    "abs_time_delta_seconds"
  )
  if (any(!vapply(data[numeric_required], function(z) {
    all(is.finite(as.numeric(z)))
  }, logical(1)))) {
    stop("Required VitalDB fields must be finite numeric values.",
         call. = FALSE)
  }
  if (any(data$abs_time_delta_seconds > 1) ||
      any(data$sao2 < 50 | data$sao2 > 100) ||
      any(data$spo2 < 50 | data$spo2 > 100)) {
    stop("The primary VitalDB cohort violates its frozen matching rules.",
         call. = FALSE)
  }
  data <- data[order(as.numeric(data$subjectid)), , drop = FALSE]
  rownames(data) <- NULL
  data$elapsed_minutes <- data$lab_time_seconds / 60
  data$x <- log1p(data$elapsed_minutes)
  data$s <- as.numeric(data$spo2)
  data$y <- as.numeric(data$sao2)
  data$cluster <- as.character(data$subjectid)
  data
}

# A small dependency-free hash used only to assign deterministic folds/seeds.
# Cohort construction uses the stronger SHA-256 row-hash rule upstream.
vitaldb_hash_number <- function(value, salt, modulus = 2147483629) {
  strings <- paste0(salt, "|", as.character(value))
  vapply(strings, function(one) {
    hash <- 0
    for (byte in utf8ToInt(enc2utf8(one))) {
      hash <- (131 * hash + byte) %% modulus
    }
    hash
  }, numeric(1))
}

vitaldb_balanced_folds <- function(subjectid, k = 3L,
                                   salt = "SALCDI-VitalDB-fold-v1") {
  subjectid <- as.character(subjectid)
  if (anyDuplicated(subjectid)) {
    stop("Fold identifiers must be unique subjects.", call. = FALSE)
  }
  if (length(subjectid) < k || k < 2L) {
    stop("There must be at least one subject per fold.", call. = FALSE)
  }
  hash <- vitaldb_hash_number(subjectid, salt)
  ordering <- order(hash, subjectid)
  fold <- integer(length(subjectid))
  fold[ordering] <- rep(seq_len(k), length.out = length(subjectid))
  fold
}

vitaldb_verification_probabilities <- function(data, p,
                                               design = c("random", "selective")) {
  design <- match.arg(design)
  if (length(p) != 1L || !is.finite(p) || p <= 0 || p >= 1) {
    stop("`p` must be a scalar in (0, 1).", call. = FALSE)
  }
  if (design == "random") {
    return(rep(p, nrow(data)))
  }
  if (p > 2 / 3) {
    stop("Selective verification requires p <= 2/3.", call. = FALSE)
  }
  s_sd <- stats::sd(data$s)
  if (!is.finite(s_sd) || s_sd <= 0) {
    stop("Selective verification requires variation in SpO2.", call. = FALSE)
  }
  z <- pmin(pmax((mean(data$s) - data$s) / s_sd, -3), 3)
  raw <- exp(0.8 * z)
  objective <- function(constant) {
    mean(pmin(pmax(constant * raw, 0.5), 1.5)) - 1
  }
  constant <- uniroot(objective, interval = c(0, 10), tol = 1e-12)$root
  relative <- pmin(pmax(constant * raw, 0.5), 1.5)
  pi <- p * relative
  if (abs(mean(pi) - p) > 1e-10 || any(pi < 0.5 * p) ||
      any(pi > 1.5 * p)) {
    stop("Selective verification probabilities failed calibration.",
         call. = FALSE)
  }
  pi
}

vitaldb_mask_seed <- function(design, replicate, seed_base) {
  key <- paste(design, replicate, seed_base, sep = "|")
  as.integer(vitaldb_hash_number(key, "SALCDI-VitalDB-mask-v1") + 1)
}

draw_vitaldb_reference_mask <- function(data, p, design, replicate,
                                        seed_base = 20260813L) {
  design <- match.arg(design, c("random", "selective"))
  if (length(replicate) != 1L || replicate < 1 || replicate != as.integer(replicate)) {
    stop("`replicate` must be a positive integer.", call. = FALSE)
  }
  pi <- vitaldb_verification_probabilities(data, p, design)
  # The seed intentionally excludes p. Reusing the same uniforms across
  # budgets produces nested masks and a coherent reference-resource frontier.
  seed <- vitaldb_mask_seed(design, replicate, seed_base)
  set.seed(seed, kind = "L'Ecuyer-CMRG")
  uniforms <- stats::runif(nrow(data))
  list(
    r = as.integer(uniforms < pi), pi = pi, uniforms = uniforms,
    p = p, design = design,
    replicate = as.integer(replicate), seed = seed
  )
}

vitaldb_masks_are_nested <- function(data, budgets, designs, replicates,
                                     seed_base = 20260813L) {
  budgets <- sort(unique(as.numeric(budgets)))
  designs <- as.character(designs)
  replicates <- as.integer(replicates)
  if (length(budgets) < 2L || any(!is.finite(budgets)) ||
      any(budgets <= 0 | budgets >= 1) || !length(designs) ||
      !length(replicates) || any(replicates < 1L)) {
    stop("Invalid inputs for the nested-mask check.", call. = FALSE)
  }
  all(vapply(designs, function(design) {
    all(vapply(replicates, function(replicate) {
      masks <- lapply(budgets, function(p) {
        draw_vitaldb_reference_mask(
          data, p, design, replicate, seed_base = seed_base
        )
      })
      same_uniforms <- all(vapply(
        masks[-1L], function(mask) {
          identical(mask$uniforms, masks[[1L]]$uniforms)
        }, logical(1)
      ))
      set_inclusion <- all(vapply(seq_len(length(masks) - 1L), function(j) {
        all(masks[[j]]$r <= masks[[j + 1L]]$r)
      }, logical(1)))
      same_uniforms && set_inclusion
    }, logical(1)))
  }, logical(1)))
}

vitaldb_knn_order <- function(train, test, max_k) {
  train <- as.matrix(train)
  test <- as.matrix(test)
  max_k <- min(as.integer(max_k), nrow(train))
  d2 <- outer(rowSums(test^2), rowSums(train^2), "+") -
    2 * tcrossprod(test, train)
  ordering <- t(apply(d2, 1L, order))
  if (is.null(dim(ordering))) {
    ordering <- matrix(ordering, nrow = nrow(test), byrow = TRUE)
  }
  ordering[, seq_len(max_k), drop = FALSE]
}

vitaldb_knn_cdf_from_order <- function(ordering, y_train, tau, k,
                                       neighbor_weights, alpha = 0.5) {
  k <- min(as.integer(k), ncol(ordering))
  index <- ordering[, seq_len(k), drop = FALSE]
  n_test <- nrow(index)
  weights <- matrix(neighbor_weights[index], nrow = n_test, ncol = k)
  denominator <- rowSums(weights)
  if (any(!is.finite(denominator)) || any(denominator <= 0)) {
    stop("KNN neighbor weights are degenerate.", call. = FALSE)
  }
  out <- vapply(tau, function(threshold) {
    indicators <- matrix(
      as.numeric(y_train <= threshold)[index], nrow = n_test, ncol = k
    )
    scaled_count <- k * rowSums(weights * indicators) / denominator
    (scaled_count + alpha) / (k + 2 * alpha)
  }, numeric(n_test))
  if (length(tau) == 1L) out <- matrix(out, ncol = 1L)
  colnames(out) <- as.character(tau)
  out
}

vitaldb_fit_knn_cdf <- function(y, x, s, r, pi, subjectid, tau,
                                include_s = FALSE,
                                k_candidates = c(15L, 30L, 60L, 120L),
                                min_verified = 20L, alpha = 0.5) {
  y <- as.numeric(y)
  x <- as.numeric(x)
  s <- as.numeric(s)
  r <- as.integer(r)
  pi <- as.numeric(pi)
  subjectid <- as.character(subjectid)
  features <- if (include_s) cbind(x = x, s = s) else matrix(x, ncol = 1L)
  center <- colMeans(features)
  scale <- apply(features, 2L, stats::sd)
  scale[!is.finite(scale) | scale <= 0] <- 1
  standardized <- sweep(sweep(features, 2L, center, "-"), 2L, scale, "/")
  verified <- which(r == 1L & is.finite(y))
  use_ipw_neighbors <- !include_s

  constant_fit <- function(reason) {
    if (!length(verified)) {
      marginal <- rep(0.5, length(tau))
    } else {
      fit_weights <- if (use_ipw_neighbors) 1 / pi[verified] else
        rep(1, length(verified))
      empirical <- vapply(tau, function(threshold) {
        weighted.mean(y[verified] <= threshold, fit_weights)
      }, numeric(1))
      n_verified <- length(verified)
      marginal <- (n_verified * empirical + alpha) /
        (n_verified + 2 * alpha)
    }
    list(
      predict = function(xnew, snew = NULL) {
        matrix(marginal, nrow = length(xnew), ncol = length(tau),
               byrow = TRUE, dimnames = list(NULL, as.character(tau)))
      },
      k = NA_integer_, fallback = TRUE, fallback_reason = reason,
      n_verified = length(verified), cv_loss = NA_real_
    )
  }

  if (length(verified) < min_verified) {
    return(constant_fit("fewer than min_verified reference outcomes"))
  }
  cv_fold <- vitaldb_balanced_folds(
    subjectid[verified], k = 5L,
    salt = if (include_s) "SALCDI-VitalDB-m-cv-v1" else
      "SALCDI-VitalDB-q-cv-v1"
  )
  smallest_training <- length(verified) - max(tabulate(cv_fold, nbins = 5L))
  candidates <- sort(unique(as.integer(k_candidates)))
  candidates <- candidates[candidates >= 1L & candidates <= smallest_training]
  if (!length(candidates)) candidates <- max(1L, smallest_training)
  loss_sum <- setNames(numeric(length(candidates)), candidates)
  loss_weight <- setNames(numeric(length(candidates)), candidates)

  for (fold in seq_len(5L)) {
    train_idx <- verified[cv_fold != fold]
    test_idx <- verified[cv_fold == fold]
    ordering <- vitaldb_knn_order(
      standardized[train_idx, , drop = FALSE],
      standardized[test_idx, , drop = FALSE], max(candidates)
    )
    neighbor_weights <- if (use_ipw_neighbors) 1 / pi[train_idx] else
      rep(1, length(train_idx))
    z_test <- 1 * outer(y[test_idx], tau, "<=")
    # q(X) needs IPW scoring when selection depends on S; m(X,S) is already
    # conditionally identified under the designed MAR mechanism.
    scoring_weights <- if (include_s) rep(1, length(test_idx)) else
      1 / pi[test_idx]
    for (candidate in candidates) {
      prediction <- vitaldb_knn_cdf_from_order(
        ordering, y[train_idx], tau, candidate, neighbor_weights, alpha
      )
      row_loss <- rowMeans((z_test - prediction)^2)
      key <- as.character(candidate)
      loss_sum[key] <- loss_sum[key] + sum(scoring_weights * row_loss)
      loss_weight[key] <- loss_weight[key] + sum(scoring_weights)
    }
  }
  cv_loss <- loss_sum / loss_weight
  k_best <- as.integer(names(cv_loss)[which.min(cv_loss)])
  train_features <- standardized[verified, , drop = FALSE]
  neighbor_weights <- if (use_ipw_neighbors) 1 / pi[verified] else
    rep(1, length(verified))

  list(
    predict = function(xnew, snew = NULL) {
      new_features <- if (include_s) {
        cbind(x = as.numeric(xnew), s = as.numeric(snew))
      } else {
        matrix(as.numeric(xnew), ncol = 1L)
      }
      new_standardized <- sweep(
        sweep(new_features, 2L, center, "-"), 2L, scale, "/"
      )
      ordering <- vitaldb_knn_order(train_features, new_standardized, k_best)
      vitaldb_knn_cdf_from_order(
        ordering, y[verified], tau, k_best, neighbor_weights, alpha
      )
    },
    k = k_best, fallback = FALSE, fallback_reason = NA_character_,
    n_verified = length(verified), cv_loss = unname(cv_loss[which.min(cv_loss)])
  )
}

vitaldb_local_borrow_v <- function(x, x0, h, pi) {
  salcdi_gain_weights(
    matrix(x, ncol = 1L), x0 = x0, h = h, pi = pi,
    kernel = "epanechnikov"
  )$weights
}

vitaldb_full_target <- function(data, tau, x0, h) {
  weights <- salcdi_local_weights(
    matrix(data$x, ncol = 1L), x0, h, kernel = "epanechnikov"
  )
  salcdi_local_cdf(salcdi_threshold_signals(data$y, tau), weights)
}

vitaldb_correct_cdf <- function(value) {
  salcdi_monotone_cdf(pmin(pmax(value, 0), 1))
}

fit_one_vitaldb_mask <- function(
    data, p, design, replicate, seed_base = 20260813L,
    target_minutes = vitaldb_target_minutes, h = vitaldb_bandwidth,
    tau = vitaldb_tau, mask = NULL, folds = NULL,
    k_candidates = c(15L, 30L, 60L, 120L), min_verified = 20L,
    return_u = FALSE) {
  if (anyDuplicated(data$subjectid)) {
    stop("Primary inference requires one row per subject.", call. = FALSE)
  }
  tau <- as.numeric(tau)
  if (!identical(tau, sort(unique(tau))) ||
      !all(c(87, 89, 91, 94, 99) %in% tau)) {
    stop("`tau` must be sorted, unique, and contain 87, 89, 91, 94, and 99.",
         call. = FALSE)
  }
  target_minutes <- as.numeric(target_minutes)
  x0_values <- log1p(target_minutes)
  n <- nrow(data)
  if (is.null(mask)) {
    mask <- draw_vitaldb_reference_mask(
      data, p, design, replicate, seed_base = seed_base
    )
  }
  if (length(mask$r) != n || length(mask$pi) != n ||
      any(!(mask$r %in% c(0, 1))) || any(mask$pi <= 0 | mask$pi > 1)) {
    stop("Invalid VitalDB reference mask.", call. = FALSE)
  }
  if (is.null(folds)) {
    folds <- vitaldb_balanced_folds(data$subjectid, k = 3L)
  }
  if (length(folds) != n || !all(folds %in% 1:3)) {
    stop("`folds` must assign every subject to one of three folds.",
         call. = FALSE)
  }
  r <- as.integer(mask$r)
  pi <- as.numeric(mask$pi)
  z <- salcdi_threshold_signals(data$y, tau)
  methods <- c("IPW", "X_anchor", "Full", "Adaptive")
  target_names <- paste0("minute_", target_minutes)
  u_by_target <- setNames(lapply(target_names, function(.) {
    setNames(lapply(methods, function(..) {
      matrix(NA_real_, nrow = n, ncol = length(tau),
             dimnames = list(NULL, as.character(tau)))
    }), methods)
  }), target_names)
  lambda_fold <- matrix(NA_real_, nrow = length(target_minutes), ncol = 3L)
  g_fold <- h_fold <- gain_fold <- lambda_fold
  nuisance_rows <- vector("list", 3L)

  for (fold in seq_len(3L)) {
    roles <- salcdi_three_role_rotation(folds, fold)
    eval_idx <- roles$evaluation
    nuisance_idx <- roles$nuisance
    gain_idx <- roles$gain
    q_fit <- vitaldb_fit_knn_cdf(
      data$y[nuisance_idx], data$x[nuisance_idx], data$s[nuisance_idx],
      r[nuisance_idx], pi[nuisance_idx], data$subjectid[nuisance_idx], tau,
      include_s = FALSE, k_candidates = k_candidates,
      min_verified = min_verified
    )
    m_fit <- vitaldb_fit_knn_cdf(
      data$y[nuisance_idx], data$x[nuisance_idx], data$s[nuisance_idx],
      r[nuisance_idx], pi[nuisance_idx], data$subjectid[nuisance_idx], tau,
      include_s = TRUE, k_candidates = k_candidates,
      min_verified = min_verified
    )
    nuisance_rows[[fold]] <- data.frame(
      fold = fold, n_verified = q_fit$n_verified,
      q_k = q_fit$k, m_k = m_fit$k,
      q_cv_loss = q_fit$cv_loss, m_cv_loss = m_fit$cv_loss,
      q_fallback = q_fit$fallback, m_fallback = m_fit$fallback,
      stringsAsFactors = FALSE
    )
    q_gain <- q_fit$predict(data$x[gain_idx], data$s[gain_idx])
    m_gain <- m_fit$predict(data$x[gain_idx], data$s[gain_idx])
    q_eval <- q_fit$predict(data$x[eval_idx], data$s[eval_idx])
    m_eval <- m_fit$predict(data$x[eval_idx], data$s[eval_idx])
    d_gain <- m_gain - q_gain
    zq_gain <- z[gain_idx, , drop = FALSE] - q_gain

    for (target in seq_along(target_minutes)) {
      v_gain <- vitaldb_local_borrow_v(
        data$x[gain_idx], x0_values[target], h, pi[gain_idx]
      )
      gains <- salcdi_gain_estimates(
        d_gain, zq_gain, v_gain, r[gain_idx], pi[gain_idx]
      )
      g_fold[target, fold] <- gains$G_hat
      h_fold[target, fold] <- gains$H_hat
      lambda_fold[target, fold] <- salcdi_estimated_lambda(
        gains$G_hat, gains$H_hat, floor = 1e-8
      )
      gain_fold[target, fold] <- 2 * gains$G_hat - gains$H_hat
      augmentations <- list(
        IPW = matrix(0, nrow = length(eval_idx), ncol = length(tau)),
        X_anchor = q_eval,
        Full = m_eval,
        Adaptive = q_eval + lambda_fold[target, fold] * (m_eval - q_eval)
      )
      for (method in methods) {
        u_by_target[[target]][[method]][eval_idx, ] <-
          salcdi_augmented_signal(
            z[eval_idx, , drop = FALSE], r[eval_idx], pi[eval_idx],
            augmentations[[method]]
          )
      }
    }
  }

  nuisance_summary <- do.call(rbind, nuisance_rows)
  target_results <- setNames(vector("list", length(target_minutes)), target_names)
  metric_rows <- vector("list", length(target_minutes))
  threshold_index <- match(c(87, 89, 91, 99), tau)
  tail_index <- which(tau <= 94)

  for (target in seq_along(target_minutes)) {
    x0 <- x0_values[target]
    weights <- salcdi_local_weights(
      matrix(data$x, ncol = 1L), x0, h, kernel = "epanechnikov"
    )
    process <- salcdi_crossfit_local_process(
      u_by_target[[target]],
      x = matrix(data$x, ncol = 1L),
      fold_id = folds,
      x0 = x0,
      h = h,
      kernel = "epanechnikov"
    )
    raw_estimates <- process$F
    estimates <- lapply(raw_estimates, vitaldb_correct_cdf)
    truth <- vitaldb_full_target(data, tau, x0, h)
    surrogate_cdf <- salcdi_local_cdf(
      salcdi_threshold_signals(data$s, tau), weights
    )
    local_reference_weight <- weights * r / pi
    local_reference_eff_n <- if (sum(local_reference_weight^2) > 0) {
      sum(local_reference_weight)^2 / sum(local_reference_weight^2)
    } else 0
    rows <- lapply(methods, function(method) {
      estimate <- estimates[[method]]
      raw <- raw_estimates[[method]]
      data.frame(
        method = method,
        ise_raw = mean((raw - truth)^2),
        ise_final = mean((estimate - truth)^2),
        ise = mean((estimate - truth)^2),
        tail_ise_raw = mean((raw[tail_index] - truth[tail_index])^2),
        tail_ise_final = mean((estimate[tail_index] - truth[tail_index])^2),
        tail_ise = mean((estimate[tail_index] - truth[tail_index])^2),
        sup_raw = max(abs(raw - truth)),
        sup_final = max(abs(estimate - truth)),
        sup_error = max(abs(estimate - truth)),
        abs_error_pr_y_lt_88 = abs(estimate[threshold_index[1L]] -
                                     truth[threshold_index[1L]]),
        abs_error_pr_y_lt_90 = abs(estimate[threshold_index[2L]] -
                                     truth[threshold_index[2L]]),
        abs_error_pr_y_lt_92 = abs(estimate[threshold_index[3L]] -
                                     truth[threshold_index[3L]]),
        abs_error_mass_y_100 = abs(
          (1 - estimate[threshold_index[4L]]) -
            (1 - truth[threshold_index[4L]])
        ),
        monotonicity_violations = sum(diff(raw) < -1e-12),
        below_zero = sum(raw < 0), above_one = sum(raw > 1),
        stringsAsFactors = FALSE
      )
    })
    rows <- do.call(rbind, rows)
    anchor_ise <- rows$ise[rows$method == "X_anchor"]
    rows$negative_transfer <- as.integer(rows$ise > anchor_ise)
    rows$gain_vs_anchor_pct <- if (anchor_ise > 0) {
      100 * (anchor_ise - rows$ise) / anchor_ise
    } else NA_real_
    rows$replicate <- replicate
    rows$seed <- mask$seed
    rows$p <- p
    rows$design <- design
    rows$target_minutes <- target_minutes[target]
    rows$x0 <- x0
    rows$h <- h
    rows$n <- n
    rows$n_verified <- sum(r)
    rows$local_support <- sum(weights > 0)
    rows$local_effective_n <- 1 / sum(weights^2)
    rows$local_actual_verified <- sum(r[weights > 0])
    rows$local_expected_verified <- sum(pi[weights > 0])
    rows$local_reference_effective_n <- local_reference_eff_n
    rho <- vapply(process$folds, `[[`, numeric(1L), "rho")
    rows$lambda_hat <- sum(rho * lambda_fold[target, ])
    rows$G_hat <- sum(rho * g_fold[target, ])
    rows$H_hat <- sum(rho * h_fold[target, ])
    rows$full_transfer_signal <- sum(rho * gain_fold[target, ])
    rows$mean_q_k <- mean(nuisance_summary$q_k, na.rm = TRUE)
    rows$mean_m_k <- mean(nuisance_summary$m_k, na.rm = TRUE)
    rows$min_nuisance_verified <- min(nuisance_summary$n_verified)
    rows$n_q_fallback <- sum(nuisance_summary$q_fallback)
    rows$n_m_fallback <- sum(nuisance_summary$m_fallback)
    rows$truth_pr_y_lt_88 <- truth[threshold_index[1L]]
    rows$truth_pr_y_lt_90 <- truth[threshold_index[2L]]
    rows$truth_pr_y_lt_92 <- truth[threshold_index[3L]]
    rows$truth_mass_y_100 <- 1 - truth[threshold_index[4L]]
    rows$naive_surrogate_ise <- mean((surrogate_cdf - truth)^2)
    rows$naive_surrogate_sup_error <- max(abs(surrogate_cdf - truth))
    metric_rows[[target]] <- rows
    target_results[[target]] <- list(
      target_minutes = target_minutes[target], x0 = x0, h = h,
      estimates = estimates, raw_estimates = raw_estimates,
      truth = truth, surrogate_cdf = surrogate_cdf,
      lambda_fold = lambda_fold[target, ], G_fold = g_fold[target, ],
      H_fold = h_fold[target, ], gain_fold = gain_fold[target, ],
      weights = weights, fold_process = process$folds,
      influence = process$influence, fold_id = folds
    )
    if (return_u) target_results[[target]]$u <- u_by_target[[target]]
  }

  list(
    metrics = do.call(rbind, metric_rows), targets = target_results,
    mask = mask, folds = folds, nuisance = nuisance_summary,
    tau = tau, target_minutes = target_minutes, h = h
  )
}

summarize_vitaldb_metrics <- function(metrics) {
  anchor <- metrics[
    metrics$method == "X_anchor",
    c("p", "design", "target_minutes", "replicate", "ise", "tail_ise")
  ]
  names(anchor)[5:6] <- c("anchor_ise", "anchor_tail_ise")
  metrics <- merge(
    metrics, anchor,
    by = c("p", "design", "target_minutes", "replicate"),
    all.x = TRUE, sort = FALSE
  )
  key <- interaction(
    metrics$p, metrics$design, metrics$target_minutes, metrics$method,
    drop = TRUE
  )
  rows <- lapply(split(metrics, key), function(data) {
    data.frame(
      p = data$p[1L], design = data$design[1L],
      target_minutes = data$target_minutes[1L], method = data$method[1L],
      mean_ise = mean(data$ise), median_ise = median(data$ise),
      mcse_ise = stats::sd(data$ise) / sqrt(nrow(data)),
      mean_tail_ise = mean(data$tail_ise),
      mcse_tail_ise = stats::sd(data$tail_ise) / sqrt(nrow(data)),
      mean_sup_error = mean(data$sup_error),
      mean_abs_error_pr_y_lt_88 = mean(data$abs_error_pr_y_lt_88),
      mean_abs_error_pr_y_lt_90 = mean(data$abs_error_pr_y_lt_90),
      mean_abs_error_pr_y_lt_92 = mean(data$abs_error_pr_y_lt_92),
      mean_abs_error_mass_y_100 = mean(data$abs_error_mass_y_100),
      mean_maskwise_gain_pct = mean(data$gain_vs_anchor_pct, na.rm = TRUE),
      mean_risk_gain_pct = 100 * (mean(data$anchor_ise) - mean(data$ise)) /
        mean(data$anchor_ise),
      mean_tail_risk_gain_pct = 100 *
        (mean(data$anchor_tail_ise) - mean(data$tail_ise)) /
        mean(data$anchor_tail_ise),
      negative_transfer_rate = mean(data$negative_transfer),
      mean_lambda = mean(data$lambda_hat),
      lambda_zero_rate = mean(data$lambda_hat <= 1e-12),
      lambda_one_rate = mean(data$lambda_hat >= 1 - 1e-12),
      mean_full_transfer_signal = mean(data$full_transfer_signal),
      mean_verified = mean(data$n_verified),
      mean_local_verified = mean(data$local_actual_verified),
      reps = length(unique(data$replicate)), stringsAsFactors = FALSE
    )
  })
  out <- do.call(rbind, rows)
  out <- out[order(out$design, out$p, out$target_minutes, out$method), ]
  rownames(out) <- NULL
  out
}

vitaldb_multiplier_band <- function(influence, center, data, h, pi,
                                    n_boot = 1999L, level = 0.95,
                                    seed = 20260813L) {
  band <- salcdi_multiplier_band(
    influence = influence,
    center = center,
    p = mean(pi),
    h = h,
    dimension = 1L,
    n_boot = n_boot,
    level = level,
    seed = seed
  )
  list(
    estimate = band$center,
    low = pmax(0, band$band_low),
    high = pmin(1, band$band_high),
    critical_value = band$critical_value,
    integrated_width = mean(
      pmin(1, band$band_high) - pmax(0, band$band_low)
    ),
    n_boot = n_boot, level = level
  )
}
