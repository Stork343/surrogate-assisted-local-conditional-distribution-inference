# Builds the frozen scenario manifest (protocol sections 8, 15-20, 24).
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
source(file.path(root, "simulation", "config", "simulation_constants.R"))

scenario_row <- function(id, module, M, p, x0, h, tau_s, verification,
                         error_dist = "gaussian", target = "F0",
                         m_scenario = NA, q_learner = "L1",
                         m_learner = "L1", q_family = NA, m_family = NA,
                         lambda_floor = 1e-8, pi_mode = "known",
                         discrete = FALSE, d = 1, level = "C_secondary",
                         train_tau_s = NA, m_local_reversal = FALSE,
                         m_tail_failure = FALSE, pi_model = NA,
                         m_est_clip = TRUE, candidate_scale = NA) {
  data.frame(
    scenario_id = id, module = module, M = M, p = p, x0 = x0, h = h,
    tau_s = tau_s, verification_design = verification,
    error_distribution = error_dist, target = target,
    m_scenario = m_scenario, q_learner = q_learner, m_learner = m_learner,
    q_family = q_family, m_family = m_family,
    lambda_floor = lambda_floor, pi_mode = pi_mode,
    discrete = discrete, d = d, level = level,
    train_tau_s = train_tau_s, m_local_reversal = m_local_reversal,
    m_tail_failure = m_tail_failure, pi_model = pi_model,
    m_est_clip = m_est_clip, candidate_scale = candidate_scale,
    stringsAsFactors = FALSE
  )
}

h_bw <- simulation_dgp$h_bandwidth
rows <- list()

# WP1 oracle mechanism: M1-M8 x {R1, R2}.
for (m_sc in sprintf("M%d", 1:8)) {
  for (v in c("R1", "R2")) {
    rows[[length(rows) + 1L]] <- scenario_row(
      id = paste0(m_sc, "_", v), module = "oracle_mechanism",
      M = 4000, p = 0.10, x0 = 0, h = 0.30, tau_s = 0.8,
      verification = v, target = "F_h", m_scenario = m_sc,
      q_learner = "oracle", m_learner = "oracle",
      level = "C_primary"
    )
  }
}

# M4 audit variants using the unclipped candidate in estimation (additive).
for (v in c("R1", "R2")) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("M4_", v, "_unclip"), module = "oracle_mechanism",
    M = 4000, p = 0.10, x0 = 0, h = 0.30, tau_s = 0.8,
    verification = v, target = "F_h", m_scenario = "M4",
    q_learner = "oracle", m_learner = "oracle", m_est_clip = FALSE,
    level = "C_secondary"
  )
}

# Vanishing-curvature path: the candidate correction is a shrinking multiple
# of the oracle correction. This isolates the branch in which H tends to zero
# while the effective correction path vanishes.
for (delta in c(1, 0.5, 0.25, 0.125, 0)) {
  delta_id <- sprintf("%04d", round(1000 * delta))
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("VC_delta", delta_id), module = "vanishing_curvature",
    M = 4000, p = 0.10, x0 = 0, h = 0.30, tau_s = 0.8,
    verification = "R1", target = "F_h", m_scenario = "VC",
    q_learner = "oracle", m_learner = "oracle", candidate_scale = delta,
    m_est_clip = FALSE, level = "C_secondary"
  )
}

# WP2 feasible estimator blocks.
for (xv in c(-0.5, 0.5)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("X0_F2_t8_", if (xv < 0) "m05" else "p05"),
    module = "feasible", M = 2000, p = 0.10, x0 = xv, h = h_bw(2000),
    tau_s = 0.8, verification = "R1", target = "F0",
    level = "C_secondary"
  )
}
for (pval in c(0.05, 0.10, 0.20)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("F1_p", format(pval, nsmall = 2)), module = "feasible",
    M = 2000, p = pval, x0 = 0, h = h_bw(2000), tau_s = 0.8,
    verification = "R1", target = "F0", level = "C_primary"
  )
}
for (tv in c(0.4, 0.8, 1.6)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("F2_t", format(tv * 10, nsmall = 0)),
    module = "feasible", M = 2000, p = 0.10, x0 = 0, h = h_bw(2000),
    tau_s = tv, verification = "R1", target = "F0", level = "C_primary"
  )
}
for (mv in c(1000, 2000, 4000)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("F3_M", mv), module = "feasible",
    M = mv, p = 0.10, x0 = 0, h = h_bw(mv), tau_s = 0.8,
    verification = "R1", target = "F0", level = "C_primary"
  )
}
for (lv in c("L2", "L3")) {
  for (tv in c(0.4, 0.8, 1.6)) {
    rows[[length(rows) + 1L]] <- scenario_row(
      id = paste0("F2_", lv, "_t", format(tv * 10, nsmall = 0)),
      module = "feasible", M = 2000, p = 0.10, x0 = 0, h = h_bw(2000),
      tau_s = tv, verification = "R1", target = "F0",
      q_learner = lv, m_learner = lv, level = "C_secondary"
    )
  }
}

# WP3 selective verification comparison.
for (v in c("R1", "R2", "R3")) {
  for (pval in c(0.05, 0.10, 0.20)) {
    rows[[length(rows) + 1L]] <- scenario_row(
      id = paste0("S_", v, "_p", format(pval, nsmall = 2)),
      module = "selective", M = 2000, p = pval, x0 = 0, h = 0.30,
      tau_s = 0.8, verification = v, target = "F_h",
      level = "C_secondary"
    )
  }
}

# WP4 scarce-reference grid (4 x 4).
for (mv in c(1000, 2000, 4000, 8000)) {
  for (pm in c(0.025, 0.05, 0.10, 0.20)) {
    rows[[length(rows) + 1L]] <- scenario_row(
      id = paste0("SC_M", mv, "_p", format(pm, nsmall = 3)),
      module = "scarcity", M = mv, p = pm, x0 = 0, h = 0.30,
      tau_s = 0.8, verification = "scarcity", target = "F_h",
      level = "C_secondary"
    )
  }
}

# WP5 nuisance-misspecification stress.
n_specs <- list(
  N1 = list(), N2 = list(m_family = "misspecified"),
  N3 = list(q_family = "misspecified"),
  N4 = list(q_family = "misspecified", m_family = "misspecified"),
  N5 = list(m_local_reversal = TRUE),
  N6 = list(m_tail_failure = TRUE),
  N7 = list(train_tau_s = 1.2),
  N8 = list(tau_s = 1.6, p = 0.05, q_learner = "L3", m_learner = "L3")
)
for (nm in names(n_specs)) {
  spec <- n_specs[[nm]]
  args <- list(id = nm, module = "stress", M = 2000, p = 0.10, x0 = 0,
               h = h_bw(2000), tau_s = 0.8, verification = "R1",
               target = "F0", level = "C_secondary")
  args[names(spec)] <- spec
  rows[[length(rows) + 1L]] <- do.call(scenario_row, args)
}

# WP5b distributional stress (protocol section 17).
dist_specs <- list(
  D1_gaussian = "gaussian",
  D2_heavy_tail = "t3",
  D3_right_skew = "skew",
  D4_mixture = "mixture"
)
for (nm in names(dist_specs)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = nm, module = "distribution", M = 2000, p = 0.10, x0 = 0,
    h = h_bw(2000), tau_s = 0.8, verification = "R1",
    error_dist = dist_specs[[nm]], target = "F0",
    level = "C_secondary"
  )
}

# WP6 multiplier bands: 3 p x 2 verification x 4 surrogate conditions.
band_conditions <- list(
  strong = list(tau_s = 0.4),
  moderate = list(tau_s = 0.8),
  weak = list(tau_s = 1.6),
  locally_failed = list(tau_s = 0.8, m_local_reversal = TRUE)
)
for (pval in c(0.05, 0.10, 0.20)) {
  for (v in c("R1", "R2")) {
    for (cond in names(band_conditions)) {
      spec <- band_conditions[[cond]]
      args <- list(id = paste0("B_p", format(pval, nsmall = 2), "_", v, "_",
                               cond),
                   module = "bands", M = 2000, p = pval, x0 = 0, h = 0.30,
                   verification = v, target = "F_h",
                   level = "C_secondary")
      args[names(spec)] <- spec
      rows[[length(rows) + 1L]] <- do.call(scenario_row, args)
    }
  }
}

# WP7 estimated-propensity exploratory scenarios.
for (pval in c(0.10, 0.20)) {
  for (pi_mod in c("P1", "P2")) {
    for (fam in c("full", "misspecified")) {
      rows[[length(rows) + 1L]] <- scenario_row(
        id = paste0("PP_p", format(pval, nsmall = 2), "_", pi_mod, "_",
                    fam),
        module = "propensity", M = 2000, p = pval, x0 = 0,
        h = h_bw(2000), tau_s = 0.8, verification = "R1", target = "F0",
        q_family = fam, m_family = fam, pi_mode = "estimated",
        level = "C_secondary", pi_model = pi_mod
      )
    }
  }
}

# WP8 supplementary: discrete, 2D, bandwidth and floor sensitivity.
rows[[length(rows) + 1L]] <- scenario_row(
  id = "D_R1_p10", module = "supplementary", M = 2000, p = 0.10,
  x0 = 0, h = h_bw(2000), tau_s = 0.8, verification = "R1", target = "F0",
  discrete = TRUE, level = "C_secondary"
)
for (mv in c(2000, 5000)) {
  for (pval in c(0.10, 0.20)) {
    rows[[length(rows) + 1L]] <- scenario_row(
      id = paste0("X2D_M", mv, "_p", format(pval, nsmall = 2)),
      module = "supplementary_2d", M = mv, p = pval, x0 = 0,
      h = simulation_dgp$h_2d(mv), tau_s = 0.8, verification = "R1",
      target = "F0", d = 2, level = "C_2d"
    )
  }
}
for (hv in c(0.225, 0.30, 0.375)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("BW_M2_h", format(hv, nsmall = 3)), module = "oracle_mechanism",
    M = 4000, p = 0.10, x0 = 0, h = hv, tau_s = 0.8, verification = "R1",
    target = "F_h", m_scenario = "M2", q_learner = "oracle",
    m_learner = "oracle", level = "C_secondary"
  )
}
for (fl in c(1e-6, 1e-4)) {
  rows[[length(rows) + 1L]] <- scenario_row(
    id = paste0("DF_F2_floor", format(fl, scientific = TRUE)),
    module = "feasible", M = 2000, p = 0.10, x0 = 0, h = h_bw(2000),
    tau_s = 0.8, verification = "R1", target = "F0",
    lambda_floor = fl, level = "C_secondary"
  )
}

manifest <- do.call(rbind, rows)
manifest$m_scenario[is.na(manifest$m_scenario)] <- "none"
manifest$q_family[is.na(manifest$q_family)] <- ""
manifest$m_family[is.na(manifest$m_family)] <- ""
manifest$train_tau_s[is.na(manifest$train_tau_s)] <- ""
write.csv(manifest, file.path(root, "simulation", "config",
                              "scenario_manifest.csv"),
          row.names = FALSE)
cat("Wrote", nrow(manifest), "scenarios.\n")
