# Frozen constants from docs/SIMULATION_AGENT_PROTOCOL.md (version 1.0).
simulation_master_seed <- 20260811L
simulation_implementation_version <- "salcdi-canonical-p0d-v2"

simulation_dgp <- list(
  x0_primary = 0,
  x0_additional = c(-0.5, 0.5),
  tau_s_values = c(0.4, 0.8, 1.6),
  h_mechanism = 0.30,
  h_bandwidth = function(M) M^(-1/5),
  h_2d = function(M) M^(-1/6)
)

simulation_threshold_levels <- 0.02 + 0.0096 * (0:100)
simulation_kernel <- "epanechnikov"
simulation_truth_n <- 1e6
simulation_truth_n_smoke <- 2e5
simulation_fitted_oracle_n <- 5000L
simulation_reps <- c(
  A = 20L,
  B = 200L,
  C_primary = 2000L,
  C_secondary = 1000L,
  C_2d = 500L
)
simulation_lambda_floor <- 1e-8
simulation_lambda_floors <- c(1e-8, 1e-6, 1e-4)
simulation_cv_grid <- seq(0, 1, by = 0.2)
simulation_boot_b <- 4999L
simulation_boot_level <- 0.95
simulation_tail_fraction <- 0.2
simulation_q_levels <- c(0.10, 0.50, 0.90)
simulation_eps <- 1e-6
simulation_discrete_cuts <- qnorm(1:9 / 10)

simulation_source_files <- function() {
  c("config/simulation_constants.R",
    "R/dgp.R",
    "R/verification_design.R",
    "R/truth_engine.R",
    "R/nuisance_gaussian.R",
    "R/nuisance_knn.R",
    "R/borrowing_estimators.R",
    "R/metrics.R",
    "R/bootstrap_bands.R",
    "R/band_runner.R",
    "R/runner.R",
    "R/qc.R")
}

source_simulation_environment <- function(root) {
  files <- file.path(root, "simulation", simulation_source_files())
  invisible(lapply(files, source))
}
