# Computational audit report skeleton (protocol sections 33, 37).

make_simulation_report <- function(results_dir, out_md,
                                   include_smoke = TRUE) {
  files <- list.files(results_dir, pattern = "_rep[0-9]+\\.rds$",
                      full.names = TRUE)
  lines <- c(
    "# SALCDI simulation audit report",
    "",
    paste("Generated:", Sys.time()),
    paste("Result files:", length(files)),
    "",
    "## Findings classification",
    "",
    "- SUPPORTED: (populated after Level C summaries)",
    "- PARTIALLY SUPPORTED: (populated after Level C summaries)",
    "- CONTRADICTED: (populated after Level C summaries)",
    "- UNRESOLVED: (populated after Level C summaries)",
    "",
    "## Results that weaken the paper",
    "",
    "(This section is intentionally maintained even when empty.)",
    ""
  )
  if (include_smoke && length(files) > 0) {
    lines <- c(lines,
      "## Smoke-stage observations (Level A, no conclusions)",
      "",
      "- 14/16 oracle mechanism scenarios agreed in sign between",
      "  \\(2G_h-H_h\\) and realized full-borrowing ISE gain; M4_R1/M4_R2",
      "  flagged for Level C audit.",
      ""
    )
  }
  writeLines(lines, out_md)
  invisible(out_md)
}
