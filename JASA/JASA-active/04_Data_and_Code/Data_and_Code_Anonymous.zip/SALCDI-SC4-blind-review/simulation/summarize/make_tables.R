#!/usr/bin/env Rscript

# Build the four registered simulation tables directly from the largest
# available replication file for each frozen scenario. Smaller smoke and
# intermediate runs are deliberately ignored.

replication_count <- function(path) {
  value <- sub(".*_rep([0-9]+)[.]rds$", "\\1", basename(path))
  suppressWarnings(as.integer(value))
}

latest_scenario_files <- function(root) {
  selector_path <- file.path(root, "simulation", "summarize",
                             "result_selector.R")
  selector_env <- new.env(parent = environment())
  sys.source(selector_path, envir = selector_env)
  selected <- selector_env$select_final_result_files(root)
  list(manifest = selected$manifest, files = selected$registry$path)
}

load_frozen_results <- function(root) {
  selected <- latest_scenario_files(root)
  objects <- lapply(selected$files, readRDS)
  bad <- !vapply(objects, is.data.frame, logical(1L))
  if (any(bad)) {
    stop("Non-data-frame simulation output: ", selected$files[[which(bad)[1L]]],
         call. = FALSE)
  }
  all_names <- unique(unlist(lapply(objects, names), use.names = FALSE))
  objects <- lapply(objects, function(x) {
    missing <- setdiff(all_names, names(x))
    for (name in missing) x[[name]] <- NA
    x[, all_names, drop = FALSE]
  })
  result <- do.call(rbind, objects)
  result$module <- selected$manifest$module[
    match(result$scenario_id, selected$manifest$scenario_id)
  ]
  list(data = result, manifest = selected$manifest, files = selected$files)
}

wide_metric <- function(data, metric) {
  formula <- stats::as.formula(paste(metric, "~ scenario_id + method"))
  aggregated <- aggregate(formula, data = data, FUN = mean, na.rm = TRUE)
  reshape(
    aggregated, idvar = "scenario_id", timevar = "method",
    direction = "wide"
  )
}

make_oracle_table <- function(data) {
  keep <- grepl("^M[1-8]_R[12](_unclip)?$", data$scenario_id)
  d <- data[keep, ]
  lambda_draws <- unique(d[
    d$method == "Adaptive",
    c("scenario_id", "replicate", "lambda_hat"),
    drop = FALSE
  ])
  if (anyDuplicated(lambda_draws[, c("scenario_id", "replicate")]) ||
      any(!is.finite(lambda_draws$lambda_hat))) {
    stop("Oracle borrowing draws are not unique and finite by replication.",
         call. = FALSE)
  }
  lambda_distribution <- do.call(
    rbind,
    lapply(split(lambda_draws, lambda_draws$scenario_id), function(x) {
      data.frame(
        scenario_id = x$scenario_id[[1L]],
        lambda_mean_from_replications = mean(x$lambda_hat),
        lambda_q10 = unname(stats::quantile(
          x$lambda_hat, probs = 0.10, type = 7L
        )),
        lambda_q90 = unname(stats::quantile(
          x$lambda_hat, probs = 0.90, type = 7L
        )),
        lambda_replications = nrow(x),
        stringsAsFactors = FALSE
      )
    })
  )
  mechanism <- aggregate(
    cbind(G_true, H_true, transfer_signal, lambda_star, lambda_hat) ~ scenario_id,
    data = d, FUN = mean, na.rm = TRUE
  )
  risk <- wide_metric(d, "ise")
  result <- Reduce(
    function(x, y) merge(x, y, by = "scenario_id", all.x = TRUE),
    list(mechanism, risk, lambda_distribution)
  )
  if (!isTRUE(all.equal(
    result$lambda_hat,
    result$lambda_mean_from_replications,
    tolerance = 1e-14
  ))) {
    stop("Oracle borrowing means disagree after replicate de-duplication.",
         call. = FALSE)
  }
  result$lambda_mean_from_replications <- NULL
  result$realized_gain <- result$ise.X_anchor - result$ise.Full
  result <- result[, c(
    "scenario_id", "G_true", "H_true", "transfer_signal", "lambda_star",
    "lambda_hat", "lambda_q10", "lambda_q90", "lambda_replications",
    "realized_gain"
  )]
  result[order(result$scenario_id), ]
}

make_feasible_table <- function(data) {
  keep <- grepl("^(F1_|F2_|F3_)", data$scenario_id)
  d <- data[keep, ]
  risk <- wide_metric(d, "ise")
  negative_transfer <- wide_metric(d, "negative_transfer")
  coefficient <- aggregate(lambda_hat ~ scenario_id, d, mean, na.rm = TRUE)
  result <- Reduce(
    function(x, y) merge(x, y, by = "scenario_id", all = TRUE),
    list(risk, negative_transfer, coefficient)
  )
  result$relative_gain_percent <-
    100 * (result$ise.X_anchor - result$ise.Adaptive) / result$ise.X_anchor
  result <- result[, c(
    "scenario_id", "ise.X_anchor", "ise.Adaptive", "ise.Full",
    "relative_gain_percent", "lambda_hat", "negative_transfer.Adaptive",
    "negative_transfer.Full"
  )]
  result[order(result$scenario_id), ]
}

make_scarcity_table <- function(data) {
  d <- data[data$module == "scarcity", ]
  d$local_information_rate_index <- d$M * d$p * d$h
  d$scaled_ise <- d$ise * d$local_information_rate_index
  aggregated <- aggregate(
    scaled_ise ~ scenario_id + M + p + local_information_rate_index + method,
    d, mean, na.rm = TRUE
  )
  result <- reshape(
    aggregated,
    idvar = c("scenario_id", "M", "p", "local_information_rate_index"),
    timevar = "method", direction = "wide"
  )
  result <- result[, c(
    "scenario_id", "M", "p", "local_information_rate_index",
    "scaled_ise.X_anchor", "scaled_ise.Adaptive"
  )]
  result[order(result$local_information_rate_index, result$M, result$p), ]
}

make_band_table <- function(data) {
  d <- data[data$module == "bands", ]
  aggregated <- aggregate(
    cbind(simultaneous_coverage, integrated_band_width) ~ scenario_id + method,
    d, mean, na.rm = TRUE
  )
  result <- reshape(
    aggregated, idvar = "scenario_id", timevar = "method", direction = "wide"
  )
  result$p <- as.numeric(sub("^B_p([0-9.]+)_.*$", "\\1", result$scenario_id))
  result$verification <- sub("^B_p[0-9.]+_(R[12])_.*$", "\\1", result$scenario_id)
  result$condition <- sub("^B_p[0-9.]+_R[12]_", "", result$scenario_id)
  result <- result[, c(
    "scenario_id", "p", "verification", "condition",
    "simultaneous_coverage.Adaptive", "simultaneous_coverage.X_anchor",
    "integrated_band_width.Adaptive", "integrated_band_width.X_anchor"
  )]
  condition_order <- match(
    result$condition, c("strong", "moderate", "weak", "locally_failed")
  )
  result[order(result$p, result$verification, condition_order), ]
}

make_vanishing_table <- function(data) {
  d <- data[data$module == "vanishing_curvature", ]
  mechanism <- aggregate(
    cbind(G_true, H_true, lambda_hat) ~ scenario_id + candidate_scale,
    d, mean, na.rm = TRUE
  )
  risk <- wide_metric(d, "ise")
  result <- merge(mechanism, risk, by = "scenario_id", all.x = TRUE)
  result$effective_correction_scale <- result$candidate_scale * result$lambda_hat
  result$adaptive_oracle_ise_gap <- result$ise.Adaptive - result$ise.Oracle_lambda
  max_curvature <- max(result$H_true)
  result$relative_curvature <- if (max_curvature > 0) {
    result$H_true / max_curvature
  } else {
    0
  }
  result <- result[, c(
    "scenario_id", "candidate_scale", "G_true", "H_true", "relative_curvature",
    "lambda_hat", "effective_correction_scale", "adaptive_oracle_ise_gap"
  )]
  result[order(result$candidate_scale), ]
}

make_headline_table <- function(data) {
  design <- data.frame(
    scenario_id = c(
      "F1_p0.05", "F1_p0.10", "F1_p0.20",
      "F2_t4", "F2_t8", "F2_t16",
      "F3_M1000", "F3_M4000", "N5"
    ),
    contrast = c(
      rep("Reference fraction", 3L), rep("Surrogate noise", 3L),
      rep("Sample size", 2L), "Local reversal"
    ),
    setting = c(
      "$p_M=0.05$", "$p_M=0.10$", "$p_M=0.20$",
      "$\\tau_S=0.4$", "$\\tau_S=0.8$", "$\\tau_S=1.6$",
      "$M=1{,}000$", "$M=4{,}000$", "N5"
    ),
    row_order = seq_len(9L),
    stringsAsFactors = FALSE
  )
  d <- data[data$scenario_id %in% design$scenario_id, ]
  risk <- wide_metric(d, "ise")
  negative_transfer <- wide_metric(d, "negative_transfer")
  coefficient <- aggregate(lambda_hat ~ scenario_id, d, mean, na.rm = TRUE)
  result <- Reduce(
    function(x, y) merge(x, y, by = "scenario_id", all = TRUE),
    list(design, risk, negative_transfer, coefficient)
  )
  result$relative_gain_percent <-
    100 * (result$ise.X_anchor - result$ise.Adaptive) / result$ise.X_anchor
  result <- result[, c(
    "scenario_id", "contrast", "setting", "ise.X_anchor", "ise.Full",
    "ise.Adaptive", "relative_gain_percent", "lambda_hat",
    "negative_transfer.Adaptive", "negative_transfer.Full", "row_order"
  )]
  result[order(result$row_order), ]
}

build_simulation_tables <- function(root = ".") {
  loaded <- load_frozen_results(root)
  list(
    oracle = make_oracle_table(loaded$data),
    feasible = make_feasible_table(loaded$data),
    scarcity = make_scarcity_table(loaded$data),
    bands = make_band_table(loaded$data),
    vanishing = make_vanishing_table(loaded$data),
    headline = make_headline_table(loaded$data),
    source_files = loaded$files
  )
}

format_fixed <- function(x, digits) {
  formatC(x, digits = digits, format = "f")
}

scenario_label <- function(x) {
  gsub("_", "-", x, fixed = TRUE)
}

write_latex_table <- function(path, caption, label, alignment, headers, rows,
                              resize = FALSE) {
  lines <- c(
    "\\begin{table}[p]", "\\centering", paste0("\\caption{", caption, "}"),
    paste0("\\label{", label, "}")
  )
  if (resize) lines <- c(lines, "\\resizebox{\\textwidth}{!}{%")
  lines <- c(
    lines, paste0("\\begin{tabular}{", alignment, "}"), "\\toprule",
    paste0(paste(headers, collapse = " & "), " \\\\"), "\\midrule",
    paste0(apply(rows, 1L, paste, collapse = " & "), " \\\\"),
    "\\bottomrule", "\\end{tabular}"
  )
  if (resize) lines <- c(lines, "}")
  writeLines(c(lines, "\\end{table}"), path, useBytes = TRUE)
}

write_simulation_tables <- function(root = ".", output_dir = NULL,
                                    write_csv = TRUE) {
  if (is.null(output_dir)) {
    output_dir <- file.path(root, "simulation", "output", "tables")
  }
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  tables <- build_simulation_tables(root)

  csv_tables <- list(
    table1_oracle_mechanism = tables$oracle,
    table2_feasible = tables$feasible,
    table3_scarcity = tables$scarcity,
    table4_bands = tables$bands
  )
  if (isTRUE(write_csv)) {
    for (name in names(csv_tables)) {
      write.csv(
        csv_tables[[name]], file.path(output_dir, paste0(name, ".csv")),
        row.names = FALSE, na = ""
      )
    }
  }

  t1 <- tables$oracle
  write_latex_table(
    file.path(output_dir, "table1_oracle_mechanism.tex"),
    "Oracle mechanism results. The realized gain is anchor ISE minus full-borrowing ISE.",
    "tab:sim-oracle", "lcccccc",
    c("Scenario", "$G_h$", "$H_h$", "$2G_h-H_h$", "$\\lambda_h^{\\mathrm{or}}$",
      "$E(\\widehat\\lambda_h)$", "Realized gain"),
    cbind(
      scenario_label(t1$scenario_id), format_fixed(t1$G_true, 3L),
      format_fixed(t1$H_true, 3L), format_fixed(t1$transfer_signal, 3L),
      format_fixed(t1$lambda_star, 3L), format_fixed(t1$lambda_hat, 3L),
      format_fixed(t1$realized_gain, 3L)
    )
  )

  t2 <- tables$feasible
  write_latex_table(
    file.path(output_dir, "table2_feasible.tex"),
    "Feasible estimator results. Relative gain is the percentage reduction in mean ISE from the X-anchor.",
    "tab:sim-feasible", "lccccccc",
    c("Scenario", "ISE anchor", "ISE Adaptive", "ISE Full", "Rel. gain",
      "$\\widehat\\lambda_h$", "NT Adaptive", "NT Full"),
    cbind(
      scenario_label(t2$scenario_id), format_fixed(t2$ise.X_anchor, 4L),
      format_fixed(t2$ise.Adaptive, 4L), format_fixed(t2$ise.Full, 4L),
      format_fixed(t2$relative_gain_percent, 1L), format_fixed(t2$lambda_hat, 3L),
      format_fixed(t2$negative_transfer.Adaptive, 3L),
      format_fixed(t2$negative_transfer.Full, 3L)
    ),
    resize = TRUE
  )

  t3 <- tables$scarcity
  write_latex_table(
    file.path(output_dir, "table3_scarcity.tex"),
    "Scarce-reference scaling: ISE times the local-information rate index.",
    "tab:sim-scarcity", "lccccc",
    c("Scenario", "$M$", "$p_M$", "$Mp_Mh$", "X-anchor", "Adaptive"),
    cbind(
      scenario_label(t3$scenario_id), as.character(t3$M), format_fixed(t3$p, 3L),
      format_fixed(t3$local_information_rate_index, 1L),
      format_fixed(t3$scaled_ise.X_anchor, 3L),
      format_fixed(t3$scaled_ise.Adaptive, 3L)
    )
  )

  t4 <- tables$bands
  coverage_values <- c(
    t4$simultaneous_coverage.Adaptive,
    t4$simultaneous_coverage.X_anchor
  )
  coverage_mcse <- sqrt(coverage_values * (1 - coverage_values) / 1000)
  band_caption <- paste(
    "Raw-process multiplier-band coverage and width (target 0.95). Each cell",
    "uses 1,000 replications and 4,999 multiplier draws. Here $M=2{,}000$",
    "and $h=0.30$, so $Mp_Mh=30,60,120$; coverage Monte Carlo standard",
    paste0(
      "errors across both methods range from ",
      formatC(min(coverage_mcse), digits = 4L, format = "f"), " to ",
      formatC(max(coverage_mcse), digits = 4L, format = "f"), "."
    )
  )
  write_latex_table(
    file.path(output_dir, "table4_bands.tex"),
    band_caption,
    "tab:sim-bands", "lllcccc",
    c("$p$", "Ver.", "Condition", "Cov. Adaptive", "Cov. anchor",
      "Width Adaptive", "Width anchor"),
    cbind(
      format_fixed(t4$p, 2L), t4$verification,
      gsub("_", " ", t4$condition, fixed = TRUE),
      format_fixed(t4$simultaneous_coverage.Adaptive, 3L),
      format_fixed(t4$simultaneous_coverage.X_anchor, 3L),
      format_fixed(t4$integrated_band_width.Adaptive, 3L),
      format_fixed(t4$integrated_band_width.X_anchor, 3L)
    )
  )

  invisible(csv_tables)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  root <- if (length(args) >= 1L) args[[1L]] else "."
  output_dir <- if (length(args) >= 2L) args[[2L]] else NULL
  write_simulation_tables(root, output_dir)
}
