#!/usr/bin/env Rscript

stop(
  "`simulation/summarize/make_all_outputs.R` is retired because it created a ",
  "second numerical evidence chain and contained pre-fix narrative values. ",
  "Use `reproducibility/build_manuscript_evidence.R`, which loads only the ",
  "versioned canonical result registry.",
  call. = FALSE
)
