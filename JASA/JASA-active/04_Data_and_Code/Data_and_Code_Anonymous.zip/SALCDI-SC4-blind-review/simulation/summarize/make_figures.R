# Primary protocol figures (base graphics; smoke/final versions).

plot_transfer_signal <- function(results_dir, manifest, out_png) {
  files <- list.files(results_dir, pattern = "_rep[0-9]+\\.rds$",
                      full.names = TRUE)
  files <- files[!grepl("_band_rep", files)]
  df <- do.call(rbind, lapply(files, readRDS))
  module_map <- vapply(manifest, function(s) s$scenario_id, character(1))
  module_map <- setNames(vapply(manifest, function(s) s$module, character(1)),
                         module_map)
  df$module <- unname(module_map[df$scenario_id])
  mech <- df[df$module == "oracle_mechanism" &
               df$method %in% c("X_anchor", "Full"), ]
  gain <- aggregate(ise ~ scenario_id, data = mech, FUN = function(x) {
    anchor <- x[seq(1, length(x), by = 2)]
    full <- x[seq(2, length(x), by = 2)]
    mean(anchor - full)
  })
  sig <- unique(mech[, c("scenario_id", "transfer_signal")])
  plot_df <- merge(gain, sig, by = "scenario_id")
  png(out_png, width = 6, height = 5, units = "in", res = 150)
  plot(plot_df$transfer_signal, plot_df$ise, pch = 19,
       xlab = "2G - H (transfer signal)",
       ylab = "Average ISE gain of Full vs X_anchor",
       main = "Figure S1: negative-transfer criterion")
  abline(h = 0, lty = 2)
  abline(v = 0, lty = 2)
  dev.off()
  invisible(plot_df)
}
