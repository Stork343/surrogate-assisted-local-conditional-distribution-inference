# Canonical final-object selector. Checkpoints are never pooled.

level_replications <- function(level) {
  switch(
    as.character(level),
    C_primary = 2000L,
    C_secondary = 1000L,
    C_2d = 500L,
    stop("Unknown simulation level `", level, "`.", call. = FALSE)
  )
}

canonical_implementation_version <- function(root = ".") {
  constants_path <- file.path(root, "simulation", "config",
                              "simulation_constants.R")
  if (!file.exists(constants_path)) {
    stop("Simulation constants are missing.", call. = FALSE)
  }
  constants <- new.env(parent = globalenv())
  sys.source(constants_path, envir = constants)
  constants$simulation_implementation_version
}

canonical_multiplier_draws <- function(root = ".") {
  constants_path <- file.path(root, "simulation", "config",
                              "simulation_constants.R")
  constants <- new.env(parent = globalenv())
  sys.source(constants_path, envir = constants)
  as.integer(constants$simulation_boot_b)
}

validate_final_result_object <- function(path, scenario_id,
                                         expected_replications,
                                         implementation_version,
                                         expected_multiplier_draws = NULL) {
  object <- tryCatch(readRDS(path), error = function(e) NULL)
  required <- c("implementation_version", "scenario_id", "replicate")
  if (!is.data.frame(object) || !all(required %in% names(object))) {
    stop("Final object `", basename(path),
         "` lacks the canonical provenance fields.", call. = FALSE)
  }
  if (!identical(unique(object$implementation_version),
                 implementation_version)) {
    stop("Final object `", basename(path), "` has implementation version `",
         paste(unique(object$implementation_version), collapse = ","),
         "`; expected `", implementation_version, "`.", call. = FALSE)
  }
  if (!identical(unique(as.character(object$scenario_id)), scenario_id)) {
    stop("Scenario identifier mismatch in `", basename(path), "`.",
         call. = FALSE)
  }
  replications <- sort(unique(object$replicate[!is.na(object$replicate)]))
  if (!identical(replications, seq_len(as.integer(expected_replications)))) {
    stop("Final object `", basename(path), "` does not contain exactly ",
         expected_replications, " registered replications.", call. = FALSE)
  }
  if (!is.null(expected_multiplier_draws)) {
    band_required <- c(
      "band_result_version", "multiplier_seed", "multiplier_draws",
      "band_construction", "verified_support_min_fold"
    )
    if (!all(band_required %in% names(object)) ||
        !identical(unique(object$band_result_version),
                   "salcdi-band-repro-v1") ||
        !identical(unique(object$multiplier_draws),
                   as.integer(expected_multiplier_draws)) ||
        !identical(unique(object$band_construction),
                   "unstudentized_raw_supremum")) {
      stop("Final band object `", basename(path),
           "` lacks the frozen resampling schema.", call. = FALSE)
    }
  }
  invisible(object)
}

select_final_result_files <- function(root = ".", validate_objects = TRUE) {
  manifest_path <- file.path(root, "simulation", "config",
                             "scenario_manifest.csv")
  output_dir <- file.path(root, "simulation", "output")
  if (!file.exists(manifest_path) || !dir.exists(output_dir)) {
    stop("Simulation manifest or output directory is missing.", call. = FALSE)
  }
  manifest <- read.csv(manifest_path, stringsAsFactors = FALSE)
  implementation_version <- canonical_implementation_version(root)
  multiplier_draws <- canonical_multiplier_draws(root)
  level_files <- character()
  band_files <- character()
  registry <- vector("list", nrow(manifest))
  for (i in seq_len(nrow(manifest))) {
    id <- manifest$scenario_id[[i]]
    replications <- level_replications(manifest$level[[i]])
    is_band <- identical(manifest$module[[i]], "bands")
    basename_expected <- if (is_band) {
      paste0(id, "_band_rep", replications, ".rds")
    } else {
      paste0(id, "_rep", replications, ".rds")
    }
    matches <- list.files(
      output_dir, full.names = TRUE, recursive = FALSE
    )
    matches <- matches[basename(matches) == basename_expected]
    if (length(matches) != 1L) {
      stop(
        "Scenario `", id, "` must have exactly one final Level C object named `",
        basename_expected, "`; found ", length(matches), ".",
        call. = FALSE
      )
    }
    if (isTRUE(validate_objects)) {
      validate_final_result_object(
        matches[[1L]], id, replications, implementation_version,
        expected_multiplier_draws = if (is_band) multiplier_draws else NULL
      )
    }
    if (is_band) band_files <- c(band_files, matches) else
      level_files <- c(level_files, matches)
    registry[[i]] <- data.frame(
      scenario_id = id,
      module = manifest$module[[i]],
      level = manifest$level[[i]],
      replications = replications,
      implementation_version = implementation_version,
      path = matches,
      stringsAsFactors = FALSE
    )
  }
  list(
    level = level_files,
    band = band_files,
    registry = do.call(rbind, registry),
    manifest = manifest
  )
}
