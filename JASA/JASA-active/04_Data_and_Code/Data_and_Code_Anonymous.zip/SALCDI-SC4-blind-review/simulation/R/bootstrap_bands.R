# Multiplier simultaneous bands from canonical fold-specific influence values.

multiplier_band <- function(
    influence, center, p, h, dimension = 1L,
    n_boot = simulation_boot_b, level = simulation_boot_level,
    seed = 1L, cluster = NULL) {
  result <- salcdi_multiplier_band(
    influence = influence,
    center = center,
    p = p,
    h = h,
    dimension = dimension,
    n_boot = n_boot,
    level = level,
    seed = seed,
    cluster = cluster
  )
  list(
    f_hat = result$center,
    band_low = result$band_low,
    band_high = result$band_high,
    critical_value = result$critical_value,
    band_low_mono = result$band_low_rearranged,
    band_high_mono = result$band_high_rearranged,
    half_width = result$half_width,
    n_boot = result$n_boot,
    level = result$level,
    seed = result$seed,
    construction = result$construction
  )
}
