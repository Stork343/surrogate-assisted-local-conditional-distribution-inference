# K-nearest-neighbor conditional CDF learner (protocol section 12, L3).

knn_indices <- function(x_tr, x_te, k) {
  k <- min(k, nrow(x_tr))
  d2 <- apply(x_te, 1, function(z) colSums((t(x_tr) - z)^2))
  t(apply(d2, 2, order))[, seq_len(k), drop = FALSE]
}

knn_cdf_predict <- function(x_tr, y_tr, x_te, k, tau, obs_weights = NULL) {
  idx <- knn_indices(x_tr, x_te, k)
  if (is.null(obs_weights)) obs_weights <- rep(1, length(y_tr))
  t(apply(idx, 1, function(nb) {
    vapply(tau, function(threshold) {
      weighted.mean(y_tr[nb] <= threshold, obs_weights[nb])
    }, numeric(1L))
  }))
}

knn_mean <- function(x_tr, y_tr, x_te, k, obs_weights = NULL) {
  idx <- knn_indices(x_tr, x_te, k)
  if (is.null(obs_weights)) obs_weights <- rep(1, length(y_tr))
  apply(idx, 1L, function(nb) weighted.mean(y_tr[nb], obs_weights[nb]))
}

select_k <- function(x_std, y, k_candidates, obs_weights = NULL) {
  n <- length(y)
  if (is.null(obs_weights)) obs_weights <- rep(1, n)
  folds <- ((seq_len(n) - 1L) %% 5L) + 1L
  err <- vapply(k_candidates, function(k) {
    if (k >= n) {
      return(Inf)
    }
    mean(vapply(seq_len(5L), function(f) {
      test <- folds == f
      train <- !test
      pred <- knn_mean(
        x_std[train, , drop = FALSE], y[train],
        x_std[test, , drop = FALSE], k, obs_weights[train]
      )
      weighted.mean((y[test] - pred)^2, obs_weights[test])
    }, numeric(1)))
  }, numeric(1))
  k_candidates[which.min(err)]
}

fit_knn_q <- function(y, x, s, r, pi = NULL,
                      k_candidates = c(25, 50, 100)) {
  x <- as.matrix(x)
  idx <- which(r == 1)
  x_tr <- x[idx, , drop = FALSE]
  y_tr <- y[idx]
  fit_weights <- if (is.null(pi)) rep(1, length(idx)) else 1 / pi[idx]
  if (length(idx) < 5L) {
    mu_const <- if (length(y_tr)) weighted.mean(y_tr, fit_weights) else 0
    sd_const <- if (length(y_tr) >= 2L) weighted_sd(y_tr, fit_weights) else 1
    return(list(predict = function(tau, xnew) {
      constant_predictor(tau, xnew, mu_const, sd_const)
    }, k = NA_integer_, uses_ipw = !is.null(pi)))
  }
  center <- colMeans(x_tr)
  scale <- apply(x_tr, 2L, stats::sd)
  scale[scale == 0] <- 1
  x_std <- sweep(sweep(x_tr, 2L, center, "-"), 2L, scale, "/")
  k_best <- select_k(x_std, y_tr, k_candidates, fit_weights)
  list(predict = function(tau, xnew) {
    xnew <- as.matrix(xnew)
    x_new_std <- sweep(sweep(xnew, 2L, center, "-"), 2L, scale, "/")
    knn_cdf_predict(x_std, y_tr, x_new_std, k_best, tau, fit_weights)
  }, k = k_best, uses_ipw = !is.null(pi))
}

fit_knn_m <- function(y, x, s, r, pi = NULL,
                      k_candidates = c(25, 50, 100)) {
  x <- as.matrix(x)
  idx <- which(r == 1)
  x_tr <- cbind(x[idx, , drop = FALSE], s = s[idx])
  y_tr <- y[idx]
  if (length(idx) < 5L) {
    mu_const <- if (length(y_tr)) mean(y_tr) else 0
    sd_const <- if (length(y_tr) >= 2L) stats::sd(y_tr) else 1
    return(list(predict = function(tau, xnew, snew) {
      constant_predictor(tau, xnew, mu_const, sd_const)
    }, k = NA_integer_, uses_ipw = FALSE))
  }
  center <- colMeans(x_tr)
  scale <- apply(x_tr, 2L, stats::sd)
  scale[scale == 0] <- 1
  x_std <- sweep(sweep(x_tr, 2L, center, "-"), 2L, scale, "/")
  k_best <- select_k(x_std, y_tr, k_candidates)
  list(predict = function(tau, xnew, snew) {
    xnew <- as.matrix(xnew)
    x_new_std <- cbind(xnew, s = as.numeric(snew))
    x_new_std <- sweep(sweep(x_new_std, 2L, center, "-"), 2L, scale, "/")
    knn_cdf_predict(x_std, y_tr, x_new_std, k_best, tau)
  }, k = k_best, uses_ipw = FALSE)
}
