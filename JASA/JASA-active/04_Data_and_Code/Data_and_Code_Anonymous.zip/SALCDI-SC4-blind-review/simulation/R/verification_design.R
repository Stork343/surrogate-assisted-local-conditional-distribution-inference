# Reference-observation mechanisms (protocol section 6).

z_moments <- function(tau_s) {
  mean_s <- 0.2
  var_mu <- 0.512
  e_sigma2 <- 0.7858333333
  var_s <- var_mu + e_sigma2 + tau_s^2
  c(mean_s = mean_s, sd_s = sqrt(var_s),
    mean_x2 = 1 / 3, sd_x2 = sqrt(2 / 45))
}

e0_calibration_constant <- local({
  cache <- new.env(parent = emptyenv())
  function(tau_s, lower = 0.5, upper = 1.5, target = 1, n = 200000L,
           seed = 20260811L, tolerance = 1e-12) {
    key <- paste(format(tau_s, digits = 17), lower, upper, target, n, sep = "|")
    if (!is.null(cache[[key]])) return(cache[[key]])

    if (!is.finite(target) || target < lower || target > upper) {
      stop("`target` must lie in [`lower`, `upper`].", call. = FALSE)
    }
    if (!is.finite(lower) || !is.finite(upper) || lower < 0 ||
        upper <= lower) {
      stop("`lower` and `upper` must satisfy 0 <= lower < upper.", call. = FALSE)
    }

    had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    old_seed <- if (had_seed) {
      get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    } else {
      NULL
    }
    on.exit({
      if (had_seed) {
        assign(".Random.seed", old_seed, envir = .GlobalEnv)
      } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
        rm(".Random.seed", envir = .GlobalEnv)
      }
    }, add = TRUE)

    set.seed(seed, kind = "L'Ecuyer-CMRG")

    x <- matrix(runif(n, -1, 1), ncol = 1L)
    eps <- rnorm(n)
    eta <- rnorm(n)
    s <- dgp_mu(x) + dgp_sigma(x) * eps + tau_s * eta
    mom <- z_moments(tau_s)
    z_s <- (s - mom["mean_s"]) / mom["sd_s"]
    z_x2 <- (x[, 1L]^2 - mom["mean_x2"]) / mom["sd_x2"]
    raw <- exp(0.8 * z_s + 0.4 * z_x2)

    objective <- function(constant) {
      mean(pmin(pmax(constant * raw, lower), upper)) - target
    }
    if (abs(objective(0)) <= tolerance) {
      cache[[key]] <- 1
      return(1)
    }

    upper_constant <- 1 / min(raw)
    while (objective(upper_constant) < 0) {
      upper_constant <- 2 * upper_constant
    }
    constant <- stats::uniroot(objective, interval = c(0, upper_constant),
                              tol = tolerance)$root

    calibrated <- pmin(pmax(constant * raw, lower), upper)
    if (abs(target - mean(calibrated)) > 10 * tolerance) {
      stop("Bounded-intensity calibration did not reach the target mean.",
           call = FALSE)
    }
    cache[[key]] <- constant
    constant
  }
})

verification_e0 <- function(x, s, tau_s, design, x0 = 0, h = 0.3) {
  x <- as.matrix(x)
  design <- match.arg(design, c("R1", "R2", "R3", "scarcity"))
  if (design == "R1") {
    return(rep(1, nrow(x)))
  }
  if (design %in% c("R2", "scarcity")) {
    mom <- z_moments(tau_s)
    z_s <- (s - mom["mean_s"]) / mom["sd_s"]
    z_x2 <- (x[, 1L]^2 - mom["mean_x2"]) / mom["sd_x2"]
    raw <- exp(0.8 * z_s + 0.4 * z_x2)
    c_calib <- e0_calibration_constant(tau_s, lower = 0.5, upper = 1.5,
                                       target = 1)
    return(pmin(pmax(c_calib * raw, 0.5), 1.5))
  }
  inside <- abs(x[, 1L] - x0) <= h
  p_in <- mean(pmax(0, pmin(1, x0 + h) - pmax(-1, x0 - h)) / 2)
  c_out <- (1 - 0.25 * p_in) / (1 - p_in)
  ifelse(inside, 0.25, c_out)
}

verification_pi <- function(x, s, tau_s, design, p, x0 = 0, h = 0.3) {
  pmin(p * verification_e0(x, s, tau_s, design, x0 = x0, h = h), 0.999)
}

propensity_logit <- function(x, s, tau_s, alpha) {
  x <- as.matrix(x)
  mom <- z_moments(tau_s)
  z_s <- (s - mom["mean_s"]) / mom["sd_s"]
  z_x2 <- (x[, 1L]^2 - mom["mean_x2"]) / mom["sd_x2"]
  plogis(alpha + 0.8 * z_s + 0.4 * z_x2)
}

alpha_for_fraction <- function(tau_s, p_target, n = 5e5) {
  f <- function(alpha) {
    set.seed(20260811L, kind = "L'Ecuyer-CMRG")
    x <- runif(n, -1, 1)
    eps <- rnorm(n)
    eta <- rnorm(n)
    s <- dgp_mu(x) + dgp_sigma(x) * eps + tau_s * eta
    mean(pmin(pmax(propensity_logit(x, s, tau_s, alpha), 0.03), 0.80)) - p_target
  }
  uniroot(f, interval = c(-6, 6))$root
}

propensity_alpha_cache <- local({
  cache <- new.env(parent = emptyenv())
  function(tau_s, p_target) {
    key <- paste(tau_s, p_target)
    if (is.null(cache[[key]])) {
      cache[[key]] <- alpha_for_fraction(tau_s, p_target)
    }
    cache[[key]]
  }
})

fit_propensity <- function(x, s, r, mode = c("P1", "P2")) {
  mode <- match.arg(mode)
  x <- as.matrix(x)
  center_s <- mean(s)
  scale_s <- stats::sd(s)
  center_x2 <- mean(x[, 1L]^2)
  scale_x2 <- stats::sd(x[, 1L]^2)
  center_x <- mean(x[, 1L])
  scale_x <- stats::sd(x[, 1L])
  z_s <- (s - center_s) / scale_s
  z_x2 <- (x[, 1L]^2 - center_x2) / scale_x2
  z_x <- (x[, 1L] - center_x) / scale_x
  d <- data.frame(r = r, z_s = z_s, z_x2 = z_x2, z_x = z_x)
  if (mode == "P1") {
    fit <- glm(r ~ z_s + z_x2, data = d, family = binomial)
  } else {
    fit <- glm(r ~ z_s + z_x, data = d, family = binomial)
  }
  list(predict = function(xnew, snew) {
    xnew <- as.matrix(xnew)
    z_s_new <- (snew - center_s) / scale_s
    z_x2_new <- (xnew[, 1L]^2 - center_x2) / scale_x2
    z_x_new <- (xnew[, 1L] - center_x) / scale_x
    if (mode == "P1") {
      nd <- data.frame(z_s = z_s_new, z_x2 = z_x2_new)
    } else {
      nd <- data.frame(z_s = z_s_new, z_x = z_x_new)
    }
    as.numeric(predict(fit, newdata = nd, type = "response"))
  })
}
