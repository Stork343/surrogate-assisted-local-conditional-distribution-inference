# Quality-control checks 1-12 (protocol section 34).

run_qc <- function(root, n = 2000, seed = 1) {
  checks <- list()
  set.seed(seed)

  u_levels <- seq(0.02, 0.98, length.out = 20)
  e <- sim_eps(1e6, "gaussian")
  checks$qc01 <- max(abs(ecdf(e)(qnorm(u_levels)) - u_levels)) < 0.01

  set.seed(seed + 1)
  x <- runif(1, -1, 1)
  s <- 0.5
  tau_s <- 0.8
  mu <- dgp_mu(x)
  sig2 <- dgp_sigma(x)^2
  kappa <- sig2 / (sig2 + tau_s^2)
  yc <- rnorm(2e5, mean = mu + kappa * (s - mu),
              sd = sqrt(sig2 * (1 - kappa)))
  tau <- as.numeric(quantile(yc, c(0.1, 0.5, 0.9)))
  m0_row <- truth_m0_matrix(matrix(x, 1), s, tau, tau_s)[1, ]
  checks$qc02 <- max(abs(ecdf(yc)(tau) - m0_row)) < 0.01

  set.seed(seed + 2)
  dat <- simulate_data(5e4, tau_s, 0, 0.3, "R1", 0.1)
  tau_g <- truth_thresholds(0, "gaussian")
  q0 <- truth_q0_matrix(dat$x, dat$s, tau_g, tau_s, "gaussian")
  z <- threshold_signals(dat$y, tau_g)
  u <- augment_fits(q0, z, dat$r, dat$pi)
  checks$qc03 <- max(abs(colMeans(u) - colMeans(q0))) < 0.05

  scenario_small <- list(scenario_id = "QC", M = 4000, p = 0.1, x0 = 0,
                         h = 0.3, tau_s = 0.8, verification = "R1",
                         error_dist = "gaussian", target = "F_h",
                         m_scenario = "M4", q_learner = "oracle",
                         m_learner = "oracle", lambda_floor = 1e-8,
                         pi_mode = "known", d = 1, module = "oracle_mechanism")
  gh <- truth_g_h(scenario_small, tau_g, 5e4)
  checks$qc04 <- gh$lambda_star >= 0 && gh$lambda_star <= 1

  q <- c(0.2, 0.4)
  m <- c(0.8, 0.6)
  checks$qc05 <- isTRUE(all.equal(salcdi_adaptive_borrow(q, m, 0), q))
  checks$qc06 <- isTRUE(all.equal(salcdi_adaptive_borrow(q, m, 1), m))

  set.seed(seed + 3)
  dat2 <- simulate_data(n, tau_s, 0, 0.3, "R1", 0.1)
  z2 <- threshold_signals(dat2$y, tau_g)
  a_zero <- matrix(0, nrow = n, ncol = length(tau_g))
  u_ipw <- augment_fits(a_zero, z2, dat2$r, dat2$pi)
  y_saved <- dat2$y
  dat2$y[dat2$r == 0] <- 999
  z2b <- threshold_signals(dat2$y, tau_g)
  u_ipw_b <- augment_fits(a_zero, z2b, dat2$r, dat2$pi)
  checks$qc07 <- isTRUE(all.equal(u_ipw, u_ipw_b))
  dat2$y <- y_saved

  y_r0 <- dat2$y[dat2$r == 0]
  fit <- fit_gaussian_q(dat2$y, dat2$x, dat2$s, dat2$r, family = "full")
  p1 <- fit$predict(tau_g, dat2$x[1:20, , drop = FALSE])
  dat2$y[dat2$r == 0] <- y_r0 + 100
  fit_b <- fit_gaussian_q(dat2$y, dat2$x, dat2$s, dat2$r, family = "full")
  p2 <- fit_b$predict(tau_g, dat2$x[1:20, , drop = FALSE])
  checks$qc08 <- isTRUE(all.equal(p1, p2))

  state <- make_seed_states("QC_REP", 2)[[1]]
  r1 <- run_one_rep(scenario_small, make_truth(scenario_small, 5e4),
                    state, 1)
  r2 <- run_one_rep(scenario_small, make_truth(scenario_small, 5e4),
                    state, 1)
  checks$qc10 <- isTRUE(all.equal(r1$rows$ise, r2$rows$ise))

  required_cols <- c("scenario_id", "replicate", "seed", "M", "p", "x0", "h",
                     "surrogate_quality", "verification_design",
                     "error_distribution", "q_learner", "m_learner",
                     "pi_mode", "method", "ise", "sup_error",
                     "lower_tail_ise", "upper_tail_ise", "mse_q10",
                     "mse_q50", "mse_q90", "lambda_hat", "lambda_star",
                     "G_hat", "H_hat", "G_true", "H_true",
                     "transfer_signal", "negative_transfer",
                     "monotonicity_violations", "runtime_seconds",
                     "warning_flag")
  checks$qc12 <- all(required_cols %in% colnames(r1$rows))

  set.seed(seed + 4L)
  calibration_n <- 50000L
  x_cal <- matrix(runif(calibration_n, -1, 1), ncol = 1L)
  s_cal <- dgp_mu(x_cal) + dgp_sigma(x_cal) * rnorm(calibration_n) +
    tau_s * rnorm(calibration_n)
  e_cal <- verification_e0(x_cal, s_cal, tau_s, "R2")
  checks$qc13 <- abs(mean(e_cal) - 1) < 0.02 &&
    all(e_cal >= 0.5 & e_cal <= 1.5)

  seed_keys <- vapply(c("QC_A", "QC_B"), function(id) {
    paste(make_seed_states(id, 1L)[[1L]], collapse = ",")
  }, character(1L))
  checks$qc14 <- !anyDuplicated(seed_keys)

  fold_id <- rep(1:3, each = 2L)
  x_fold <- matrix(c(0, 0.9, 0, 0.9, 0.5, 0.5), ncol = 1L)
  u_fold <- matrix(c(0, 0, 1, 1, 0.3, 0.3), ncol = 1L)
  fold_fit <- salcdi_crossfit_local_process(
    list(test = u_fold), x_fold, fold_id, x0 = 0, h = 1,
    kernel = "epanechnikov"
  )
  fold_manual <- mean(vapply(1:3, function(k) {
    idx <- which(fold_id == k)
    salcdi_local_cdf(
      u_fold[idx, , drop = FALSE],
      salcdi_local_weights(x_fold[idx, , drop = FALSE], 0, 1,
                           "epanechnikov")
    )
  }, numeric(1L)))
  checks$qc15 <- isTRUE(all.equal(fold_fit$F$test, fold_manual))

  checks$qc16 <- all(c(
    "ise_raw", "ise_final", "sup_raw", "sup_final",
    "candidate_path_signature"
  ) %in% colnames(r1$rows))

  checks$qc17 <- "implementation_version" %in% names(r1$rows) &&
    identical(unique(r1$rows$implementation_version),
              simulation_implementation_version)

  ok <- all(unlist(checks))
  list(pass = ok, checks = checks)
}
