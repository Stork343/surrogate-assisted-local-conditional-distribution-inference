# Primary performance metrics (protocol section 22).

metric_indices <- function(t_len = length(simulation_threshold_levels),
                           probability_levels = NULL) {
  t_len <- as.integer(t_len)
  if (t_len < 2L) stop("At least two thresholds are required.", call. = FALSE)
  if (is.null(probability_levels)) {
    probability_levels <- if (t_len == length(simulation_threshold_levels)) {
      simulation_threshold_levels
    } else {
      seq_len(t_len) / (t_len + 1)
    }
  }
  if (length(probability_levels) != t_len) {
    stop("Probability levels must align with the threshold grid.",
         call. = FALSE)
  }
  tail_n <- max(1L, floor(t_len * simulation_tail_fraction))
  q_idx <- vapply(simulation_q_levels, function(q) {
    which.min(abs(probability_levels - q))
  }, integer(1))
  list(lower = seq_len(tail_n),
       upper = (t_len - tail_n + 1L):t_len,
       q = q_idx)
}

compute_metrics <- function(f_hat, target, method = "") {
  idx <- metric_indices(length(f_hat))
  raw <- as.numeric(f_hat)
  final <- salcdi_shape_correct_cdf(raw)$rearranged
  target <- as.numeric(target)
  ise_raw <- mean((raw - target)^2)
  ise_final <- mean((final - target)^2)
  sup_raw <- max(abs(raw - target))
  sup_final <- max(abs(final - target))
  diffs <- diff(raw)
  list(
    method = method,
    ise_raw = ise_raw,
    ise_final = ise_final,
    ise = ise_final,
    sup_raw = sup_raw,
    sup_final = sup_final,
    sup_error = sup_final,
    lower_tail_ise_raw = mean((raw[idx$lower] - target[idx$lower])^2),
    lower_tail_ise_final = mean((final[idx$lower] - target[idx$lower])^2),
    lower_tail_ise = mean((final[idx$lower] - target[idx$lower])^2),
    upper_tail_ise_raw = mean((raw[idx$upper] - target[idx$upper])^2),
    upper_tail_ise_final = mean((final[idx$upper] - target[idx$upper])^2),
    upper_tail_ise = mean((final[idx$upper] - target[idx$upper])^2),
    mse_q10 = (final[idx$q[1L]] - target[idx$q[1L]])^2,
    mse_q50 = (final[idx$q[2L]] - target[idx$q[2L]])^2,
    mse_q90 = (final[idx$q[3L]] - target[idx$q[3L]])^2,
    monotonicity_violations = sum(diffs < -1e-12),
    largest_violation = max(0, -min(diffs)),
    below_zero = sum(f_hat < 0),
    above_one = sum(f_hat > 1)
  )
}
