# Multiplier-band replication execution (protocol sections 21, 23, 28).

run_band_rep <- function(scenario, truth, state, replicate_id,
                         n_boot = simulation_boot_b) {
  assign(".Random.seed", state, envir = globalenv()) # nolint
  t0 <- proc.time()[["elapsed"]]
  data <- simulate_data(n = scenario$M, tau_s = scenario$tau_s,
                        x0 = scenario$x0, h = scenario$h,
                        verification = scenario$verification,
                        p = scenario$p,
                        error_dist = scenario$error_dist,
                        discrete = isTRUE(scenario$discrete),
                        d = scenario$d,
                        pi_mode = scenario$pi_mode)
  learners <- make_learners(scenario)
  est <- estimate_feasible(data, scenario, truth, learners, return_u = TRUE)
  idx <- metric_indices()
  target <- truth$f_target
  band_methods <- intersect(c("X_anchor", "Adaptive"), names(est$influence))
  fold_diagnostics <- vapply(est$fold_process, function(fold) {
    eval_idx <- fold$eval_idx
    kernel <- fold$kernel
    in_support <- kernel > 0
    c(
      support_count = sum(in_support),
      verified_support_count = sum(in_support & data$r[eval_idx] == 1),
      kernel_verified_weight = sum(kernel * data$r[eval_idx]),
      kernel_mean = fold$mu_hat
    )
  }, numeric(4L))
  rows <- lapply(band_methods, function(nm) {
    multiplier_seed <- simulation_master_seed + 1000L * replicate_id +
      match(nm, band_methods)
    band <- multiplier_band(
      influence = est$influence[[nm]],
      center = est$F[[nm]],
      p = mean(data$pi),
      h = scenario$h,
      dimension = scenario$d,
      n_boot = n_boot,
      seed = multiplier_seed
    )
    cover <- target >= band$band_low & target <= band$band_high
    cover_mono <- target >= band$band_low_mono &
      target <= band$band_high_mono
    data.frame(
      implementation_version = simulation_implementation_version,
      scenario_id = scenario$scenario_id,
      replicate = replicate_id,
      seed = paste(state, collapse = ","),
      M = scenario$M, p = scenario$p, x0 = scenario$x0, h = scenario$h,
      surrogate_quality = surrogate_quality_label(scenario$tau_s),
      verification_design = scenario$verification,
      error_distribution = scenario$error_dist,
      q_learner = scenario$q_learner, m_learner = scenario$m_learner,
      pi_mode = scenario$pi_mode, method = nm,
      simultaneous_coverage = as.integer(all(cover)),
      simultaneous_coverage_rearranged = as.integer(all(cover_mono)),
      pointwise_coverage_q10 = as.integer(cover[idx$q[1L]]),
      pointwise_coverage_q50 = as.integer(cover[idx$q[2L]]),
      pointwise_coverage_q90 = as.integer(cover[idx$q[3L]]),
      integrated_band_width = mean(band$band_high - band$band_low),
      maximum_band_width = max(band$band_high - band$band_low),
      bootstrap_critical_value = band$critical_value,
      multiplier_seed = band$seed,
      multiplier_draws = band$n_boot,
      band_construction = band$construction,
      band_result_version = "salcdi-band-repro-v1",
      verified_support_total = sum(
        fold_diagnostics["verified_support_count", ]
      ),
      verified_support_min_fold = min(
        fold_diagnostics["verified_support_count", ]
      ),
      kernel_verified_weight_min_fold = min(
        fold_diagnostics["kernel_verified_weight", ]
      ),
      kernel_mean_min_fold = min(fold_diagnostics["kernel_mean", ]),
      runtime_seconds = proc.time()[["elapsed"]] - t0,
      warning_flag = as.integer(
        any(!is.finite(band$band_low)) || any(!is.finite(band$band_high))
      ),
      stringsAsFactors = FALSE
    )
  })
  list(rows = do.call(rbind, rows))
}

run_band_batch <- function(root, scenario, n_rep, truth,
                           out_dir = file.path(root, "simulation", "output"),
                           cores = 1, force = FALSE,
                           n_boot = simulation_boot_b) {
  n_boot <- as.integer(n_boot)
  force <- isTRUE(force) || identical(
    Sys.getenv("SALCDI_FORCE_CANONICAL_RERUN", "0"), "1"
  )
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  out_file <- file.path(out_dir, paste0(scenario$scenario_id,
                                        "_band_rep", n_rep, ".rds"))
  if (file.exists(out_file) && !force) {
    existing <- tryCatch(readRDS(out_file), error = function(e) NULL)
    current <- is.data.frame(existing) &&
      "implementation_version" %in% names(existing) &&
      "band_result_version" %in% names(existing) &&
      "multiplier_draws" %in% names(existing) &&
      identical(unique(existing$implementation_version),
                simulation_implementation_version) &&
      identical(unique(existing$band_result_version),
                "salcdi-band-repro-v1") &&
      identical(unique(existing$multiplier_draws), as.integer(n_boot))
    if (isTRUE(current)) return(out_file)
    stop("Existing band result is not a canonical ",
         simulation_implementation_version,
         " object. Re-run this scenario with `force = TRUE`.", call. = FALSE)
  }
  states <- make_seed_states(scenario$scenario_id, n_rep)
  worker <- function(j) run_band_rep(
    scenario, truth, states[[j]], j, n_boot = n_boot
  )
  if (cores == 1) {
    res <- lapply(seq_len(n_rep), worker)
  } else {
    cl <- parallel::makeCluster(cores)
    on.exit(parallel::stopCluster(cl))
    parallel::clusterExport(cl, "root", envir = environment())
    parallel::clusterEvalQ(cl, {
      pkgload::load_all(root, quiet = TRUE)
      source(file.path(root, "simulation", "config", "simulation_constants.R"))
      invisible(lapply(file.path(root, "simulation",
                                 simulation_source_files()), source))
    })
    parallel::clusterExport(
      cl, c("scenario", "truth", "states", "worker", "n_boot"),
                            envir = environment())
    res <- parallel::parLapply(cl, seq_len(n_rep), function(j) worker(j))
  }
  result <- do.call(rbind, lapply(res, function(rep) rep$rows))
  rownames(result) <- NULL
  saveRDS(result, out_file)
  out_file
}
