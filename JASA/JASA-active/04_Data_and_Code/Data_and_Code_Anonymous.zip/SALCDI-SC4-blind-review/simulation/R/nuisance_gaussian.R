# Gaussian location-scale nuisance learners (protocol section 12, L1/L2).

predict_location_scale <- function(tau, mu_hat, sd_hat) {
  pnorm((matrix(tau, nrow = length(mu_hat), ncol = length(tau),
                byrow = TRUE) - mu_hat) / sd_hat)
}

gaussian_log_square_correction <- function() {
  salcdi_gaussian_log_square_correction()
}

weighted_sd <- function(x, weights) {
  center <- weighted.mean(x, weights)
  sqrt(sum(weights * (x - center)^2) / sum(weights))
}

gauss_design <- function(x, s = NULL, include_s = FALSE, full = TRUE) {
  x <- as.matrix(x)
  p <- ncol(x)
  out <- data.frame(X1 = x[, 1L])
  if (p >= 2L) {
    out$X2 <- x[, 2L]
  }
  if (full) {
    out$X1sq <- x[, 1L]^2
    if (p >= 2L) {
      out$X2sq <- x[, 2L]^2
      out$X1X2 <- x[, 1L] * x[, 2L]
    }
  }
  if (include_s) {
    out$S <- s
    if (full) {
      out$X1S <- x[, 1L] * s
      if (p >= 2L) {
        out$X2S <- x[, 2L] * s
      }
      out$X1sqS <- x[, 1L]^2 * s
      if (p >= 2L) {
        out$X2sqS <- x[, 2L]^2 * s
      }
    }
  }
  out
}

constant_predictor <- function(tau, xnew, mu, sd) {
  n <- nrow(as.matrix(xnew))
  predict_location_scale(tau, rep(mu, n), rep(sd, n))
}

fit_gaussian_q <- function(y, x, s, r, pi = NULL,
                           family = c("full", "misspecified")) {
  family <- match.arg(family)
  x <- as.matrix(x)
  idx <- which(r == 1)
  yy <- y[idx] # nolint
  fit_weights <- if (is.null(pi)) rep(1, length(idx)) else 1 / pi[idx]
  if (length(idx) < 5L) {
    mu_const <- if (length(yy)) weighted.mean(yy, fit_weights) else 0
    sd_const <- if (length(yy) >= 2L) weighted_sd(yy, fit_weights) else 1
    return(list(predict = function(tau, xnew) {
      constant_predictor(tau, xnew, mu_const, sd_const)
    }, uses_ipw = !is.null(pi)))
  }
  d <- gauss_design(x[idx, , drop = FALSE],
                    full = family == "full")
  mf <- lm(yy ~ ., data = d, weights = fit_weights)
  if (family == "full") {
    vf <- lm(log(mf$residuals^2 + simulation_eps) ~ ., data = d,
             weights = fit_weights)
  } else {
    vf <- NULL
    const_sd <- weighted_sd(mf$residuals, fit_weights)
  }
  list(predict = function(tau, xnew) {
    xnew <- as.matrix(xnew)
    nd <- gauss_design(xnew, full = family == "full")
    mu_hat <- predict(mf, newdata = nd)
    if (family == "full") {
      sd_hat <- sqrt(exp(
        predict(vf, newdata = nd) + gaussian_log_square_correction()
      ))
    } else {
      sd_hat <- rep(const_sd, nrow(xnew))
    }
    predict_location_scale(tau, mu_hat, sd_hat)
  }, uses_ipw = !is.null(pi))
}

fit_gaussian_m <- function(y, x, s, r, pi = NULL,
                           family = c("full", "misspecified")) {
  family <- match.arg(family)
  x <- as.matrix(x)
  idx <- which(r == 1)
  yy <- y[idx] # nolint
  if (length(idx) < 8L) {
    mu_const <- if (length(yy)) mean(yy) else 0
    sd_const <- if (length(yy) >= 2L) stats::sd(yy) else 1
    return(list(predict = function(tau, xnew, snew) {
      constant_predictor(tau, xnew, mu_const, sd_const)
    }, uses_ipw = FALSE))
  }
  d <- gauss_design(x[idx, , drop = FALSE], s = s[idx], include_s = TRUE,
                    full = family == "full")
  mf <- lm(yy ~ ., data = d)
  if (family == "full") {
    vf <- lm(log(mf$residuals^2 + simulation_eps) ~ ., data = d)
  } else {
    vf <- NULL
    const_sd <- stats::sd(mf$residuals)
  }
  list(predict = function(tau, xnew, snew) {
    xnew <- as.matrix(xnew)
    nd <- gauss_design(xnew, s = as.numeric(snew), include_s = TRUE,
                       full = family == "full")
    mu_hat <- predict(mf, newdata = nd)
    if (family == "full") {
      sd_hat <- sqrt(exp(
        predict(vf, newdata = nd) + gaussian_log_square_correction()
      ))
    } else {
      sd_hat <- rep(const_sd, nrow(xnew))
    }
    predict_location_scale(tau, mu_hat, sd_hat)
  }, uses_ipw = FALSE)
}
