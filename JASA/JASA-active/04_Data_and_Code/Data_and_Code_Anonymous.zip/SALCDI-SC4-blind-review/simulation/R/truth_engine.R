# Analytic truth and high-accuracy quadrature/Monte Carlo targets.

epan_k <- function(u) {
  0.75 * (1 - u^2) * (abs(u) <= 1)
}

truth_thresholds <- function(x0, error_dist, discrete = FALSE) {
  if (isTRUE(discrete)) return(1:10)
  x0 <- matrix(as.numeric(x0), nrow = 1)
  eps_quantile(simulation_threshold_levels, error_dist) *
    dgp_sigma(x0) + dgp_mu(x0)
}

discrete_latent_cutpoints <- function(tau) {
  category <- as.integer(tau)
  if (any(category < 1L | category > 10L) || any(category != tau)) {
    stop("Discrete thresholds must be integer categories in 1:10.",
         call. = FALSE)
  }
  cuts <- c(qnorm(1:9 / 10), Inf)
  cuts[category]
}

truth_q0_discrete_matrix <- function(x, tau, error_dist = "gaussian") {
  x <- as.matrix(x)
  mu <- dgp_mu(x)
  sig <- dgp_sigma(x)
  cuts <- discrete_latent_cutpoints(tau)
  z <- (matrix(cuts, nrow = nrow(x), ncol = length(cuts), byrow = TRUE) -
          mu) / sig
  result <- eps_cdf(z, error_dist)
  result[, tau == 10] <- 1
  result
}

truth_m0_discrete_matrix <- function(x, s, tau, tau_s) {
  x <- as.matrix(x)
  mu <- dgp_mu(x)
  sig2 <- dgp_sigma(x)^2
  kappa <- sig2 / (sig2 + tau_s^2)
  mean_i <- mu + kappa * (s - mu)
  sd_i <- sqrt(sig2 * (1 - kappa))
  cuts <- discrete_latent_cutpoints(tau)
  result <- pnorm(
    (matrix(cuts, nrow = nrow(x), ncol = length(cuts), byrow = TRUE) -
       mean_i) / sd_i
  )
  result[, tau == 10] <- 1
  result
}

truth_q0_matrix <- function(x, s, tau, tau_s, error_dist) {
  x <- as.matrix(x)
  mu <- dgp_mu(x)
  sig <- dgp_sigma(x)
  z <- (matrix(tau, nrow = nrow(x), ncol = length(tau), byrow = TRUE) - mu) / sig
  eps_cdf(z, error_dist)
}

truth_m0_matrix <- function(x, s, tau, tau_s) {
  x <- as.matrix(x)
  mu <- dgp_mu(x)
  sig2 <- dgp_sigma(x)^2
  kappa <- sig2 / (sig2 + tau_s^2)
  mean_i <- mu + kappa * (s - mu)
  sd_i <- sqrt(sig2 * (1 - kappa))
  pnorm((matrix(tau, nrow = nrow(x), ncol = length(tau), byrow = TRUE) -
           mean_i) / sd_i)
}

truth_f0_vector <- function(tau, x0, error_dist) {
  x0 <- matrix(as.numeric(x0), nrow = 1)
  eps_cdf((tau - dgp_mu(x0)) / dgp_sigma(x0), error_dist)
}

truth_f0_discrete <- function(tau, x0, error_dist) {
  drop(truth_q0_discrete_matrix(
    matrix(as.numeric(x0), nrow = 1L), tau, error_dist
  ))
}

truth_fh_discrete <- function(tau, x0, h, error_dist, n_quad = 10001) {
  nodes <- seq(-1, 1, length.out = n_quad)
  mid <- (nodes[-1] + nodes[-length(nodes)]) / 2
  kernel <- epan_k((mid - x0) / h)
  q <- truth_q0_discrete_matrix(matrix(mid, ncol = 1L), tau, error_dist)
  drop(crossprod(kernel, q)) / sum(kernel)
}

truth_fh_vector <- function(tau, x0, h, error_dist, n_quad = 10001) {
  nodes <- seq(-1, 1, length.out = n_quad)
  mid <- (nodes[-1] + nodes[-length(nodes)]) / 2
  dx <- mid[2L] - mid[1L]
  k <- epan_k((mid - x0) / h)
  f0 <- outer(tau, mid, function(yy, xx) {
    eps_cdf((yy - dgp_mu(xx)) / dgp_sigma(xx), error_dist)
  })
  as.numeric(f0 %*% (k * dx)) / sum(k * dx)
}

surrogate_candidate <- function(m0, q0, m_scenario, x, x0, h, tau,
                                error_dist, candidate_scale = NULL) {
  if (is.null(m_scenario) || m_scenario == "none") {
    return(list(unclipped = m0, clipped = m0))
  }
  a <- m0 - q0
  u_levels <- simulation_threshold_levels
  if (m_scenario == "VC") {
    if (is.null(candidate_scale) || !is.finite(candidate_scale) ||
        candidate_scale < 0) {
      stop("Vanishing-curvature scenarios require a nonnegative scale.",
           call. = FALSE)
    }
    unclipped <- q0 + candidate_scale * a
  } else if (m_scenario %in% c("M1", "M2", "M3", "M4", "M5")) {
    c_value <- switch(m_scenario,
                      M1 = 1, M2 = 0.5, M3 = 1.5, M4 = 2.5, M5 = -0.5)
    unclipped <- q0 + c_value * a
  } else if (m_scenario == "M6") {
    c_row <- ifelse(abs(x[, 1L] - x0) <= h, -0.5, 1)
    c_mat <- matrix(c_row, nrow = nrow(x), ncol = ncol(q0))
    unclipped <- q0 + c_mat * a
  } else if (m_scenario == "M7") {
    c_col <- ifelse(u_levels < 0.2, -0.5, 1)
    c_mat <- matrix(rep(c_col, each = nrow(x)), nrow = nrow(x), ncol = ncol(q0))
    unclipped <- q0 + c_mat * a
  } else if (m_scenario == "M8") {
    u_j <- matrix(rep(u_levels, each = nrow(x)), nrow = nrow(x), ncol = ncol(q0))
    unclipped <- m0 + 0.15 * sin(2 * pi * u_j) / (1 - x[, 1L]^2)
  } else {
    stop("Unknown surrogate scenario `", m_scenario, "`.", call. = FALSE)
  }
  list(unclipped = unclipped, clipped = pmin(pmax(unclipped, 0), 1))
}

apply_candidate_path_stress <- function(
    m, q, scenario, x, x0, h,
    threshold_levels = simulation_threshold_levels) {
  result <- as.matrix(m)
  q <- as.matrix(q)
  x <- as.matrix(x)
  if (!all(dim(result) == dim(q)) || nrow(result) != nrow(x)) {
    stop("Candidate, anchor, and covariate dimensions do not align.",
         call. = FALSE)
  }
  if (isTRUE(scenario$m_local_reversal)) {
    multiplier <- ifelse(abs(x[, 1L] - as.numeric(x0)[1L]) <= h, -0.5, 1)
    result <- q + multiplier * (result - q)
  }
  if (isTRUE(scenario$m_tail_failure)) {
    if (length(threshold_levels) != ncol(result)) {
      stop("Threshold levels do not align with the candidate path.",
           call. = FALSE)
    }
    multiplier <- ifelse(threshold_levels < 0.2, -0.5, 1)
    result <- q + sweep(result - q, 2L, multiplier, "*")
  }
  result
}

candidate_path_signature <- function(scenario) {
  m_scenario <- if (is.null(scenario$m_scenario)) "none" else
    scenario$m_scenario
  candidate_scale <- if (is.null(scenario$candidate_scale)) "none" else
    scenario$candidate_scale
  paste(
    m_scenario,
    if (isTRUE(scenario$m_est_clip)) "clipped" else "raw",
    candidate_scale,
    isTRUE(scenario$m_local_reversal),
    isTRUE(scenario$m_tail_failure),
    sep = "|"
  )
}

select_candidate_path <- function(
    m0, q0, scenario, x, x0, h, tau, error_dist,
    threshold_levels = simulation_threshold_levels) {
  candidate <- surrogate_candidate(
    m0, q0, scenario$m_scenario, x, x0, h, tau, error_dist,
    scenario$candidate_scale
  )
  mode <- if (isTRUE(scenario$m_est_clip)) "clipped" else "raw"
  selected <- if (mode == "clipped") candidate$clipped else candidate$unclipped
  selected <- apply_candidate_path_stress(
    selected, q0, scenario, x, x0, h, threshold_levels
  )
  list(
    values = selected,
    raw = candidate$unclipped,
    clipped = candidate$clipped,
    mode = mode,
    path_signature = candidate_path_signature(scenario)
  )
}

truth_g_h <- function(scenario, tau, n_truth, seed = 20260811L,
                      chunk_size = 1e5) {
  if (scenario$error_dist != "gaussian") {
    return(list(G = NA_real_, H = NA_real_,
                lambda_star = NA_real_, transfer_signal = NA_real_))
  }
  set.seed(seed, kind = "L'Ecuyer-CMRG")
  n_chunks <- ceiling(n_truth / chunk_size)
  g_sum <- 0
  h_sum <- 0
  n_done <- 0
  for (cc in seq_len(n_chunks)) {
    n <- min(chunk_size, n_truth - (cc - 1L) * chunk_size)
    x <- matrix(runif(n, -1, 1), ncol = 1)
    eps <- rnorm(n)
    eta <- rnorm(n)
    s <- dgp_mu(x) + dgp_sigma(x) * eps + scenario$tau_s * eta
    e0 <- verification_e0(x, s, scenario$tau_s, scenario$verification,
                          x0 = scenario$x0, h = scenario$h)
    if (!is.null(scenario$pi_mode) && scenario$pi_mode == "estimated") {
      alpha <- propensity_alpha_cache(scenario$tau_s, scenario$p)
      pi0 <- pmin(pmax(propensity_logit(x, s, scenario$tau_s, alpha),
                       0.03), 0.80)
    } else {
      pi0 <- pmin(scenario$p * e0, 0.999)
    }
    v <- salcdi_gain_weights(
      x, scenario$x0, scenario$h, pi0, kernel = simulation_kernel
    )$weights
    if (isTRUE(scenario$discrete)) {
      q0 <- truth_q0_discrete_matrix(x, tau, scenario$error_dist)
      m0 <- truth_m0_discrete_matrix(x, s, tau, scenario$tau_s)
    } else {
      q0 <- truth_q0_matrix(x, s, tau, scenario$tau_s, "gaussian")
      m0 <- truth_m0_matrix(x, s, tau, scenario$tau_s)
    }
    mb <- select_candidate_path(
      m0, q0, scenario, x, scenario$x0, scenario$h, tau, "gaussian"
    )
    a <- m0 - q0
    d <- mb$values - q0
    g_sum <- g_sum + sum(v * rowMeans(d * a))
    h_sum <- h_sum + sum(v * rowMeans(d^2))
    n_done <- n_done + n
  }
  g <- g_sum / n_done
  h <- h_sum / n_done
  lambda_star <- salcdi_oracle_lambda(g, h)
  list(G = g, H = h, lambda_star = lambda_star,
       transfer_signal = 2 * g - h)
}

make_truth <- function(scenario, truth_n = simulation_truth_n) {
  tau <- truth_thresholds(
    scenario$x0, scenario$error_dist, discrete = isTRUE(scenario$discrete)
  )
  if (isTRUE(scenario$discrete)) {
    f0 <- truth_f0_discrete(tau, scenario$x0, scenario$error_dist)
  } else {
    f0 <- truth_f0_vector(tau, scenario$x0, scenario$error_dist)
  }
  if (scenario$target == "F_h") {
    f_target <- if (isTRUE(scenario$discrete)) {
      truth_fh_discrete(tau, scenario$x0, scenario$h, scenario$error_dist)
    } else {
      truth_fh_vector(tau, scenario$x0, scenario$h, scenario$error_dist)
    }
  } else {
    f_target <- f0
  }
  if (scenario$d == 2L) {
    gh <- list(G = NA_real_, H = NA_real_,
               lambda_star = NA_real_, transfer_signal = NA_real_)
  } else {
    gh <- truth_g_h(scenario, tau, truth_n)
  }
  oracle_sample <- NULL
  if (!(scenario$module %in% c("oracle_mechanism", "vanishing_curvature"))) {
    oracle_seed <- stable_scenario_seed(20260819L, scenario$scenario_id)
    oracle_sample <- make_fitted_oracle_sample(
      scenario, n = simulation_fitted_oracle_n, seed = oracle_seed
    )
  }
  list(
    tau = tau,
    f0 = f0,
    f_target = f_target,
    G = gh$G,
    H = gh$H,
    lambda_star = gh$lambda_star,
    transfer_signal = gh$transfer_signal,
    oracle_sample = oracle_sample
  )
}

make_fitted_oracle_sample <- function(
    scenario, n = simulation_fitted_oracle_n, seed = 20260819L) {
  set.seed(as.integer(seed), kind = "L'Ecuyer-CMRG")
  simulate_data(
    n = n,
    tau_s = scenario$tau_s,
    x0 = scenario$x0,
    h = scenario$h,
    verification = scenario$verification,
    p = scenario$p,
    error_dist = scenario$error_dist,
    discrete = isTRUE(scenario$discrete),
    d = scenario$d,
    pi_mode = scenario$pi_mode
  )
}

fitted_path_oracle <- function(
    q_fit, m_fit, scenario, tau, oracle_data) {
  q <- q_fit$predict(tau, oracle_data$x)
  m <- m_fit$predict(tau, oracle_data$x, oracle_data$s)
  threshold_levels <- if (length(tau) == length(simulation_threshold_levels)) {
    simulation_threshold_levels
  } else {
    seq_len(length(tau)) / length(tau)
  }
  m <- apply_candidate_path_stress(
    m, q, scenario, oracle_data$x, scenario$x0, scenario$h,
    threshold_levels
  )
  d <- m - q
  z <- threshold_signals(oracle_data$y, tau)
  weights <- salcdi_gain_weights(
    oracle_data$x, scenario$x0, scenario$h, oracle_data$pi,
    kernel = simulation_kernel
  )$weights
  g <- mean(weights * rowMeans(d * (z - q)))
  h_value <- mean(weights * rowMeans(d^2))
  list(
    G = g,
    H = h_value,
    lambda = salcdi_oracle_lambda(g, h_value),
    source = "independent_truth_sample",
    n = nrow(oracle_data$x),
    candidate_path_signature = candidate_path_signature(scenario)
  )
}
