# Canonical estimators E0-E6 and borrowing diagnostics.

local_borrow_v <- function(x, x0, h, pi) {
  salcdi_gain_weights(
    x, x0 = x0, h = h, pi = pi, kernel = simulation_kernel
  )$weights
}

augment_fits <- function(a, z, r, pi) {
  salcdi_augmented_signal(z, r, pi, a)
}

local_estimates <- function(u_list, x, x0, h) {
  w <- salcdi_local_weights(x, x0, h, kernel = simulation_kernel)
  lapply(u_list, function(u) salcdi_local_cdf(u, w))
}

make_learners <- function(scenario) {
  q_family <- scenario$q_family
  if (is.null(q_family)) {
    q_family <- if (scenario$q_learner == "L2") "misspecified" else "full"
  }
  m_family <- scenario$m_family
  if (is.null(m_family)) {
    m_family <- if (scenario$m_learner == "L2") "misspecified" else "full"
  }
  if (scenario$q_learner == "L3") {
    q_fun <- fit_knn_q
  } else {
    q_fun <- function(y, x, s, r, pi) {
      fit_gaussian_q(y, x, s, r, pi = pi, family = q_family)
    }
  }
  if (scenario$m_learner == "L3") {
    m_fun <- fit_knn_m
  } else {
    m_fun <- function(y, x, s, r, pi) {
      fit_gaussian_m(y, x, s, r, pi = pi, family = m_family)
    }
  }
  list(q = q_fun, m = m_fun)
}

method_list <- function(q_e, m_e, m0_e, lambda_hat, lambda_cv,
                        lambda_star, scenario, tau) {
  n <- nrow(q_e)
  t_len <- ncol(q_e)
  zero <- matrix(0, nrow = n, ncol = t_len)
  out <- list(
    IPW = zero,
    X_anchor = q_e,
    Full = m_e,
    Adaptive = q_e + lambda_hat * (m_e - q_e),
    CV_shrinkage = q_e + lambda_cv * (m_e - q_e)
  )
  if (!is.null(m0_e)) out$Oracle_m <- m0_e
  if (length(lambda_star) == 1L && is.finite(lambda_star)) {
    out$Oracle_lambda <- q_e + lambda_star * (m_e - q_e)
  }
  out
}

estimate_oracle_mechanism <- function(data, scenario, truth) {
  n <- nrow(data$x)
  x0 <- scenario$x0
  h <- scenario$h
  tau <- truth$tau
  z <- threshold_signals(data$y, tau)
  gain_idx <- sample.int(n, floor(n / 2))
  eval_idx <- setdiff(seq_len(n), gain_idx)
  q0_all <- truth_q0_matrix(data$x, data$s, tau, scenario$tau_s, "gaussian")
  m0_all <- truth_m0_matrix(data$x, data$s, tau, scenario$tau_s)
  mb_all <- select_candidate_path(
    m0_all, q0_all, scenario, data$x, x0, h, tau, "gaussian"
  )
  mb_est <- mb_all$values
  q0_g <- q0_all[gain_idx, , drop = FALSE]
  d_g <- mb_est[gain_idx, , drop = FALSE] - q0_g
  zq_g <- z[gain_idx, , drop = FALSE] - q0_g
  v_g <- local_borrow_v(data$x[gain_idx, , drop = FALSE], x0, h,
                        data$pi[gain_idx])
  gains <- salcdi_gain_estimates(d_g, zq_g, v_g,
                                 data$r[gain_idx], data$pi[gain_idx])
  lambda_hat <- salcdi_estimated_lambda(gains$G_hat, gains$H_hat,
                                        scenario$lambda_floor)
  lambda_cv <- salcdi_cv_shrinkage_lambda(gains$G_hat, gains$H_hat,
                                          simulation_cv_grid)
  q0_e <- q0_all[eval_idx, , drop = FALSE]
  m0_e <- m0_all[eval_idx, , drop = FALSE]
  mb_e <- mb_est[eval_idx, , drop = FALSE]
  methods <- method_list(q0_e, mb_e, m0_e, lambda_hat, lambda_cv,
                         truth$lambda_star, scenario, tau)
  z_e <- z[eval_idx, , drop = FALSE]
  u_list <- lapply(methods, augment_fits,
                   z = z_e, r = data$r[eval_idx], pi = data$pi[eval_idx])
  f_list <- local_estimates(u_list, data$x[eval_idx, , drop = FALSE], x0, h)
  list(F = f_list, lambda_hat = lambda_hat, lambda_cv = lambda_cv,
       G_hat = gains$G_hat, H_hat = gains$H_hat,
       candidate_path_signature = mb_all$path_signature)
}

estimate_feasible <- function(data, scenario, truth, learners,
                              return_u = FALSE, training_data = NULL) {
  n <- nrow(data$x)
  x0 <- scenario$x0
  h <- scenario$h
  tau <- truth$tau
  z <- threshold_signals(data$y, tau)
  folds <- ((sample.int(n) - 1L) %% 3L) + 1L
  fit_data <- if (is.null(training_data)) data else training_data
  z_fit <- threshold_signals(fit_data$y, tau)
  fit_folds <- if (is.null(training_data)) {
    folds
  } else {
    ((sample.int(nrow(fit_data$x)) - 1L) %% 3L) + 1L
  }
  method_names <- c("IPW", "X_anchor", "Full", "Adaptive", "CV_shrinkage",
                    "Oracle_m", "Oracle_lambda")
  t_len <- length(tau)
  u_all <- lapply(method_names, function(nm) matrix(NA_real_, n, t_len))
  names(u_all) <- method_names
  lambda_k <- numeric(3)
  cv_k <- numeric(3)
  g_k <- numeric(3)
  h_k <- numeric(3)
  oracle_lambda_k <- rep(NA_real_, 3L)
  oracle_g_k <- rep(NA_real_, 3L)
  oracle_h_k <- rep(NA_real_, 3L)
  m0_available <- scenario$error_dist == "gaussian"
  for (k in 1:3) {
    eval_roles <- salcdi_three_role_rotation(folds, k)
    fit_roles <- salcdi_three_role_rotation(fit_folds, k)
    eval_idx <- eval_roles$evaluation
    nuisance_idx <- fit_roles$nuisance
    gain_idx <- fit_roles$gain
    if (scenario$pi_mode == "estimated") {
      pi_model <- if (is.null(scenario$pi_model)) "P1" else scenario$pi_model
      pi_fit <- fit_propensity(fit_data$x[nuisance_idx, , drop = FALSE],
                               fit_data$s[nuisance_idx],
                               fit_data$r[nuisance_idx],
                               mode = pi_model)
      pi_gain <- pi_fit$predict(fit_data$x[gain_idx, , drop = FALSE],
                                fit_data$s[gain_idx])
      pi_eval <- pi_fit$predict(data$x[eval_idx, , drop = FALSE],
                                data$s[eval_idx])
      pi_nuisance <- pi_fit$predict(fit_data$x[nuisance_idx, , drop = FALSE],
                                    fit_data$s[nuisance_idx])
    } else {
      pi_gain <- fit_data$pi[gain_idx]
      pi_eval <- data$pi[eval_idx]
      pi_nuisance <- fit_data$pi[nuisance_idx]
    }
    q_fit <- learners$q(
      fit_data$y[nuisance_idx],
      fit_data$x[nuisance_idx, , drop = FALSE],
      fit_data$s[nuisance_idx], fit_data$r[nuisance_idx],
      pi_nuisance
    )
    m_fit <- learners$m(
      fit_data$y[nuisance_idx],
      fit_data$x[nuisance_idx, , drop = FALSE],
      fit_data$s[nuisance_idx], fit_data$r[nuisance_idx],
      pi_nuisance
    )
    q_g <- q_fit$predict(tau, fit_data$x[gain_idx, , drop = FALSE])
    m_g <- m_fit$predict(tau, fit_data$x[gain_idx, , drop = FALSE],
                         fit_data$s[gain_idx])
    threshold_levels <- if (length(tau) == length(simulation_threshold_levels)) {
      simulation_threshold_levels
    } else {
      seq_len(length(tau)) / length(tau)
    }
    m_g <- apply_candidate_path_stress(
      m_g, q_g, scenario, fit_data$x[gain_idx, , drop = FALSE],
      x0, h, threshold_levels
    )
    d_g <- m_g - q_g
    zq_g <- z_fit[gain_idx, , drop = FALSE] - q_g
    v_g <- local_borrow_v(fit_data$x[gain_idx, , drop = FALSE], x0, h,
                          pi_gain)
    gains <- salcdi_gain_estimates(d_g, zq_g, v_g,
                                   fit_data$r[gain_idx], pi_gain)
    lambda_k[k] <- salcdi_estimated_lambda(gains$G_hat, gains$H_hat,
                                           scenario$lambda_floor)
    cv_k[k] <- salcdi_cv_shrinkage_lambda(gains$G_hat, gains$H_hat,
                                          simulation_cv_grid)
    g_k[k] <- gains$G_hat
    h_k[k] <- gains$H_hat
    q_e <- q_fit$predict(tau, data$x[eval_idx, , drop = FALSE])
    m_e <- m_fit$predict(tau, data$x[eval_idx, , drop = FALSE],
                         data$s[eval_idx])
    m_e <- apply_candidate_path_stress(
      m_e, q_e, scenario, data$x[eval_idx, , drop = FALSE],
      x0, h, threshold_levels
    )
    m0_e <- NULL
    if (m0_available) {
      m0_e <- if (isTRUE(scenario$discrete)) {
        truth_m0_discrete_matrix(
          data$x[eval_idx, , drop = FALSE], data$s[eval_idx], tau,
          scenario$tau_s
        )
      } else {
        truth_m0_matrix(data$x[eval_idx, , drop = FALSE],
                        data$s[eval_idx], tau, scenario$tau_s)
      }
    }
    fitted_oracle <- NULL
    if (!is.null(truth$oracle_sample)) {
      fitted_oracle <- fitted_path_oracle(
        q_fit, m_fit, scenario, tau, truth$oracle_sample
      )
      oracle_lambda_k[k] <- fitted_oracle$lambda
      oracle_g_k[k] <- fitted_oracle$G
      oracle_h_k[k] <- fitted_oracle$H
    }
    methods <- method_list(q_e, m_e, m0_e, lambda_k[k], cv_k[k],
                           oracle_lambda_k[k], scenario, tau)
    z_e <- z[eval_idx, , drop = FALSE]
    for (nm in names(methods)) {
      u_all[[nm]][eval_idx, ] <- augment_fits(methods[[nm]], z_e,
                                              data$r[eval_idx],
                                              pi_eval)
    }
  }
  keep <- method_names[vapply(u_all, function(z) all(is.finite(z)), logical(1L))]
  process <- salcdi_crossfit_local_process(
    u_all[keep], x = data$x, fold_id = folds,
    x0 = x0, h = h, kernel = simulation_kernel
  )
  rho <- vapply(process$folds, `[[`, numeric(1L), "rho")
  p_hat <- mean(data$pi)
  out <- list(
    F = process$F,
    F_raw = process$F,
    lambda_hat = sum(rho * lambda_k),
    lambda_cv = sum(rho * cv_k),
    G_hat = sum(rho * g_k),
    H_hat = sum(rho * h_k),
    G_tilde_hat = p_hat * sum(rho * g_k),
    H_tilde_hat = p_hat * sum(rho * h_k),
    lambda_fold = lambda_k,
    lambda_cv_fold = cv_k,
    G_fold = g_k,
    H_fold = h_k,
    fitted_oracle_lambda_fold = oracle_lambda_k,
    fitted_oracle_G_fold = oracle_g_k,
    fitted_oracle_H_fold = oracle_h_k,
    fitted_oracle_lambda = if (all(is.finite(oracle_lambda_k))) {
      sum(rho * oracle_lambda_k)
    } else {
      NA_real_
    },
    fold_id = folds,
    fold_process = process$folds,
    influence = process$influence,
    training_fold_id = fit_folds,
    independent_training_domain = !is.null(training_data),
    p_hat = p_hat
  )
  out$candidate_path_signature <- candidate_path_signature(scenario)
  if (return_u) {
    out$u <- u_all[keep]
  }
  out
}
