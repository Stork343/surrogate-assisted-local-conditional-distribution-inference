# Data-generating processes (protocol sections 3, 17-19).

dgp_mu <- function(x) {
  x <- as.matrix(x)
  if (ncol(x) == 1L) {
    1.2 * x[, 1L] + 0.6 * x[, 1L]^2
  } else {
    1.2 * x[, 1L] + 0.8 * x[, 2L] + 0.6 * x[, 1L] * x[, 2L]
  }
}

dgp_sigma <- function(x) {
  x <- as.matrix(x)
  if (ncol(x) == 1L) {
    0.8 + 0.25 * x[, 1L]^2
  } else {
    0.8 + 0.2 * (x[, 1L]^2 + x[, 2L]^2)
  }
}

sim_eps <- function(n, dist = c("gaussian", "t3", "skew", "mixture")) {
  dist <- match.arg(dist)
  switch(dist,
    gaussian = rnorm(n),
    t3 = rt(n, df = 3) / sqrt(3),
    skew = (rchisq(n, df = 3) - 3) / sqrt(6),
    mixture = {
      raw <- ifelse(runif(n) < 0.85, rnorm(n), rnorm(n, mean = 2.5, sd = 0.6))
      (raw - 0.375) / sqrt(1.700875)
    }
  )
}

eps_cdf <- function(e, dist = c("gaussian", "t3", "skew", "mixture")) {
  dist <- match.arg(dist)
  switch(dist,
    gaussian = pnorm(e),
    t3 = pt(sqrt(3) * e, df = 3),
    skew = pchisq(sqrt(6) * e + 3, df = 3),
    mixture = {
      z <- 0.375 + sqrt(1.700875) * e
      0.85 * pnorm(z) + 0.15 * pnorm((z - 2.5) / 0.6)
    }
  )
}

eps_quantile <- function(u, dist = c("gaussian", "t3", "skew", "mixture")) {
  dist <- match.arg(dist)
  switch(dist,
    gaussian = qnorm(u),
    t3 = qt(u, df = 3) / sqrt(3),
    skew = (qchisq(u, df = 3) - 3) / sqrt(6),
    mixture = {
      vapply(u, function(ui) {
        uniroot(function(e) eps_cdf(e, "mixture") - ui,
                interval = c(-8, 8))$root
      }, numeric(1))
    }
  )
}

simulate_data <- function(n, tau_s, x0, h, verification = "R1", p = 0.1,
                          error_dist = "gaussian", discrete = FALSE, d = 1,
                          pi_mode = "known") {
  x <- matrix(runif(n * d, -1, 1), nrow = n, ncol = d)
  eps <- sim_eps(n, error_dist)
  eta <- rnorm(n)
  y_star <- dgp_mu(x) + dgp_sigma(x) * eps
  if (discrete) {
    y <- findInterval(y_star, simulation_discrete_cuts) + 1L
  } else {
    y <- y_star
  }
  s <- y_star + tau_s * eta
  if (pi_mode == "estimated") {
    alpha <- propensity_alpha_cache(tau_s, p)
    pi0 <- pmin(pmax(propensity_logit(x, s, tau_s, alpha), 0.03), 0.80)
    e0 <- pi0 / p
  } else {
    e0 <- verification_e0(x, s, tau_s, verification, x0 = x0, h = h)
    pi0 <- pmin(p * e0, 0.999)
  }
  r <- rbinom(n, 1, pi0)
  list(
    x = x,
    s = s,
    y = y,
    y_star = y_star,
    r = r,
    pi = pi0,
    e0 = e0
  )
}

make_domain_shift_samples <- function(scenario) {
  if (is.null(scenario$train_tau_s) || !is.finite(scenario$train_tau_s)) {
    stop("A finite `train_tau_s` is required for a domain-shift scenario.",
         call. = FALSE)
  }
  common <- list(
    n = scenario$M,
    x0 = scenario$x0,
    h = scenario$h,
    verification = scenario$verification,
    p = scenario$p,
    error_dist = scenario$error_dist,
    discrete = isTRUE(scenario$discrete),
    d = scenario$d,
    pi_mode = scenario$pi_mode
  )
  evaluation <- do.call(simulate_data, c(common, list(tau_s = scenario$tau_s)))
  training <- do.call(
    simulate_data, c(common, list(tau_s = scenario$train_tau_s))
  )
  evaluation$domain <- "evaluation"
  training$domain <- "training_gain"
  list(evaluation = evaluation, training = training)
}

threshold_signals <- function(y, tau) {
  salcdi_threshold_signals(y, tau)
}
