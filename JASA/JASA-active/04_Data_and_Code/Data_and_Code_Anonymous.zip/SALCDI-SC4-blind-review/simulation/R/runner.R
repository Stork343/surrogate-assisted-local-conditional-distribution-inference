# Deterministic seeds, scenario execution, checkpointing, and parallelism.

stable_scenario_seed <- function(master_seed, scenario_id) {
  modulus <- 2147483647
  accumulator <- as.double(as.integer(master_seed) %% modulus)
  bytes <- utf8ToInt(enc2utf8(as.character(scenario_id)))
  for (byte in bytes) {
    accumulator <- (accumulator * 131 + byte) %% modulus
  }
  as.integer(max(1, accumulator))
}

make_seed_states <- function(scenario_id, n_rep,
                             master_seed = simulation_master_seed) {
  set.seed(stable_scenario_seed(master_seed, scenario_id),
           kind = "L'Ecuyer-CMRG")
  rng <- .Random.seed
  rng <- parallel::nextRNGStream(rng)
  states <- vector("list", n_rep)
  for (j in seq_len(n_rep)) {
    states[[j]] <- rng
    rng <- parallel::nextRNGSubStream(rng)
  }
  states
}

surrogate_quality_label <- function(tau_s) {
  switch(as.character(tau_s),
         "0.4" = "strong",
         "0.8" = "moderate",
         "1.6" = "weak",
         "moderate")
}

simulation_x0_metadata <- function(x0) {
  coordinates <- as.numeric(x0)
  if (!length(coordinates) || any(!is.finite(coordinates))) {
    stop("`x0` must contain at least one finite coordinate.", call. = FALSE)
  }
  list(
    x0 = coordinates[[1L]],
    x0_coordinates = paste(as.character(coordinates), collapse = ","),
    x0_dimension = length(coordinates)
  )
}

run_one_rep <- function(scenario, truth, state, replicate_id) {
  assign(".Random.seed", state, envir = globalenv()) # nolint
  t0 <- proc.time()[["elapsed"]]
  training_data <- NULL
  if (!is.null(scenario$train_tau_s)) {
    samples <- make_domain_shift_samples(scenario)
    data <- samples$evaluation
    training_data <- samples$training
  } else {
    data <- simulate_data(n = scenario$M, tau_s = scenario$tau_s,
                          x0 = scenario$x0, h = scenario$h,
                          verification = scenario$verification,
                          p = scenario$p,
                          error_dist = scenario$error_dist,
                          discrete = isTRUE(scenario$discrete),
                          d = scenario$d,
                          pi_mode = scenario$pi_mode)
  }
  if (scenario$module %in% c("oracle_mechanism", "vanishing_curvature")) {
    est <- estimate_oracle_mechanism(data, scenario, truth)
  } else {
    learners <- make_learners(scenario)
    est <- estimate_feasible(
      data, scenario, truth, learners, training_data = training_data
    )
  }
  target <- truth$f_target
  anchor_ise <- NULL
  metrics <- lapply(est$F, compute_metrics, target = target)
  anchor_ise <- metrics$X_anchor$ise
  x0_metadata <- simulation_x0_metadata(scenario$x0)
  rows <- lapply(names(metrics), function(nm) {
    mt <- metrics[[nm]]
    data.frame(
      implementation_version = simulation_implementation_version,
      scenario_id = scenario$scenario_id,
      replicate = replicate_id,
      seed = paste(state, collapse = ","),
      M = scenario$M,
      p = scenario$p,
      x0 = x0_metadata$x0,
      x0_coordinates = x0_metadata$x0_coordinates,
      x0_dimension = x0_metadata$x0_dimension,
      h = scenario$h,
      surrogate_quality = surrogate_quality_label(scenario$tau_s),
      verification_design = scenario$verification,
      error_distribution = scenario$error_dist,
      q_learner = scenario$q_learner,
      m_learner = scenario$m_learner,
      pi_mode = scenario$pi_mode,
      candidate_scale = if (is.null(scenario$candidate_scale)) {
        NA_real_
      } else {
        scenario$candidate_scale
      },
      candidate_path_signature = est$candidate_path_signature,
      method = nm,
      ise_raw = mt$ise_raw,
      ise_final = mt$ise_final,
      ise = mt$ise,
      sup_raw = mt$sup_raw,
      sup_final = mt$sup_final,
      sup_error = mt$sup_error,
      lower_tail_ise_raw = mt$lower_tail_ise_raw,
      lower_tail_ise_final = mt$lower_tail_ise_final,
      lower_tail_ise = mt$lower_tail_ise,
      upper_tail_ise_raw = mt$upper_tail_ise_raw,
      upper_tail_ise_final = mt$upper_tail_ise_final,
      upper_tail_ise = mt$upper_tail_ise,
      mse_q10 = mt$mse_q10,
      mse_q50 = mt$mse_q50,
      mse_q90 = mt$mse_q90,
      lambda_hat = est$lambda_hat,
      lambda_star = if (!is.null(est$fitted_oracle_lambda) &&
                           is.finite(est$fitted_oracle_lambda)) {
        est$fitted_oracle_lambda
      } else {
        truth$lambda_star
      },
      G_hat = est$G_hat,
      H_hat = est$H_hat,
      G_true = truth$G,
      H_true = truth$H,
      transfer_signal = truth$transfer_signal,
      negative_transfer = as.integer(mt$ise > anchor_ise),
      monotonicity_violations = mt$monotonicity_violations,
      runtime_seconds = proc.time()[["elapsed"]] - t0,
      warning_flag = as.integer(
        any(!is.finite(est$F[[nm]])) ||
          !is.finite(mt$ise) || !is.finite(mt$sup_error)
      ),
      stringsAsFactors = FALSE
    )
  })
  list(rows = do.call(rbind, rows))
}

read_scenario_manifest <- function(root) {
  csv <- file.path(root, "simulation", "config", "scenario_manifest.csv")
  df <- read.csv(csv, stringsAsFactors = FALSE, check.names = FALSE)
  field_map <- c(
    verification = "verification_design",
    error_dist = "error_distribution"
  )
  for (target in names(field_map)) {
    source <- field_map[[target]]
    if (!source %in% names(df)) {
      stop("Scenario manifest is missing `", source, "`.", call. = FALSE)
    }
    if (target %in% names(df) &&
        !identical(as.character(df[[target]]), as.character(df[[source]]))) {
      stop("Scenario manifest fields `", target, "` and `", source,
           "` disagree.", call. = FALSE)
    }
    df[[target]] <- df[[source]]
  }
  num_cols <- c(
    "M", "p", "x0", "h", "tau_s", "lambda_floor", "d",
    "candidate_scale"
  )
  for (col in num_cols) {
    df[[col]] <- as.numeric(df[[col]])
  }
  for (col in c("discrete", "m_local_reversal", "m_tail_failure",
                "m_est_clip")) {
    df[[col]] <- as.logical(df[[col]])
  }
  out <- lapply(split(df, seq_len(nrow(df))), as.list)
  out <- lapply(out, function(row) {
    if (row$d >= 2L) {
      row$x0 <- rep(0, row$d)
    }
    for (col in c("m_scenario", "q_family", "m_family", "train_tau_s",
                  "pi_model")) {
      val <- row[[col]]
      if (length(val) == 1L && (is.na(val) || !nzchar(as.character(val)))) {
        row[[col]] <- NULL
      }
    }
    if (length(row$candidate_scale) == 1L && is.na(row$candidate_scale)) {
      row$candidate_scale <- NULL
    }
    row
  })
  unname(out)
}

run_scenario_batch <- function(root, scenario, n_rep, truth,
                               out_dir = file.path(root, "simulation", "output"),
                               cores = 1, force = FALSE,
                               master_seed = simulation_master_seed) {
  force <- isTRUE(force) || identical(
    Sys.getenv("SALCDI_FORCE_CANONICAL_RERUN", "0"), "1"
  )
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  out_file <- file.path(out_dir, paste0(scenario$scenario_id,
                                        "_rep", n_rep, ".rds"))
  if (file.exists(out_file) && !force) {
    existing <- tryCatch(readRDS(out_file), error = function(e) NULL)
    current <- is.data.frame(existing) &&
      "implementation_version" %in% names(existing) &&
      identical(unique(existing$implementation_version),
                simulation_implementation_version)
    if (isTRUE(current)) return(out_file)
    stop("Existing result is not a canonical ",
         simulation_implementation_version,
         " object. Re-run this scenario with `force = TRUE`.", call. = FALSE)
  }
  states <- make_seed_states(scenario$scenario_id, n_rep, master_seed)
  worker <- function(j) run_one_rep(scenario, truth, states[[j]], j)
  if (cores == 1) {
    res <- lapply(seq_len(n_rep), worker)
  } else {
    cl <- parallel::makeCluster(cores)
    on.exit(parallel::stopCluster(cl))
    parallel::clusterExport(cl, "root", envir = environment())
    parallel::clusterEvalQ(cl, {
      pkgload::load_all(root, quiet = TRUE)
      source(file.path(root, "simulation", "config", "simulation_constants.R"))
      invisible(lapply(file.path(root, "simulation",
                                 simulation_source_files()), source))
    })
    parallel::clusterExport(cl, c("scenario", "truth", "states", "worker"),
                            envir = environment())
    res <- parallel::parLapply(cl, seq_len(n_rep), function(j) worker(j))
  }
  result <- do.call(rbind, lapply(res, function(rep) rep$rows))
  rownames(result) <- NULL
  saveRDS(result, out_file)
  out_file
}
