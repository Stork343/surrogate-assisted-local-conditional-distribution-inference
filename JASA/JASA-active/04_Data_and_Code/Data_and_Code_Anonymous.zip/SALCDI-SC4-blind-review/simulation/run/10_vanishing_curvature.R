# Targeted vanishing-curvature module: five shrinking candidate paths.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1L) args[[1L]] else "."
cores <- if (length(args) >= 2L) as.integer(args[[2L]]) else 1L

pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)

manifest <- read_scenario_manifest(root)
selected <- manifest[vapply(
  manifest, function(s) identical(s$module, "vanishing_curvature"), logical(1L)
)]
if (length(selected) != 5L) {
  stop("Expected five registered vanishing-curvature scenarios.", call. = FALSE)
}

for (scenario in selected) {
  cat("Vanishing curvature", scenario$scenario_id, "start:", format(Sys.time()), "\n")
  truth <- make_truth(scenario, truth_n = simulation_truth_n)
  run_scenario_batch(
    root, scenario, simulation_reps[[scenario$level]], truth, cores = cores,
    force = TRUE
  )
}
