# Pre-submission diagnostic for multiplier-count stability and local information.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1L) normalizePath(args[[1L]]) else normalizePath(".")
cores <- if (length(args) >= 2L) as.integer(args[[2L]]) else 1L
if (!is.finite(cores) || cores < 1L) cores <- 1L

pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)

diagnostic_ids <- c(
  "B_p0.05_R2_strong",
  "B_p0.05_R2_moderate",
  "B_p0.05_R2_weak",
  "B_p0.05_R2_locally_failed",
  "B_p0.10_R2_strong",
  "B_p0.05_R1_moderate",
  "B_p0.20_R2_moderate"
)
draw_counts <- c(999L, 4999L)
manifest <- read_scenario_manifest(root)
selected <- manifest[vapply(
  manifest, function(scenario) scenario$scenario_id %in% diagnostic_ids,
  logical(1L)
)]
stopifnot(length(selected) == length(diagnostic_ids))

result_files <- character()
for (draws in draw_counts) {
  out_dir <- file.path(
    root, "simulation", "output", paste0("band_diagnostic_B", draws)
  )
  for (scenario in selected) {
    n_rep <- simulation_reps[[scenario$level]]
    cat(
      "Band diagnostic", draws, scenario$scenario_id,
      "start:", format(Sys.time()), "\n"
    )
    truth <- make_truth(scenario, truth_n = simulation_truth_n)
    result_files <- c(result_files, run_band_batch(
      root, scenario, n_rep, truth, out_dir = out_dir,
      cores = cores, force = TRUE, n_boot = draws
    ))
  }
}

raw <- do.call(rbind, lapply(result_files, readRDS))
summary <- aggregate(
  cbind(
    simultaneous_coverage,
    simultaneous_coverage_rearranged,
    integrated_band_width,
    bootstrap_critical_value,
    verified_support_total,
    verified_support_min_fold,
    kernel_verified_weight_min_fold,
    kernel_mean_min_fold
  ) ~ scenario_id + method + multiplier_draws + band_construction,
  raw,
  mean
)

low_fold <- aggregate(
  I(verified_support_min_fold <= 3) ~
    scenario_id + method + multiplier_draws + band_construction,
  raw,
  mean
)
names(low_fold)[names(low_fold) == "I(verified_support_min_fold <= 3)"] <-
  "frequency_min_fold_le_3"
summary <- merge(
  summary, low_fold,
  by = c("scenario_id", "method", "multiplier_draws", "band_construction"),
  all.x = TRUE, sort = TRUE
)

output <- file.path(
  root, "reproducibility", "machine_tables",
  "band_presubmission_diagnostic.csv"
)
write.csv(summary, output, row.names = FALSE)
cat("Wrote", nrow(summary), "diagnostic rows to", output, "\n")
