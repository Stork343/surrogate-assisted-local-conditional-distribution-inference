# Work Package 0 smoke run (Level A: 20 replications).
# Usage: Rscript simulation/run/00_smoke.R [project-root] [cores]
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
cores <- if (length(commandArgs(trailingOnly = TRUE)) > 1) {
  as.integer(commandArgs(trailingOnly = TRUE)[2])
} else {
  1
}

pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)

cat("QC start:", format(Sys.time()), "\n")
qc <- run_qc(root)
cat("QC pass:", qc$pass, "\n")
for (nm in names(qc$checks)) {
  cat(sprintf("  %s: %s\n", nm, qc$checks[[nm]]))
}
if (!qc$pass) {
  stop("QC failed; no simulation batch started.", call. = FALSE)
}

manifest <- read_scenario_manifest(root)
smoke_ids <- c(
  paste0("M", 1:8, "_R1"),
  paste0("M", 1:8, "_R2"),
  "F1_p0.05", "F1_p0.10", "F1_p0.20",
  "SC_M2000_p0.050", "SC_M2000_p0.200",
  "SC_M4000_p0.050", "SC_M4000_p0.200"
)
scenarios <- manifest[vapply(manifest, function(s) {
  s$scenario_id %in% smoke_ids
}, logical(1))]

n_rep <- simulation_reps[["A"]]
out_dir <- file.path(root, "simulation", "output")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
times <- numeric(length(scenarios))
names(times) <- vapply(scenarios, function(s) s$scenario_id, character(1))
for (i in seq_along(scenarios)) {
  scenario <- scenarios[[i]]
  cat("Smoke scenario", scenario$scenario_id,
      "start:", format(Sys.time()), "\n")
  truth <- make_truth(scenario, truth_n = simulation_truth_n_smoke)
  t0 <- proc.time()[["elapsed"]]
  run_scenario_batch(root, scenario, n_rep, truth,
                     out_dir = out_dir, cores = cores, force = TRUE)
  times[[i]] <- proc.time()[["elapsed"]] - t0
  cat("  done in", round(times[[i]], 2), "seconds\n")
}

# Runtime benchmark on one additional feasible scenario.
bench_scenario <- manifest[[which(vapply(manifest, function(s) {
  s$scenario_id == "F2_t8"
}, logical(1)))[1]]]
truth_bench <- make_truth(bench_scenario, truth_n = simulation_truth_n_smoke)
t0 <- proc.time()[["elapsed"]]
invisible(run_scenario_batch(root, bench_scenario, 1, truth_bench,
                             out_dir = out_dir, cores = 1, force = TRUE))
bench_seconds <- (proc.time()[["elapsed"]] - t0)
cat("Feasible benchmark (1 rep):", round(bench_seconds, 3), "seconds\n")

cat("Smoke complete:", format(Sys.time()), "\n")
