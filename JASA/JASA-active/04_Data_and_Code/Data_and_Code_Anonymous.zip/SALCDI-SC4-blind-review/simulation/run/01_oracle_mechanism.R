# Work Package 1: oracle mechanism experiments (M1-M8 x R1/R2).
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
manifest <- read_scenario_manifest(root)
sel <- manifest[vapply(manifest, function(s) {
  s$module == "oracle_mechanism" &&
    !is.null(s$m_scenario) && s$m_scenario %in% paste0("M", 1:8) &&
    !startsWith(s$scenario_id, "BW_")
}, logical(1))]
for (scenario in sel) {
  n_rep <- simulation_reps[[scenario$level]]
  cat("WP1", scenario$scenario_id, "start:", format(Sys.time()), "\n")
  truth <- make_truth(scenario, truth_n = simulation_truth_n)
  run_scenario_batch(root, scenario, n_rep, truth, cores = cores)
}
cat("WP1 complete:", format(Sys.time()), "\n")
