# Work Package 5a: nuisance-misspecification stress (N1-N8).
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
manifest <- read_scenario_manifest(root)
sel <- manifest[vapply(manifest, function(s) s$module == "stress",
                       logical(1))]
for (scenario in sel) {
  cat("WP5a", scenario$scenario_id, "start:", format(Sys.time()), "\n")
  truth <- make_truth(scenario, truth_n = simulation_truth_n)
  n_rep <- simulation_reps[[scenario$level]]
  run_scenario_batch(root, scenario, n_rep, truth, cores = cores)
}
cat("WP5a complete:", format(Sys.time()), "\n")
