# Work Package 2: feasible estimator experiments (F1-F3, L1-L3).
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
manifest <- read_scenario_manifest(root)
sel <- manifest[vapply(manifest, function(s) {
  s$module == "feasible" && !startsWith(s$scenario_id, "DF_")
}, logical(1))]
for (scenario in sel) {
  cat("WP2", scenario$scenario_id, "start:", format(Sys.time()), "\n")
  truth <- make_truth(scenario, truth_n = simulation_truth_n)
  n_rep <- simulation_reps[[scenario$level]]
  run_scenario_batch(root, scenario, n_rep, truth, cores = cores)
}
cat("WP2 complete:", format(Sys.time()), "\n")
