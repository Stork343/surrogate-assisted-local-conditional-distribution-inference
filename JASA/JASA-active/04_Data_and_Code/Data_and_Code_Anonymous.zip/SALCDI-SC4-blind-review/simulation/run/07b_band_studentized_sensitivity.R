# Pre-specified studentized-band sensitivity using shared fitted influences.

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1L) normalizePath(args[[1L]]) else normalizePath(".")
cores <- if (length(args) >= 2L) as.integer(args[[2L]]) else 1L
if (!is.finite(cores) || cores < 1L) cores <- 1L

pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)

diagnostic_ids <- c(
  "B_p0.05_R2_strong",
  "B_p0.05_R2_moderate",
  "B_p0.05_R2_weak",
  "B_p0.05_R2_locally_failed",
  "B_p0.10_R2_strong",
  "B_p0.05_R1_moderate",
  "B_p0.20_R2_moderate"
)
n_boot <- 4999L
output_dir <- file.path(
  root, "simulation", "output", "band_studentized_sensitivity"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

band_sensitivity <- function(influence, center, p, h, dimension, seed) {
  influence <- as.matrix(influence)
  center <- as.numeric(center)
  n <- nrow(influence)
  h <- as.numeric(h)
  h_volume <- if (length(h) == 1L) h^as.integer(dimension) else prod(h)

  set.seed(as.integer(seed), kind = "L'Ecuyer-CMRG")
  xi <- matrix(
    sample(c(-1, 1), n_boot * n, replace = TRUE),
    nrow = n_boot, ncol = n
  )
  process_scale <- sqrt(p * h_volume / n)
  process <- process_scale * (xi %*% influence)

  raw_supremum <- apply(process, 1L, function(value) max(abs(value)))
  raw_critical <- unname(stats::quantile(
    raw_supremum, simulation_boot_level, names = FALSE
  ))
  raw_half_width <- raw_critical / sqrt(n * p * h_volume)

  pointwise_scale <- sqrt(
    (p * h_volume / n) * colSums(influence^2)
  )
  numerical_floor <- sqrt(.Machine$double.eps)
  pointwise_scale <- pmax(pointwise_scale, numerical_floor)
  studentized_process <- sweep(process, 2L, pointwise_scale, "/")
  studentized_supremum <- apply(
    studentized_process, 1L, function(value) max(abs(value))
  )
  studentized_critical <- unname(stats::quantile(
    studentized_supremum, simulation_boot_level, names = FALSE
  ))
  studentized_half_width <-
    studentized_critical * pointwise_scale / sqrt(n * p * h_volume)

  make_result <- function(construction, critical, half_width) {
    low <- center - half_width
    high <- center + half_width
    list(
      construction = construction,
      critical_value = critical,
      band_low = low,
      band_high = high,
      band_low_rearranged = salcdi_monotone_cdf(low),
      band_high_rearranged = salcdi_monotone_cdf(high),
      integrated_width = mean(high - low),
      maximum_width = max(high - low)
    )
  }

  list(
    make_result(
      "unstudentized_raw_supremum", raw_critical, raw_half_width
    ),
    make_result(
      "studentized_t_supremum", studentized_critical,
      studentized_half_width
    ),
    pointwise_scale_min = min(pointwise_scale),
    pointwise_scale_median = stats::median(pointwise_scale),
    numerical_floor = numerical_floor
  )
}

run_sensitivity_rep <- function(scenario, truth, state, replicate_id) {
  assign(".Random.seed", state, envir = globalenv()) # nolint
  data <- simulate_data(
    n = scenario$M, tau_s = scenario$tau_s, x0 = scenario$x0,
    h = scenario$h, verification = scenario$verification, p = scenario$p,
    error_dist = scenario$error_dist, discrete = isTRUE(scenario$discrete),
    d = scenario$d, pi_mode = scenario$pi_mode
  )
  learners <- make_learners(scenario)
  est <- estimate_feasible(data, scenario, truth, learners, return_u = TRUE)
  target <- truth$f_target
  methods <- intersect(c("X_anchor", "Adaptive"), names(est$influence))

  fold_diagnostics <- vapply(est$fold_process, function(fold) {
    eval_idx <- fold$eval_idx
    kernel <- fold$kernel
    in_support <- kernel > 0
    c(
      verified_support_count = sum(in_support & data$r[eval_idx] == 1),
      kernel_verified_weight = sum(kernel * data$r[eval_idx]),
      kernel_mean = fold$mu_hat
    )
  }, numeric(3L))

  rows <- lapply(methods, function(method) {
    multiplier_seed <- simulation_master_seed + 1000L * replicate_id +
      match(method, methods)
    bands <- band_sensitivity(
      est$influence[[method]], est$F[[method]], p = mean(data$pi),
      h = scenario$h, dimension = scenario$d, seed = multiplier_seed
    )
    do.call(rbind, lapply(bands[1:2], function(band) {
      cover <- target >= band$band_low & target <= band$band_high
      cover_rearranged <- target >= band$band_low_rearranged &
        target <= band$band_high_rearranged
      data.frame(
        implementation_version = simulation_implementation_version,
        sensitivity_version = "salcdi-band-studentized-sensitivity-v1",
        scenario_id = scenario$scenario_id,
        replicate = replicate_id,
        data_seed = paste(state, collapse = ","),
        method = method,
        band_construction = band$construction,
        simultaneous_coverage = as.integer(all(cover)),
        simultaneous_coverage_rearranged = as.integer(
          all(cover_rearranged)
        ),
        integrated_band_width = band$integrated_width,
        maximum_band_width = band$maximum_width,
        bootstrap_critical_value = band$critical_value,
        multiplier_seed = multiplier_seed,
        multiplier_draws = n_boot,
        pointwise_scale_min = bands$pointwise_scale_min,
        pointwise_scale_median = bands$pointwise_scale_median,
        numerical_floor = bands$numerical_floor,
        verified_support_total = sum(
          fold_diagnostics["verified_support_count", ]
        ),
        verified_support_min_fold = min(
          fold_diagnostics["verified_support_count", ]
        ),
        kernel_verified_weight_min_fold = min(
          fold_diagnostics["kernel_verified_weight", ]
        ),
        kernel_mean_min_fold = min(fold_diagnostics["kernel_mean", ]),
        stringsAsFactors = FALSE
      )
    }))
  })
  do.call(rbind, rows)
}

manifest <- read_scenario_manifest(root)
selected <- manifest[vapply(
  manifest, function(scenario) scenario$scenario_id %in% diagnostic_ids,
  logical(1L)
)]
stopifnot(length(selected) == length(diagnostic_ids))

result_files <- character()
for (scenario in selected) {
  n_rep <- simulation_reps[[scenario$level]]
  path <- file.path(
    output_dir,
    paste0(scenario$scenario_id, "_B", n_boot, "_rep", n_rep, ".rds")
  )
  cat("Studentized sensitivity", scenario$scenario_id,
      "start:", format(Sys.time()), "\n")
  truth <- make_truth(scenario, truth_n = simulation_truth_n)
  states <- make_seed_states(scenario$scenario_id, n_rep)
  worker <- function(index) {
    run_sensitivity_rep(scenario, truth, states[[index]], index)
  }
  if (cores == 1L) {
    pieces <- lapply(seq_len(n_rep), worker)
  } else {
    cluster <- parallel::makeCluster(cores)
    parallel::clusterExport(cluster, "root", envir = environment())
    parallel::clusterEvalQ(cluster, {
      pkgload::load_all(root, quiet = TRUE)
      source(file.path(root, "simulation", "config", "simulation_constants.R"))
      source_simulation_environment(root)
    })
    parallel::clusterExport(
      cluster,
      c(
        "scenario", "truth", "states", "n_rep", "n_boot",
        "band_sensitivity", "run_sensitivity_rep", "worker"
      ),
      envir = environment()
    )
    pieces <- parallel::parLapply(
      cluster, seq_len(n_rep), function(index) worker(index)
    )
    parallel::stopCluster(cluster)
  }
  result <- do.call(rbind, pieces)
  rownames(result) <- NULL
  saveRDS(result, path)
  result_files <- c(result_files, path)
}

raw <- do.call(rbind, lapply(result_files, readRDS))
summary <- aggregate(
  cbind(
    simultaneous_coverage,
    simultaneous_coverage_rearranged,
    integrated_band_width,
    maximum_band_width,
    bootstrap_critical_value,
    pointwise_scale_min,
    pointwise_scale_median,
    verified_support_total,
    verified_support_min_fold,
    kernel_verified_weight_min_fold
  ) ~ scenario_id + method + band_construction + multiplier_draws,
  raw,
  mean
)
output <- file.path(
  root, "reproducibility", "machine_tables",
  "band_studentized_sensitivity.csv"
)
write.csv(summary, output, row.names = FALSE)
cat("Wrote", nrow(summary), "studentized sensitivity rows to", output, "\n")
