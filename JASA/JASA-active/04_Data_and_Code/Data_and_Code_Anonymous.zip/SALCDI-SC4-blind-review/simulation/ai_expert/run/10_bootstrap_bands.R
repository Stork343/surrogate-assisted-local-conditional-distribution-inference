# WP-AI8: multiplier bands on representative AI scenarios (after scoring).
stop("WP-AI8: implement after primary scoring and downstream runs.",
     call. = FALSE)
