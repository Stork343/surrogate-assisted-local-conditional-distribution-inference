# WP-AI10: AI tables 1-8, figures 4-12, and integrated audit report.
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
raw <- file.path(base, "results", "raw")
summ <- file.path(base, "results", "summaries")
tabs <- file.path(base, "results", "tables")
figs <- file.path(base, "results", "figures")
dir.create(tabs, recursive = TRUE, showWarnings = FALSE)
dir.create(figs, recursive = TRUE, showWarnings = FALSE)

corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A")
prim <- read.csv(file.path(raw, "ai_scores_primary_corpusA.csv"),
                 stringsAsFactors = FALSE)
pert <- read.csv(file.path(raw, "ai_perturbations.csv"),
                 stringsAsFactors = FALSE)
d0 <- merge(corpus, prim, by = "case_id")
d0 <- d0[!d0$api_failure, ]
n <- nrow(d0)

num <- function(x, d = 3) formatC(x, digits = d, format = "f")
csv_write <- function(x, name) write.csv(x, file.path(summ, name),
                                         row.names = FALSE)

# ---- AI Table 1: raw evaluator performance ----
ch <- ai_characterize(d0$parsed_score, d0$Y, x = d0$X, group = d0$A)
cm <- ai_confidence_metrics(d0$parsed_confidence, d0$parsed_score - d0$Y)
t1 <- data.frame(
  metric = c("n", "bias", "MAE", "RMSE", "Pearson", "Spearman",
             "calibration_intercept", "calibration_slope",
             "max_abs_local_bias", "group_bias_A0", "group_bias_A1",
             "cor(confidence,-|error|)", "P(|error|>10 | C>90)",
             "review_needed_rate"),
  value = c(n, ch$bias, ch$mae, ch$rmse, ch$pearson, ch$spearman,
            ch$cal_intercept, ch$cal_slope,
            max(abs(ch$local$bias), na.rm = TRUE),
            ch$group_bias["0"], ch$group_bias["1"],
            cm$cor_conf_neg_abs_err, cm$p_severe_overconfident,
            mean(d0$parsed_review_needed))
)
csv_write(t1, "ai_table1_raw_evaluator.csv")

# ---- AI Table 2: prompt/model sensitivity ----
eval_cfg <- function(score_vec, y_vec) {
  ok <- is.finite(score_vec) & is.finite(y_vec)
  c(bias = mean(score_vec[ok] - y_vec[ok]),
    rmse = sqrt(mean((score_vec[ok] - y_vec[ok])^2)))
}
p0v <- prim[!prim$api_failure, c("case_id", "parsed_score")]
rows2 <- list()
e0 <- eval_cfg(p0v$parsed_score[match(d0$case_id, p0v$case_id)], d0$Y)
rows2[[1]] <- data.frame(config = "P0_pro", n_valid = nrow(p0v),
                         n_total = nrow(prim), valid_rate = nrow(p0v) / nrow(prim),
                         bias_vs_Y = e0[["bias"]], rmse_vs_Y = e0[["rmse"]],
                         rank_cor_vs_P0 = NA)
for (pj in c("prompt_P1", "prompt_P2", "prompt_P3", "flash", "thinking")) {
  if (pj == "flash") {
    d <- rbind(read.csv(file.path(raw, "behavior_flash_1_750.csv"),
                        stringsAsFactors = FALSE),
               read.csv(file.path(raw, "behavior_flash_751_1500.csv"),
                        stringsAsFactors = FALSE))
  } else if (pj == "thinking") {
    d <- rbind(read.csv(file.path(raw, "behavior_thinking_1_375.csv"),
                        stringsAsFactors = FALSE),
               read.csv(file.path(raw, "behavior_thinking_376_750.csv"),
                        stringsAsFactors = FALSE))
  } else {
    d <- read.csv(file.path(raw, paste0("behavior_", pj, "_1_1000.csv")),
                  stringsAsFactors = FALSE)
  }
  dv <- d[!d$api_failure, ]
  common <- intersect(dv$case_id, d0$case_id)
  sc <- dv$score[match(common, dv$case_id)]
  yv <- d0$Y[match(common, d0$case_id)]
  p0c <- p0v$parsed_score[match(common, p0v$case_id)]
  ev <- eval_cfg(sc, yv)
  rows2[[length(rows2) + 1L]] <- data.frame(
    config = pj, n_valid = length(common), n_total = nrow(d),
    valid_rate = length(common) / nrow(d),
    bias_vs_Y = ev[["bias"]], rmse_vs_Y = ev[["rmse"]],
    rank_cor_vs_P0 = cor(sc, p0c, method = "spearman")
  )
}
t2 <- do.call(rbind, rows2)
csv_write(t2, "ai_table2_prompt_model_sensitivity.csv")

# ---- AI Table 3/5: Block A ----
filesA <- list.files(raw, pattern = "^AI_A_.*_mask2000\\.rds$", full.names = TRUE)
dfA <- do.call(rbind, lapply(filesA, readRDS))
aggA <- aggregate(cbind(ise, sup_error) ~ scenario_id + method, data = dfA,
                  FUN = mean)
ntA <- aggregate(negative_transfer ~ scenario_id + method, data = dfA,
                 FUN = mean)
lamA <- aggregate(lambda_hat ~ scenario_id, data = dfA, FUN = mean)
ghA <- aggregate(cbind(G_hat, H_hat) ~ scenario_id, data = dfA, FUN = mean)
wA <- merge(reshape(aggA[, c("scenario_id","method","ise")],
                    idvar="scenario_id", timevar="method", direction="wide"),
            reshape(ntA, idvar="scenario_id", timevar="method",
                    direction="wide"), by="scenario_id")
wA <- merge(wA, lamA, by="scenario_id")
wA <- merge(wA, ghA, by="scenario_id")
wA$design <- sub("^AI_A_(V[0-9])_.*", "\\1", wA$scenario_id)
wA$p <- as.numeric(sub("^.*_p", "", wA$scenario_id))
wA$rel_gain_Adaptive <- 100*(wA$ise.X_anchor - wA$ise.Adaptive)/wA$ise.X_anchor
csv_write(wA, "ai_table3_blockA.csv")

# ---- AI Table 4: Block B ----
filesB <- list.files(raw, pattern = "^AI_B_.*_mask2000\\.rds$", full.names = TRUE)
dfB <- do.call(rbind, lapply(filesB, readRDS))
aggB <- aggregate(cbind(ise, sup_error) ~ scenario_id + method, data = dfB,
                  FUN = mean)
ntB <- aggregate(negative_transfer ~ scenario_id + method, data = dfB,
                 FUN = mean)
lamB <- aggregate(lambda_hat ~ scenario_id, data = dfB, FUN = mean)
ghB <- aggregate(cbind(G_hat, H_hat) ~ scenario_id, data = dfB, FUN = mean)
wB <- merge(reshape(aggB[, c("scenario_id","method","ise")],
                    idvar="scenario_id", timevar="method", direction="wide"),
            reshape(ntB, idvar="scenario_id", timevar="method",
                    direction="wide"), by="scenario_id")
wB <- merge(wB, lamB, by="scenario_id")
wB <- merge(wB, ghB, by="scenario_id")
wB$surrogate <- sub("^AI_B_(AI[0-9]+)_.*", "\\1", wB$scenario_id)
wB$design <- sub("^AI_B_AI[0-9]+_(V[0-9])_.*", "\\1", wB$scenario_id)
wB$p <- as.numeric(sub("^.*_p", "", wB$scenario_id))
wB$rel_gain_Adaptive <- 100*(wB$ise.X_anchor - wB$ise.Adaptive)/wB$ise.X_anchor
csv_write(wB, "ai_table4_blockB.csv")

# ---- AI Table 6: confidence ----
conf_rows <- data.frame(
  config = c("AI0_V4", "AI9_V4"),
  ise_adaptive = c(wA$ise.Adaptive[wA$scenario_id == "AI_A_V4_p0.100"],
                   wB$ise.Adaptive[wB$scenario_id == "AI_B_AI9_V4_p0.10"]),
  lambda_hat = c(wA$lambda_hat[wA$scenario_id == "AI_A_V4_p0.100"],
                 wB$lambda_hat[wB$scenario_id == "AI_B_AI9_V4_p0.10"]),
  nt_adaptive = c(wA$negative_transfer.Adaptive[wA$scenario_id == "AI_A_V4_p0.100"],
                  wB$negative_transfer.Adaptive[wB$scenario_id == "AI_B_AI9_V4_p0.10"])
)
csv_write(conf_rows, "ai_table6_confidence.csv")

# ---- AI Table 7: equivalent fraction (all Block A designs) ----
eq_all <- do.call(rbind, lapply(unique(wA$design), function(v) {
  dd <- wA[wA$design == v, ]
  p_grid <- seq(0.025, 0.40, length.out = 200)
  interp <- approx(dd$p, dd$ise.X_anchor, xout = p_grid, rule = 2)$y
  do.call(rbind, lapply(seq_len(nrow(dd)), function(i) {
    r <- dd$ise.Adaptive[i]
    ok <- which(interp <= r)
    p_eq <- if (length(ok)) min(p_grid[ok]) else NA_real_
    data.frame(design = v, p = dd$p[i], risk_ai = r, p_eq = p_eq,
               ratio = p_eq / dd$p[i])
  }))
}))
csv_write(eq_all, "ai_table7_equivalent_fraction.csv")

# ---- AI Table 8: multiplier bands ----
bfiles <- list.files(raw, pattern = "_bands500\\.rds$", full.names = TRUE)
bdf <- do.call(rbind, lapply(bfiles, readRDS))
aggBd <- aggregate(cbind(simultaneous_coverage, integrated_band_width,
                         maximum_band_width) ~ scenario_id + method,
                   data = bdf, FUN = mean)
csv_write(aggBd, "ai_table8_bands.csv")

# ---- AI Figure 4: 2G-H vs realized full-borrowing benefit ----
scen4 <- rbind(
  data.frame(scenario_id = wA$scenario_id, block = "A",
             G = wA$G_hat, H = wA$H_hat,
             benefit = wA$ise.X_anchor - wA$ise.Full),
  data.frame(scenario_id = wB$scenario_id, block = "B",
             G = wB$G_hat, H = wB$H_hat,
             benefit = wB$ise.X_anchor - wB$ise.Full)
)
png(file.path(figs, "AIFig4_transfer_criterion.png"), width = 6.5, height = 5,
    units = "in", res = 150)
plot(2*scen4$G - scen4$H, scen4$benefit, pch = 19,
     col = ifelse(scen4$block == "A", "black", "blue"),
     xlab = expression(2*hat(G) - hat(H)),
     ylab = "Realized benefit of full borrowing",
     main = "AI Figure 4: transfer signal vs realized benefit")
abline(h = 0, v = 0, lty = 2)
legend("topleft", legend = c("Block A", "Block B"), pch = 19,
       col = c("black", "blue"), bty = "n")
dev.off()

# ---- AI Figure 5: lambda_hat vs p by design ----
png(file.path(figs, "AIFig5_lambda.png"), width = 6.5, height = 5,
    units = "in", res = 150)
for (v in unique(wA$design)) {
  dd <- wA[wA$design == v, ]
  if (v == "V1") plot(dd$p, dd$lambda_hat, type = "b", pch = 19,
                      ylim = c(0.5, 1), xlab = "p", ylab = expression(hat(lambda)),
                      main = "AI Figure 5: borrowing coefficient vs p")
  else lines(dd$p, dd$lambda_hat, type = "b", pch = as.numeric(sub("V","",v)) + 14)
}
legend("bottomright", legend = paste0("V", 1:5), pch = 15:19, bty = "n")
dev.off()

# ---- AI Figure 6: p vs ISE (V1) ----
v1 <- wA[wA$design == "V1", ]
png(file.path(figs, "AIFig6_frontier.png"), width = 6.5, height = 5,
    units = "in", res = 150)
plot(v1$p, v1$ise.X_anchor, type = "b", pch = 19, log = "y",
     ylim = range(c(v1$ise.X_anchor, v1$ise.Full, v1$ise.Adaptive,
                    v1$ise.Oracle_m)),
     xlab = "p", ylab = "ISE",
     main = "AI Figure 6: reference fraction vs risk")
lines(v1$p, v1$ise.Full, type = "b", pch = 17, col = "blue")
lines(v1$p, v1$ise.Adaptive, type = "b", pch = 15, col = "red")
lines(v1$p, v1$ise.Oracle_m, type = "b", pch = 8, col = "darkgreen")
legend("topright", legend = c("X_anchor", "Full", "Adaptive", "Oracle_m"),
       pch = c(19,17,15,8), col = c("black","blue","red","darkgreen"), bty = "n")
dev.off()

# ---- AI Figure 7: x0 -> lambda_hat with local AI RMSE ----
x0files <- list.files(raw, pattern = "^AIFIG7_.*_mask500\\.rds$", full.names = TRUE)
x0df <- do.call(rbind, lapply(x0files, readRDS))
lam7 <- aggregate(lambda_hat ~ scenario_id, data = x0df[x0df$method == "Adaptive", ],
                  FUN = mean)
x0vals <- c(m05 = -0.5, p05 = 0.5)
lam7$x0 <- x0vals[sub("^AIFIG7_x0_", "", lam7$scenario_id)]
lam0 <- wA$lambda_hat[wA$scenario_id == "AI_A_V1_p0.100"]
x0all <- rbind(lam7[, c("x0", "lambda_hat")], data.frame(x0 = 0, lambda_hat = lam0))
png(file.path(figs, "AIFig7_local_borrowing.png"), width = 6.5, height = 5,
    units = "in", res = 150)
plot(x0all$x0, x0all$lambda_hat, type = "b", pch = 19, ylim = c(0, 1),
     xlab = expression(x[0]), ylab = expression(E(hat(lambda)(x[0]))),
     main = "AI Figure 7: borrowing coefficient across target points")
dev.off()

# ---- AI Figure 8: failure map heatmap ----
b1 <- wB[wB$design == "V1", ]
mat8 <- matrix(b1$rel_gain_Adaptive, nrow = 10, byrow = TRUE,
               dimnames = list(paste0("AI", 1:10), paste0("p=", c(0.05,0.10,0.20))))
png(file.path(figs, "AIFig8_failure_map.png"), width = 6, height = 7,
    units = "in", res = 150)
image(seq_len(10), seq_len(3), mat8, col = heat.colors(30),
      xlab = "Surrogate", ylab = "Reference fraction",
      main = "AI Figure 8: failure map (adaptive gain %)", axes = FALSE)
axis(1, at = seq_len(10), labels = paste0("AI", 1:10), las = 2, cex.axis = 0.7)
axis(2, at = seq_len(3), labels = c(0.05, 0.10, 0.20))
box()
dev.off()

# ---- AI Figure 9: equivalent fraction ----
png(file.path(figs, "AIFig9_eq_fraction.png"), width = 6.5, height = 5,
    units = "in", res = 150)
for (v in unique(eq_all$design)) {
  dd <- eq_all[eq_all$design == v, ]
  if (v == "V1") plot(dd$p, dd$ratio, type = "b", pch = 19, ylim = c(0, 4),
                      xlab = "p", ylab = expression(p[eq]/p),
                      main = "AI Figure 9: equivalent expert-review fraction")
  else lines(dd$p, dd$ratio, type = "b",
             pch = as.numeric(sub("V","",v)) + 14)
}
abline(h = 1, lty = 2)
legend("topright", legend = paste0("V", 1:5), pch = 15:19, bty = "n")
dev.off()

# ---- AI Figure 10: prompt/model sensitivity ----
png(file.path(figs, "AIFig10_prompt_model.png"), width = 7, height = 5,
    units = "in", res = 150)
par(mar = c(7, 4, 3, 1))
barplot(t2$valid_rate, names.arg = t2$config, las = 2, ylim = c(0, 1),
        col = "steelblue", ylab = "Valid response rate",
        main = "AI Figure 10: prompt/model sensitivity")
abline(h = 0.9, lty = 2)
dev.off()

# ---- AI Figure 11: paired effects ----
fp <- read.csv(file.path(raw, "behavior_framing_pos_1_500.csv"), stringsAsFactors = FALSE)
fn <- read.csv(file.path(raw, "behavior_framing_neg_1_500.csv"), stringsAsFactors = FALSE)
g0 <- read.csv(file.path(raw, "behavior_group_A0_1_500.csv"), stringsAsFactors = FALSE)
g1 <- read.csv(file.path(raw, "behavior_group_A1_1_500.csv"), stringsAsFactors = FALSE)
vb <- read.csv(file.path(raw, "behavior_verbose_1_500.csv"), stringsAsFactors = FALSE)
em <- read.csv(file.path(raw, "behavior_embedded_1_300.csv"), stringsAsFactors = FALSE)
pair_delta <- function(a, b) {
  score_of <- function(x) {
    if ("score" %in% names(x)) x$score else x$parsed_score
  }
  ok_of <- function(x) {
    if ("api_failure" %in% names(x)) !x$api_failure else rep(TRUE, nrow(x))
  }
  common <- intersect(a$case_id[ok_of(a)], b$case_id[ok_of(b)])
  score_of(a)[match(common, a$case_id)] -
    score_of(b)[match(common, b$case_id)]
}
d_f <- pair_delta(fp, fn)
d_g <- pair_delta(g1, g0)
d_v <- pair_delta(vb, p0v)
d_e <- pair_delta(em, p0v)
png(file.path(figs, "AIFig11_paired_effects.png"), width = 6.5, height = 5,
    units = "in", res = 150)
means <- c(framing = mean(d_f), group = mean(d_g), verbosity = mean(d_v),
           embedded = mean(d_e))
sds <- c(sd(d_f), sd(d_g), sd(d_v), sd(d_e)) / sqrt(c(length(d_f), length(d_g),
                                                      length(d_v), length(d_e)))
bp <- barplot(means, ylim = c(-0.15, 0.15), col = "gray",
              ylab = "Mean score difference",
              main = "AI Figure 11: framing/group/verbosity/instruction effects")
arrows(bp, means - 1.96 * sds, bp, means + 1.96 * sds, angle = 90, code = 3, length = 0.05)
abline(h = 0)
dev.off()

# ---- AI Figure 12: band coverage ----
png(file.path(figs, "AIFig12_band_coverage.png"), width = 6.5, height = 5,
    units = "in", res = 150)
plot(seq_len(nrow(aggBd)), aggBd$simultaneous_coverage, pch = 19,
     col = ifelse(aggBd$method == "Adaptive", "blue", "black"),
     ylim = c(0.85, 1), ylab = "Simultaneous coverage", xlab = "",
     xaxt = "n",
     main = "AI Figure 12: multiplier-band coverage")
axis(1, at = seq_len(nrow(aggBd)), labels = aggBd$scenario_id,
     las = 2, cex.axis = 0.5)
abline(h = 0.95, lty = 2)
abline(h = c(0.92, 0.98), lty = 3, col = "gray")
legend("bottomleft", legend = c("X_anchor", "Adaptive"), pch = 19,
       col = c("black", "blue"), bty = "n")
dev.off()

cat("AI tables and figures written.\n")
