# WP-AI1: generate, stratify, and freeze the three synthetic corpora + truth.
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))

base <- file.path(root, "simulation", "ai_expert")
frozen <- file.path(base, "corpus", "frozen_cases")
truth_dir <- file.path(base, "corpus", "truth")
dir.create(frozen, recursive = TRUE, showWarnings = FALSE)
dir.create(truth_dir, recursive = TRUE, showWarnings = FALSE)

specs <- c(A = 3000L, B = 1500L, C = 1500L)
corpus_seeds <- c(A = 20260811L, B = 20260812L, C = 20260813L)
for (nm in names(specs)) {
  dossier_path <- file.path(frozen, paste0("corpus_", nm, ".jsonl"))
  case_ids <- ai_frozen_case_ids(dossier_path)
  if (is.null(case_ids)) {
    legacy_path <- file.path(base, "corpus", paste0("corpus_", nm, ".rds"))
    if (file.exists(legacy_path)) case_ids <- readRDS(legacy_path)$case_id
  }
  if (is.null(case_ids)) {
    cat("Generating new frozen corpus", nm, "\n")
    corpus <- generate_corpus(specs[[nm]], seed = corpus_seeds[[nm]])
  } else {
    cat("Reconstructing frozen dossier identities for corpus", nm, "\n")
    stopifnot(length(case_ids) == specs[[nm]])
    corpus <- ai_reconstruct_frozen_corpus(case_ids, corpus_seeds[[nm]])
  }
  ai_write_corpus_bundle(corpus, file.path(base, "corpus"), nm,
                         dossier_seed_base = 20260812L)
  qc <- ai_qc_leakage(corpus, readLines(dossier_path, warn = FALSE))
  if (!qc$pass) {
    stop("Leakage QC failed for corpus ", nm, call. = FALSE)
  }
  cat("Corpus", nm, ":", nrow(corpus), "cases, leakage clean\n")
}

truth_specs <- data.frame(
  x0 = c(-0.5, 0, 0.5), label = c("m05", "0", "p05"),
  seed = c(20260821L, 20260811L, 20260822L), stringsAsFactors = FALSE
)
for (j in seq_len(nrow(truth_specs))) {
  truth_path <- file.path(
    truth_dir,
    paste0("truth_x0_", truth_specs$label[j], "_h0.3.rds")
  )
  truth_current <- if (file.exists(truth_path)) readRDS(truth_path) else NULL
  if (is.null(truth_current) ||
      !identical(truth_current$reference_version, ai_reference_version)) {
    cat("Generating truth sample (10^6) at x0 =", truth_specs$x0[j], "\n")
    truth <- ai_make_truth(
      x0 = truth_specs$x0[j], h = 0.3, n = 1e6,
      seed = truth_specs$seed[j], path = truth_path
    )
  } else {
    truth <- truth_current
  }
  cat("Truth ready at x0 =", truth$x0, ": n =", truth$n,
      "thresholds =", length(truth$tau), "\n")
}
ai_audit_log(root, "AI_EXPERIMENT_LOG.md",
             paste("P0-C canonical corpus generation complete:",
                   "A=3000, B=1500, C=1500; fixed-bias truth frozen;",
                   "dossier/evidence/truth physically separated."))
