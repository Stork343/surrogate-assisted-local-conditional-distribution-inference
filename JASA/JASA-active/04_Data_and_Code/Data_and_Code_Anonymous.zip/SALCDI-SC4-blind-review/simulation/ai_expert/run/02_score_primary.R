# WP-AI2: score corpus cases with the primary configuration (resumable,
# parallel, cached). Usage: Rscript 02_score_primary.R <root> <cores> [A|B|C]
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
corpus_id <- if (length(commandArgs(trailingOnly = TRUE)) > 2) {
  toupper(commandArgs(trailingOnly = TRUE)[3])
} else {
  "A"
}
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
if (!nzchar(Sys.getenv("DEEPSEEK_API_KEY", unset = ""))) {
  stop("BLOCKED: DEEPSEEK_API_KEY is not set.", call. = FALSE)
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
cfg <- ai_api_config(file.path(base, "config", "api_config.yml"))
system_prompt <- paste(readLines(file.path(base, "prompts",
                                           "system_primary.txt"), warn = FALSE),
                       collapse = "\n")
rubric <- paste(readLines(file.path(base, "prompts", "rubric_primary.txt"),
                          warn = FALSE), collapse = "\n")
cache_dir <- file.path(base, "cache", "deepseek")
dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), corpus_id,
                                include_truth = FALSE)

work <- lapply(seq_len(nrow(corpus)), function(i) {
  row <- corpus[i, ]
  dossier <- ai_dossier_text(row, seed = 20260812L + i)
  user_prompt <- paste(rubric, dossier, "Return only valid JSON.", sep = "\n\n")
  params <- list(temperature = cfg$temperature, thinking = FALSE,
                 max_tokens = cfg$max_tokens,
                 response_format = cfg$response_format)
  req_hash <- ai_request_hash(cfg$model_primary, system_prompt, user_prompt,
                              params)
  list(case_id = row$case_id, user_prompt = user_prompt,
       request_hash = req_hash)
})
cached_flag <- vapply(work, function(w) {
  !is.null(ai_cache_lookup(cache_dir, w$request_hash))
}, logical(1))
cat("Corpus", corpus_id, "cases:", length(work),
    "cached:", sum(cached_flag), "\n")
todo <- which(!cached_flag)
if (length(todo) == 0L) {
  cat("All cases already cached.\n")
} else {
  work_todo <- work[todo]
  worker <- function(i) {
    w <- work_todo[[i]]
    resp <- ai_call_deepseek(
      system_prompt, w$user_prompt, cfg,
      failure_dir = file.path(cache_dir, "failures"),
      request_hash = w$request_hash
    )
    if (resp$status == "failed") {
      return(list(status = "failed", case_id = w$case_id,
                  request_hash = w$request_hash,
                  error = resp$error$failure_type %||% "api"))
    }
    content <- resp$content
    list(status = "ok", case_id = w$case_id, request_hash = w$request_hash,
         content = content, parsed = resp$parsed, resp = resp)
  }
  if (cores == 1) {
    res <- lapply(seq_along(todo), worker)
  } else {
    cl <- parallel::makeCluster(cores)
    on.exit(parallel::stopCluster(cl))
    parallel::clusterExport(cl, "root", envir = environment())
    parallel::clusterEvalQ(cl, {
      pkgload::load_all(root, quiet = TRUE)
      source(file.path(root, "simulation", "config", "simulation_constants.R"))
      invisible(lapply(file.path(root, "simulation",
                                 simulation_source_files()), source))
      ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
      invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
    })
    parallel::clusterExport(cl, c("work_todo", "system_prompt", "cfg",
                                  "worker"), envir = environment())
    res <- parallel::parLapply(cl, seq_along(todo), function(i) worker(i))
  }
  n_ok <- 0
  n_fail <- 0
  for (i in seq_along(todo)) {
    out <- res[[i]]
    if (out$status != "ok") {
      n_fail <- n_fail + 1
      ai_audit_log(root, "AI_FAILURE_LOG.md",
                   paste("case", out$case_id, out$error))
      next
    }
    clean <- ai_clean_parsed(out$parsed)
    entry <- data.frame(
      case_id = out$case_id, request_hash = out$request_hash,
      model = cfg$model_primary, thinking_mode = FALSE,
      temperature = cfg$temperature, prompt_id = "P0",
      prompt_hash = out$request_hash,
      timestamp_utc = format(Sys.time(), tz = "UTC"),
      system_fingerprint = out$resp$body$system_fingerprint %||% NA_character_,
      finish_reason = out$resp$body$choices[[1]]$finish_reason %||% NA_character_,
      input_tokens = out$resp$body$usage$prompt_tokens %||% NA_integer_,
      output_tokens = out$resp$body$usage$completion_tokens %||% NA_integer_,
      retry_count = out$resp$attempt, raw_response = out$content,
      parsed_score = clean$score, parsed_confidence = clean$confidence,
      parsed_review_needed = clean$review_needed, parsed_grade = clean$grade,
      api_failure = FALSE, stringsAsFactors = FALSE
    )
    ai_cache_write(cache_dir, entry,
                   file.path(cache_dir, paste0(out$request_hash, ".json")))
    n_ok <- n_ok + 1
    if (n_ok %% 100 == 0) {
      cat("Scored", n_ok, "new cases at", format(Sys.time()), "\n")
    }
  }
  cat("New scored:", n_ok, "failed:", n_fail, "\n")
}

scores <- do.call(rbind, lapply(seq_len(nrow(corpus)), function(i) {
  w <- work[[i]]
  cached <- ai_cache_lookup(cache_dir, w$request_hash)
  if (is.null(cached)) {
    data.frame(case_id = w$case_id, parsed_score = NA_real_,
               parsed_confidence = NA_real_, parsed_review_needed = NA,
               parsed_grade = NA_character_, api_failure = TRUE,
               stringsAsFactors = FALSE)
  } else {
    data.frame(case_id = w$case_id,
               parsed_score = cached$parsed_score,
               parsed_confidence = cached$parsed_confidence,
               parsed_review_needed = cached$parsed_review_needed,
               parsed_grade = cached$parsed_grade,
               api_failure = cached$api_failure, stringsAsFactors = FALSE)
  }
}))
out_path <- file.path(base, "results", "raw",
                      paste0("ai_scores_primary_corpus", corpus_id, ".csv"))
write.csv(scores, out_path, row.names = FALSE)
cat("Primary scores written:", out_path, "| complete:",
    sum(!scores$api_failure), "/", nrow(scores), "\n")
