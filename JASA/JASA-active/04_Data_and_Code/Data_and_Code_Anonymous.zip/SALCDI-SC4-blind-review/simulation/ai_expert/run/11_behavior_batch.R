# WP-AI4 generic behavior batch runner.
# Usage: Rscript 11_behavior_batch.R <root> <cores> <job> <start> <end> [n_reps]
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
job <- commandArgs(trailingOnly = TRUE)[3]
start_i <- as.integer(commandArgs(trailingOnly = TRUE)[4])
end_i <- as.integer(commandArgs(trailingOnly = TRUE)[5])
n_reps <- as.integer(commandArgs(trailingOnly = TRUE)[6])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
if (is.na(start_i)) start_i <- 1L
if (is.na(end_i)) end_i <- start_i
if (is.na(n_reps)) n_reps <- 1L
if (!nzchar(Sys.getenv("DEEPSEEK_API_KEY", unset = ""))) {
  stop("BLOCKED: DEEPSEEK_API_KEY is not set.", call. = FALSE)
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
cfg <- ai_api_config(file.path(base, "config", "api_config.yml"))
prompt_dir <- file.path(base, "prompts")
system_prompt <- paste(readLines(file.path(prompt_dir, "system_primary.txt"),
                                 warn = FALSE), collapse = "\n")
rubric <- paste(readLines(file.path(prompt_dir, "rubric_primary.txt"),
                          warn = FALSE), collapse = "\n")
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A",
                                include_truth = FALSE)

job_config <- list(
  repeatability = list(model = cfg$model_primary, temperature = 0,
                       thinking = FALSE, prompt = "system_primary.txt",
                       variant = "normal", reps = 5),
  temperature = list(model = cfg$model_primary, temperature = 1.0,
                     thinking = FALSE, prompt = "system_primary.txt",
                     variant = "normal", reps = 5),
  prompt_P1 = list(model = cfg$model_primary, temperature = 0,
                   thinking = FALSE, prompt = "prompt_minimal.txt",
                   variant = "normal", reps = 1),
  prompt_P2 = list(model = cfg$model_primary, temperature = 0,
                   thinking = FALSE, prompt = "prompt_conservative.txt",
                   variant = "normal", reps = 1),
  prompt_P3 = list(model = cfg$model_primary, temperature = 0,
                   thinking = FALSE, prompt = "prompt_uncertainty.txt",
                   variant = "normal", reps = 1),
  flash = list(model = cfg$model_flash, temperature = 0,
               thinking = FALSE, prompt = "system_primary.txt",
               variant = "normal", reps = 1),
  thinking = list(model = cfg$model_primary, temperature = 0,
                  thinking = TRUE, prompt = "system_primary.txt",
                  variant = "normal", reps = 1),
  framing_pos = list(model = cfg$model_primary, temperature = 0,
                     thinking = FALSE, prompt = "system_primary.txt",
                     variant = "framing_pos", reps = 1),
  framing_neg = list(model = cfg$model_primary, temperature = 0,
                     thinking = FALSE, prompt = "system_primary.txt",
                     variant = "framing_neg", reps = 1),
  group_A0 = list(model = cfg$model_primary, temperature = 0,
                  thinking = FALSE, prompt = "system_primary.txt",
                  variant = "group_A0", reps = 1),
  group_A1 = list(model = cfg$model_primary, temperature = 0,
                  thinking = FALSE, prompt = "system_primary.txt",
                  variant = "group_A1", reps = 1),
  verbose = list(model = cfg$model_primary, temperature = 0,
                 thinking = FALSE, prompt = "system_primary.txt",
                 variant = "verbose", reps = 1),
  embedded = list(model = cfg$model_primary, temperature = 0,
                  thinking = FALSE, prompt = "system_primary.txt",
                  variant = "embedded", reps = 1)
)
if (!job %in% names(job_config)) {
  stop("Unknown job `", job, "`.", call. = FALSE)
}
jc <- job_config[[job]]
prompt_text <- paste(readLines(file.path(prompt_dir, jc$prompt),
                               warn = FALSE), collapse = "\n")
user_system <- if (jc$prompt == "system_primary.txt") system_prompt else prompt_text
user_rubric <- if (jc$prompt == "system_primary.txt") rubric else ""

cache_dir <- file.path(base, "cache", "deepseek")
dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
idx <- start_i:min(end_i, nrow(corpus))
work <- lapply(idx, function(i) {
  row <- corpus[i, ]
  dossier <- switch(jc$variant,
    normal = ai_dossier_text(row, seed = 20260812L + i),
    framing_pos = ai_dossier_text(row, seed = 20260812L + i,
                                  framing = "positive"),
    framing_neg = ai_dossier_text(row, seed = 20260812L + i,
                                  framing = "negative"),
    group_A0 = {
      r <- row; r$A <- 0
      ai_dossier_text(r, seed = 20260812L + i, group_attr = TRUE)
    },
    group_A1 = {
      r <- row; r$A <- 1
      ai_dossier_text(r, seed = 20260812L + i, group_attr = TRUE)
    },
    verbose = ai_dossier_text(row, seed = 20260812L + i, verbose = TRUE),
    embedded = ai_dossier_text(row, seed = 20260812L + i,
                               embedded_instruction = TRUE),
    stop("Unknown variant")
  )
  user_prompt <- if (nzchar(user_rubric)) {
    paste(user_rubric, dossier, "Return only valid JSON.", sep = "\n\n")
  } else {
    paste(dossier, "Return only valid JSON.", sep = "\n\n")
  }
  params <- list(model = jc$model, temperature = jc$temperature,
                 thinking = jc$thinking,
                 max_tokens = if (jc$thinking) 4096 else cfg$max_tokens,
                 response_format = cfg$response_format)
  list(case_id = row$case_id, user_prompt = user_prompt,
       request_hash = ai_request_hash(jc$model, user_system, user_prompt,
                                      params))
})
cat("Job", job, "cases:", length(work), "reps:", jc$reps, "\n")

worker <- function(job_item, rep_id) {
  w <- job_item
  cached <- ai_cache_lookup(cache_dir, w$request_hash)
  if (!is.null(cached)) {
    return(list(status = "cached", case_id = w$case_id, rep = rep_id,
                request_hash = w$request_hash,
                parsed = list(score = cached$parsed_score,
                              confidence = cached$parsed_confidence,
                              review_needed = cached$parsed_review_needed,
                              grade = cached$parsed_grade)))
  }
  resp <- ai_call_deepseek(user_system, w$user_prompt, cfg,
                           model = jc$model, temperature = jc$temperature,
                           thinking = jc$thinking,
                           max_tokens = if (jc$thinking) 4096 else cfg$max_tokens,
                           failure_dir = file.path(cache_dir, "failures"),
                           request_hash = w$request_hash)
  if (resp$status == "failed") {
    return(list(status = "failed", case_id = w$case_id, rep = rep_id,
                request_hash = w$request_hash,
                error = resp$error$failure_type %||% "api"))
  }
  content <- resp$content
  list(status = "ok", case_id = w$case_id, rep = rep_id,
       request_hash = w$request_hash, content = content,
       parsed = resp$parsed, resp = resp)
}

tasks <- lapply(seq_along(work), function(j) {
  lapply(seq_len(jc$reps), function(r) list(j = j, rep = r))
})
tasks <- unlist(tasks, recursive = FALSE)
if (cores == 1) {
  res <- lapply(tasks, function(t) worker(work[[t$j]], t$rep))
} else {
  cl <- parallel::makeCluster(cores)
  on.exit(parallel::stopCluster(cl))
  parallel::clusterExport(cl, "root", envir = environment())
  parallel::clusterEvalQ(cl, {
    pkgload::load_all(root, quiet = TRUE)
    source(file.path(root, "simulation", "config", "simulation_constants.R"))
    invisible(lapply(file.path(root, "simulation",
                               simulation_source_files()), source))
    ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
    invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
  })
  parallel::clusterExport(cl, c("work", "jc", "user_system", "cfg",
                                "worker", "cache_dir"), envir = environment())
  res <- parallel::parLapply(cl, tasks, function(t) worker(work[[t$j]], t$rep))
}

for (o in res) {
  if (o$status != "ok") next
  clean <- ai_clean_parsed(o$parsed)
  entry <- data.frame(
    case_id = o$case_id, request_hash = o$request_hash,
    model = jc$model, thinking_mode = jc$thinking,
    temperature = jc$temperature, prompt_id = job,
    prompt_hash = o$request_hash,
    timestamp_utc = format(Sys.time(), tz = "UTC"),
    system_fingerprint = o$resp$body$system_fingerprint %||% NA_character_,
    finish_reason = o$resp$body$choices[[1]]$finish_reason %||% NA_character_,
    input_tokens = o$resp$body$usage$prompt_tokens %||% NA_integer_,
    output_tokens = o$resp$body$usage$completion_tokens %||% NA_integer_,
    retry_count = o$resp$attempt, raw_response = o$content,
    parsed_score = clean$score, parsed_confidence = clean$confidence,
    parsed_review_needed = clean$review_needed, parsed_grade = clean$grade,
    api_failure = FALSE, stringsAsFactors = FALSE
  )
  ai_cache_write(cache_dir, entry,
                 file.path(cache_dir, paste0(o$request_hash, ".json")))
}

out_rows <- lapply(res, function(o) {
  if (o$status == "failed") {
    return(data.frame(case_id = o$case_id, rep = o$rep,
                      request_hash = o$request_hash, job = job,
                      score = NA_real_, confidence = NA_real_,
                      review_needed = NA, grade = NA_character_,
                      api_failure = TRUE, stringsAsFactors = FALSE))
  }
  clean <- if (o$status == "cached") o$parsed else ai_clean_parsed(o$parsed)
  data.frame(case_id = o$case_id, rep = o$rep,
             request_hash = o$request_hash, job = job,
             score = as.numeric(clean$score),
             confidence = as.numeric(clean$confidence),
             review_needed = as.logical(clean$review_needed),
             grade = as.character(clean$grade),
             api_failure = FALSE, stringsAsFactors = FALSE)
})
out <- do.call(rbind, out_rows)
out_path <- file.path(base, "results", "raw",
                      paste0("behavior_", job, "_", start_i, "_", end_i, ".csv"))
write.csv(out, out_path, row.names = FALSE)
cat("Job", job, "done:", sum(!out$api_failure), "/", nrow(out), "->", out_path, "\n")
