# WP-AI5: generate AI1-AI10 variants from frozen raw scores (no API calls).
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
scores <- utils::read.csv(file.path(base, "results", "raw",
                                   "ai_scores_primary_corpusA.csv"),
                          stringsAsFactors = FALSE)
scores <- scores[!scores$api_failure, ]
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A")
corpus <- corpus[corpus$case_id %in% scores$case_id, ]
stopifnot(all(scores$case_id == corpus$case_id))
raw <- scores$parsed_score
conditional_truth_path <- file.path(
  base, "corpus", "truth", "conditional_quantiles_fixed_bias_v2.rds"
)
q <- ai_conditional_quantiles(
  corpus$X, probs = c(0.2, 0.8), path = conditional_truth_path
)
mu_s_x0 <- sum(epan_k((corpus$X - 0) / 0.3) * raw) /
  sum(epan_k((corpus$X - 0) / 0.3))
out <- data.frame(case_id = corpus$case_id, X = corpus$X, A = corpus$A,
                  D = corpus$D, Y = corpus$Y, S_raw = raw)
for (code in paste0("AI", 1:10)) {
  if (code == "AI9") {
    out[[code]] <- raw
  } else {
    out[[code]] <- ai_perturb(raw, corpus, code, x0 = 0, h = 0.3,
                              mu_s_x0 = mu_s_x0, q20 = q[, "q20"],
                              q80 = q[, "q80"])
  }
}
write.csv(out, file.path(base, "results", "raw",
                         "ai_perturbations.csv"), row.names = FALSE)
cat("Controlled failures written for AI1-AI10; raw score preserved as S_raw.\n")
