# WP-AI7: SALCDI downstream inference with masked human labels.
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
scores <- utils::read.csv(file.path(base, "results", "raw",
                                   "ai_scores_primary_corpusA.csv"),
                          stringsAsFactors = FALSE)
pert <- utils::read.csv(file.path(base, "results", "raw",
                                  "ai_perturbations.csv"),
                        stringsAsFactors = FALSE)
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A")
corpus <- merge(corpus, scores[, c("case_id", "parsed_score",
                                   "parsed_confidence", "api_failure")],
                by = "case_id")
corpus <- corpus[!corpus$api_failure, ]
corpus <- merge(corpus, pert[, c("case_id", "S_raw", paste0("AI", 1:10))],
                by = "case_id")
truth <- ai_read_truth(file.path(base, "corpus", "truth",
                                 "truth_x0_0_h0.3.rds"))
scenarios <- read.csv(file.path(base, "config", "ai_scenarios.csv"),
                      stringsAsFactors = FALSE)
scenarios <- scenarios[scenarios$block %in% c("A", "B"), ]
for (i in seq_len(nrow(scenarios))) {
  sr <- scenarios[i, ]
  corpus_work <- corpus
  if (sr$surrogate == "AI0") {
    corpus_work$S_AI <- corpus_work$S_raw
  } else {
    corpus_work$S_AI <- corpus_work[[sr$surrogate]]
  }
  corpus_work$C_AI <- if (sr$surrogate == "AI9") {
    rep(95, nrow(corpus_work))
  } else {
    corpus_work$parsed_confidence
  }
  scenario <- ai_scenario(sr$scenario_id, nrow(corpus), x0 = 0, h = 0.3,
                          p = sr$p, design = sr$design,
                          surrogate_code = sr$surrogate)
  cat("AI downstream", scenario$scenario_id, "start:", format(Sys.time()),
      "\n")
  ai_run_downstream(root, corpus_work, scenario, truth, n_mask = 2000L,
                    out_dir = file.path(base, "results", "raw"),
                    cores = cores)
  cat("  done:", format(Sys.time()), "\n")
}
