# WP-AI0: API engineering smoke test on 20 cases.
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
if (!nzchar(Sys.getenv("DEEPSEEK_API_KEY", unset = ""))) {
  stop("BLOCKED: DEEPSEEK_API_KEY is not set. Set it as an environment ",
       "variable before running API work packages.", call. = FALSE)
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))

corpus_dir <- file.path(root, "simulation", "ai_expert", "corpus")
corpus <- ai_load_corpus_bundle(corpus_dir, "A", include_truth = FALSE)
cfg <- ai_api_config(file.path(root, "simulation", "ai_expert", "config",
                               "api_config.yml"))
system_prompt <- readLines(file.path(root, "simulation", "ai_expert",
                                     "prompts", "system_primary.txt"),
                           warn = FALSE)
rubric <- readLines(file.path(root, "simulation", "ai_expert", "prompts",
                              "rubric_primary.txt"), warn = FALSE)
idx <- seq_len(min(20, nrow(corpus)))
cache_dir <- file.path(root, "simulation", "ai_expert", "cache", "deepseek")
dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
results <- vector("list", length(idx))
for (i in seq_along(idx)) {
  row <- corpus[idx[i], ]
  dossier <- ai_dossier_text(row, seed = 20260812L + i)
  user_prompt <- paste(rubric, dossier,
                       "Return only valid JSON.", sep = "\n\n")
  params <- list(temperature = cfg$temperature, thinking = cfg$thinking,
                 max_tokens = cfg$max_tokens,
                 response_format = cfg$response_format)
  req_hash <- ai_request_hash(cfg$model_primary, system_prompt, user_prompt,
                              params)
  cached <- ai_cache_lookup(cache_dir, req_hash)
  if (!is.null(cached)) {
    results[[i]] <- cached
    next
  }
  resp <- ai_call_deepseek(
    system_prompt, user_prompt, cfg,
    failure_dir = file.path(cache_dir, "failures"), request_hash = req_hash
  )
  if (resp$status == "failed") {
    results[[i]] <- data.frame(case_id = row$case_id,
                               request_hash = req_hash, model = cfg$model_primary,
                               api_failure = TRUE, raw_response = "",
                               parsed_score = NA_real_, stringsAsFactors = FALSE)
    next
  }
  content <- resp$content
  clean <- ai_clean_parsed(resp$parsed)
  entry <- data.frame(
    case_id = row$case_id, request_hash = req_hash,
    model = cfg$model_primary, thinking_mode = FALSE,
    temperature = cfg$temperature, prompt_id = "P0",
    prompt_hash = req_hash, timestamp_utc = format(Sys.time(), tz = "UTC"),
    system_fingerprint = resp$body$system_fingerprint %||% NA_character_,
    finish_reason = resp$body$choices[[1]]$finish_reason %||% NA_character_,
    input_tokens = resp$body$usage$prompt_tokens %||% NA_integer_,
    output_tokens = resp$body$usage$completion_tokens %||% NA_integer_,
    retry_count = resp$attempt, raw_response = content,
    parsed_score = clean$score, parsed_confidence = clean$confidence,
    parsed_review_needed = clean$review_needed, parsed_grade = clean$grade,
    api_failure = FALSE, stringsAsFactors = FALSE
  )
  ai_cache_write(cache_dir, entry, file.path(cache_dir,
                                             paste0(req_hash, ".json")))
  results[[i]] <- entry
  cat("Smoke case", i, "of", length(idx), "- score:", clean$score, "\n")
}
out <- do.call(rbind, results)
saveRDS(out, file.path(root, "simulation", "ai_expert", "results", "raw",
                       "api_smoke_20.rds"))
cat("API smoke complete; failures:", sum(out$api_failure), "\n")
