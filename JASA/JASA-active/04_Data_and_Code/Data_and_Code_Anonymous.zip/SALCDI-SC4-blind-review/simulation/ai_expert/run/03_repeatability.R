# WP-AI4a: repeatability, temperature, and stochasticity blocks (API).
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
if (!nzchar(Sys.getenv("DEEPSEEK_API_KEY", unset = ""))) {
  stop("BLOCKED: DEEPSEEK_API_KEY is not set.", call. = FALSE)
}
stop("WP-AI4a repeatability runner: implement after primary scoring is frozen.",
     call. = FALSE)
