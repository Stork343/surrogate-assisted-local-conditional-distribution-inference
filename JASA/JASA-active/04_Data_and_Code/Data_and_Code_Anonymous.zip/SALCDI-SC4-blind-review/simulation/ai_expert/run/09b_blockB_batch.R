# WP-AI7 Block B slice runner.
# Usage: Rscript 09b_blockB_batch.R <root> <cores> <start> <end>
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
start_i <- as.integer(commandArgs(trailingOnly = TRUE)[3])
end_i <- as.integer(commandArgs(trailingOnly = TRUE)[4])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
if (is.na(start_i)) start_i <- 1L
if (is.na(end_i)) end_i <- start_i
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
scores <- utils::read.csv(file.path(base, "results", "raw",
                                   "ai_scores_primary_corpusA.csv"),
                          stringsAsFactors = FALSE)
pert <- utils::read.csv(file.path(base, "results", "raw",
                                  "ai_perturbations.csv"),
                        stringsAsFactors = FALSE)
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A")
corpus <- merge(corpus, scores[, c("case_id", "parsed_score",
                                   "parsed_confidence", "api_failure")],
                by = "case_id")
corpus <- corpus[!corpus$api_failure, ]
corpus <- merge(corpus, pert[, c("case_id", "S_raw", paste0("AI", 1:10))],
                by = "case_id")
truth <- ai_read_truth(file.path(base, "corpus", "truth",
                                 "truth_x0_0_h0.3.rds"))
scenarios <- utils::read.csv(file.path(base, "config", "ai_scenarios.csv"),
                             stringsAsFactors = FALSE)
sel <- scenarios[scenarios$block == "B", ]
sel <- sel[start_i:min(end_i, nrow(sel)), , drop = FALSE]
for (i in seq_len(nrow(sel))) {
  sr <- sel[i, ]
  cw <- corpus
  cw$S_AI <- if (sr$surrogate == "AI0") cw$S_raw else cw[[sr$surrogate]]
  cw$C_AI <- if (sr$surrogate == "AI9") rep(95, nrow(cw)) else cw$parsed_confidence
  scenario <- ai_scenario(sr$scenario_id, nrow(cw), 0, 0.3, sr$p,
                          sr$design, sr$surrogate)
  cat(scenario$scenario_id, "start:", format(Sys.time()), "\n")
  ai_run_downstream(root, cw, scenario, truth, n_mask = 2000L,
                    out_dir = file.path(base, "results", "raw"), cores = cores)
  cat("  done:", format(Sys.time()), "\n")
}
