# WP-AI6: validate reference-sampling designs V1-V5.
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
scores <- utils::read.csv(file.path(base, "results", "raw",
                                   "ai_scores_primary_corpusA.csv"),
                          stringsAsFactors = FALSE)
scores <- scores[!scores$api_failure, ]
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A")
corpus <- corpus[corpus$case_id %in% scores$case_id, ]
corpus$S_AI <- scores$parsed_score
corpus$C_AI <- scores$parsed_confidence
out <- do.call(rbind, lapply(paste0("V", 1:5), function(v) {
  do.call(rbind, lapply(c(0.025, 0.05, 0.10, 0.20, 0.40), function(p) {
    pi <- ai_review_pi(corpus, v, p, confidence = corpus$C_AI)
    data.frame(design = v, p = p, mean_pi = mean(pi),
               min_pi = min(pi), max_pi = max(pi),
               stringsAsFactors = FALSE)
  }))
}))
print(out, digits = 4, row.names = FALSE)
write.csv(out, file.path(base, "results", "summaries",
                         "reference_design_diagnostics.csv"), row.names = FALSE)
