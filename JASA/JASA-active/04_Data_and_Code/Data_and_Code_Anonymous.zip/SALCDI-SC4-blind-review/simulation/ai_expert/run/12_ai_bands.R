# WP-AI8: multiplier bands on representative AI scenarios.
root <- commandArgs(trailingOnly = TRUE)[1]
cores <- as.integer(commandArgs(trailingOnly = TRUE)[2])
if (is.na(root) || !nzchar(root)) root <- "."
if (is.na(cores)) cores <- 1
pkgload::load_all(root, quiet = TRUE)
source(file.path(root, "simulation", "config", "simulation_constants.R"))
source_simulation_environment(root)
ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
base <- file.path(root, "simulation", "ai_expert")
scores <- utils::read.csv(file.path(base, "results", "raw",
                                   "ai_scores_primary_corpusA.csv"),
                          stringsAsFactors = FALSE)
pert <- utils::read.csv(file.path(base, "results", "raw",
                                  "ai_perturbations.csv"),
                        stringsAsFactors = FALSE)
corpus <- ai_load_corpus_bundle(file.path(base, "corpus"), "A")
corpus <- merge(corpus, scores[, c("case_id", "parsed_score",
                                   "parsed_confidence", "api_failure")],
                by = "case_id")
corpus <- corpus[!corpus$api_failure, ]
corpus <- merge(corpus, pert[, c("case_id", "S_raw", paste0("AI", 1:10))],
                by = "case_id")
truth <- ai_read_truth(file.path(base, "corpus", "truth",
                                 "truth_x0_0_h0.3.rds"))

band_scenarios <- list(
  list(id = "AIBAND_V1_p0.10_raw", surrogate = "AI0", design = "V1", p = 0.10),
  list(id = "AIBAND_V1_p0.05_raw", surrogate = "AI0", design = "V1", p = 0.05),
  list(id = "AIBAND_V5_p0.10_raw", surrogate = "AI0", design = "V5", p = 0.10),
  list(id = "AIBAND_V4_p0.10_raw", surrogate = "AI0", design = "V4", p = 0.10),
  list(id = "AIBAND_V1_p0.10_AI4", surrogate = "AI4", design = "V1", p = 0.10),
  list(id = "AIBAND_V1_p0.10_AI8", surrogate = "AI8", design = "V1", p = 0.10)
)
for (bs in band_scenarios) {
  cw <- corpus
  cw$S_AI <- if (bs$surrogate == "AI0") cw$S_raw else cw[[bs$surrogate]]
  cw$C_AI <- if (bs$surrogate == "AI9") rep(95, nrow(cw)) else cw$parsed_confidence
  scenario <- ai_scenario(bs$id, nrow(cw), 0, 0.3, bs$p, bs$design,
                          bs$surrogate)
  cat(bs$id, "start:", format(Sys.time()), "\n")
  ai_run_bands(root, cw, scenario, truth, n_mask = 500L,
               out_dir = file.path(base, "results", "raw"), cores = cores)
  cat("  done:", format(Sys.time()), "\n")
}
