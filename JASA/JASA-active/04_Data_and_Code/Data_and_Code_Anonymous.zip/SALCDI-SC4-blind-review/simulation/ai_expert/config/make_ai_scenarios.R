# AI experimental matrix (AI protocol section 39).
root <- if (length(commandArgs(trailingOnly = TRUE)) > 0) {
  commandArgs(trailingOnly = TRUE)[1]
} else {
  "."
}
out_path <- file.path(root, "simulation", "ai_expert", "config",
                      "ai_scenarios.csv")

rows <- list()
add_row <- function(id, block, surrogate, design, p, prompt = "P0",
                    model = "deepseek-v4-pro", thinking = FALSE,
                    confidence_block = FALSE, stochastic = "first") {
  rows[[length(rows) + 1L]] <<- data.frame(
    scenario_id = id, block = block, surrogate = surrogate,
    design = design, p = p, prompt = prompt, model = model,
    thinking = thinking, confidence_block = confidence_block,
    stochastic = stochastic, stringsAsFactors = FALSE
  )
}

# Block A: raw DeepSeek, V1-V5, five reference fractions.
for (v in paste0("V", 1:5)) {
  for (pv in c(0.025, 0.05, 0.10, 0.20, 0.40)) {
    add_row(paste0("AI_A_", v, "_p", format(pv, nsmall = 3)),
            "A", "AI0", v, pv)
  }
}

# Block B: controlled failures AI1-AI10, V1/V4/V5, three fractions.
for (code in paste0("AI", 1:10)) {
  for (v in c("V1", "V4", "V5")) {
    for (pv in c(0.05, 0.10, 0.20)) {
      add_row(paste0("AI_B_", code, "_", v, "_p", format(pv, nsmall = 2)),
              "B", code, v, pv)
    }
  }
}

# Block C: prompt and model sensitivity, V1/V4 at p = 0.10.
for (pr in c("P0", "P1", "P2", "P3")) {
  for (v in c("V1", "V4")) {
    add_row(paste0("AI_C_", pr, "_", v), "C", "AI0", v, 0.10, prompt = pr)
  }
}
for (v in c("V1", "V4")) {
  add_row(paste0("AI_C_flash_", v), "C", "AI0", v, 0.10,
          model = "deepseek-v4-flash")
  add_row(paste0("AI_C_thinking_", v), "C", "AI0", v, 0.10,
          thinking = TRUE)
}

# Block D: confidence block.
for (code in c("AI0", "AI9")) {
  for (v in c("V1", "V4")) {
    add_row(paste0("AI_D_", code, "_", v), "D", code, v, 0.10,
            confidence_block = TRUE)
  }
}

# Block E: stochasticity aggregation.
for (st in c("first", "mean3", "median3")) {
  add_row(paste0("AI_E_", st), "E", "AI0", "V1", 0.10, stochastic = st)
}

manifest <- do.call(rbind, rows)
write.csv(manifest, out_path, row.names = FALSE)
cat("Wrote", nrow(manifest), "AI scenarios.\n")
