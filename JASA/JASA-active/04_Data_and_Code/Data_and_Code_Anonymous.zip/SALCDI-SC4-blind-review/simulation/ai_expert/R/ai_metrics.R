# AI evaluator characterization metrics (AI protocol sections 18-19, 35).

ai_characterize <- function(scores, y, x = NULL, group = NULL) {
  err <- scores - y
  fit <- lm(y ~ scores)
  out <- list(
    bias = mean(err),
    mae = mean(abs(err)),
    rmse = sqrt(mean(err^2)),
    pearson = cor(scores, y),
    spearman = cor(scores, y, method = "spearman"),
    cal_intercept = unname(coef(fit)[1L]),
    cal_slope = unname(coef(fit)[2L]),
    n = length(y)
  )
  if (!is.null(x)) {
    xb <- cut(x, breaks = seq(-1, 1, length.out = 18), include.lowest = TRUE)
    local <- data.frame(x_mid = (head(seq(-1, 1, length.out = 18), -1) +
                                   tail(seq(-1, 1, length.out = 18), -1)) / 2)
    local$bias <- tapply(err, xb, mean)
    local$rmse <- sqrt(tapply(err^2, xb, mean))
    out$local <- local
  }
  if (!is.null(group)) {
    out$group_bias <- tapply(err, group, mean)
    out$group_mae <- tapply(abs(err), group, mean)
  }
  out
}

ai_confidence_metrics <- function(confidence, err) {
  dec <- cut(confidence, breaks = seq(0, 100, length.out = 11),
             include.lowest = TRUE)
  list(
    cor_conf_neg_abs_err = cor(confidence, -abs(err)),
    error_by_conf_decile = tapply(abs(err), dec, mean),
    p_severe_overconfident = mean(abs(err) > 10 & confidence > 90)
  )
}

ai_repeatability <- function(repeated) {
  k <- ncol(repeated)
  n <- nrow(repeated)
  within_sd <- apply(repeated, 1L, stats::sd)
  msb <- n / (k - 1) * sum((rowMeans(repeated) - mean(repeated))^2)
  msw <- sum(apply(repeated, 1L, function(r) sum((r - mean(r))^2))) /
    (n * (k - 1))
  icc <- (msb - msw) / (msb + (k - 1) * msw)
  first <- repeated[, 1L]
  ranks <- apply(repeated, 2L, rank)
  list(
    within_case_sd = mean(within_sd),
    max_within_diff = mean(apply(repeated, 1L, function(r) diff(range(r)))),
    exact_repeat_freq = mean(apply(repeated, 1L, function(r) {
      length(unique(r)) == 1L
    })),
    icc = icc,
    rank_stability = mean(stats::cor(ranks[, 1L], ranks[, -1L, drop = FALSE],
                                     method = "spearman"))
  )
}

ai_equivalent_fraction <- function(risk_ai, p, anchor_risk_grid) {
  p_grid <- as.numeric(names(anchor_risk_grid))
  ok <- which(anchor_risk_grid <= risk_ai)
  if (length(ok) == 0L) {
    return(NA_real_)
  }
  p_eq <- min(p_grid[ok])
  p_eq / p
}
