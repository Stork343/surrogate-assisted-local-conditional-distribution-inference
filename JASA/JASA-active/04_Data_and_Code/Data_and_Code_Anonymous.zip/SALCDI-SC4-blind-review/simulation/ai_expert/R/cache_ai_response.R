# API response cache (AI protocol section 16).

ai_request_hash <- function(model, system_prompt, user_prompt, params) {
  digest::digest(
    paste(model, system_prompt, user_prompt,
          jsonlite::toJSON(params, auto_unbox = TRUE)),
    algo = "sha256"
  )
}

ai_cache_lookup <- function(cache_dir, request_hash) {
  csv <- file.path(cache_dir, "responses.csv")
  if (!file.exists(csv)) {
    return(NULL)
  }
  tab <- utils::read.csv(csv, stringsAsFactors = FALSE)
  idx <- which(tab$request_hash == request_hash)
  if (length(idx) == 0L) {
    return(NULL)
  }
  tab[idx[1L], , drop = FALSE]
}

ai_cache_write <- function(cache_dir, row, raw_path) {
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  csv <- file.path(cache_dir, "responses.csv")
  new_row <- as.data.frame(row, stringsAsFactors = FALSE)
  if (!file.exists(csv)) {
    utils::write.csv(new_row, csv, row.names = FALSE)
  } else {
    utils::write.table(new_row, csv, row.names = FALSE, sep = ",",
                       append = TRUE, col.names = FALSE)
  }
  if (!is.null(raw_path)) {
    writeLines(row$raw_response, raw_path)
  }
  invisible(csv)
}

ai_clean_parsed <- function(parsed) {
  data.frame(
    score = parsed$score,
    confidence = parsed$confidence,
    review_needed = parsed$review_needed,
    grade = parsed$grade,
    stringsAsFactors = FALSE
  )
}
