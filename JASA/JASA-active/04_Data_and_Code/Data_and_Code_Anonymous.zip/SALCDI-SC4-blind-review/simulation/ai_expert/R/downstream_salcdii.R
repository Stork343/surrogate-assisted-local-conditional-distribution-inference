# AI truth engine and SALCDI downstream inference (AI protocol sections 42-43).

ai_simulate_y_x0 <- function(x0, n, seed) {
  ai_simulate_reference_given_x(rep(x0, n), seed = seed)
}

ai_truth_chunked <- function(x0, h, tau, n = 1e6, seed = 20260812L,
                             chunk = 2e5) {
  set.seed(seed, kind = "L'Ecuyer-CMRG")
  num <- numeric(length(tau))
  den <- 0
  n_done <- 0
  while (n_done < n) {
    m <- min(chunk, n - n_done)
    x <- runif(m, -1, 1)
    y <- ai_simulate_y_x0_sample(x, m, seed = NULL)
    k <- epan_k((x - x0) / h)
    z <- 1 * (outer(y, tau, "<="))
    num <- num + colSums(z * k)
    den <- den + sum(k)
    n_done <- n_done + m
  }
  num / den
}

ai_simulate_y_x0_sample <- function(x, n, seed) {
  stopifnot(length(x) == n)
  ai_simulate_reference_given_x(x, seed = seed)
}

ai_make_truth <- function(x0, h, n = 1e6, seed = 20260812L,
                          path = NULL) {
  u <- simulation_threshold_levels
  y0 <- ai_simulate_y_x0(x0, n, seed)
  tau <- as.numeric(quantile(y0, u))
  f0 <- ecdf(y0)(tau)
  fh <- ai_truth_chunked(x0, h, tau, n = n, seed = seed + 10L)
  out <- list(x0 = x0, h = h, tau = tau, f0 = f0, fh = fh, n = n,
              seed = seed, reference_version = ai_reference_version)
  if (!is.null(path)) {
    saveRDS(out, path)
  }
  out
}

ai_read_truth <- function(path) {
  if (!file.exists(path)) {
    stop("Missing canonical AI truth object: ", path, call. = FALSE)
  }
  truth <- readRDS(path)
  if (!identical(truth$reference_version, ai_reference_version)) {
    stop("AI truth object predates the fixed expert-reference mechanism. ",
         "Regenerate WP-AI1 before downstream inference.", call. = FALSE)
  }
  truth
}

ai_scenario <- function(id, corpus_n, x0, h, p, design, surrogate_code,
                        confidence_used = FALSE) {
  list(
    scenario_id = id, module = "ai", M = corpus_n, p = p, x0 = x0, h = h,
    tau_s = 0.8, verification = design, error_dist = "ai", target = "F_h",
    m_scenario = "none", q_learner = "L1", m_learner = "L1",
    lambda_floor = 1e-8, pi_mode = "known", d = 1,
    level = "C_secondary", surrogate_code = surrogate_code,
    confidence_used = confidence_used
  )
}

ai_build_data <- function(corpus, mask) {
  list(
    x = matrix(corpus$X, ncol = 1),
    s = corpus$S_AI,
    y = corpus$Y,
    r = mask$r,
    pi = mask$pi
  )
}

ai_full_oracle <- function(corpus, scenario, truth) {
  w <- salcdi_local_weights(matrix(corpus$X, ncol = 1), scenario$x0,
                            scenario$h, kernel = simulation_kernel)
  z <- salcdi_threshold_signals(corpus$Y, truth$tau)
  f_full <- salcdi_local_cdf(z, w)
  list(F_full = f_full)
}

ai_downstream_one <- function(corpus, scenario, truth, mask, learners,
                              oracle_full) {
  data <- ai_build_data(corpus, mask)
  est <- estimate_feasible(data, scenario, truth, learners)
  target <- truth$fh
  metrics <- lapply(est$F, compute_metrics, target = target)
  anchor_ise <- metrics$X_anchor$ise
  rows <- lapply(names(metrics), function(nm) {
    mt <- metrics[[nm]]
    data.frame(
      implementation_version = simulation_implementation_version,
      scenario_id = scenario$scenario_id, replicate = NA_integer_,
      seed = paste(mask$state, collapse = ","), M = nrow(corpus),
      p = scenario$p, x0 = scenario$x0, h = scenario$h,
      surrogate_quality = scenario$surrogate_code,
      verification_design = scenario$verification,
      error_distribution = "ai", q_learner = "L1", m_learner = "L1",
      pi_mode = scenario$pi_mode, method = nm,
      ise_raw = mt$ise_raw, ise_final = mt$ise_final, ise = mt$ise,
      sup_raw = mt$sup_raw, sup_final = mt$sup_final,
      sup_error = mt$sup_error,
      lower_tail_ise_raw = mt$lower_tail_ise_raw,
      lower_tail_ise_final = mt$lower_tail_ise_final,
      lower_tail_ise = mt$lower_tail_ise,
      upper_tail_ise_raw = mt$upper_tail_ise_raw,
      upper_tail_ise_final = mt$upper_tail_ise_final,
      upper_tail_ise = mt$upper_tail_ise,
      mse_q10 = mt$mse_q10, mse_q50 = mt$mse_q50, mse_q90 = mt$mse_q90,
      lambda_hat = est$lambda_hat, lambda_star = NA_real_,
      G_hat = est$G_hat, H_hat = est$H_hat,
      G_true = NA_real_, H_true = NA_real_, transfer_signal = NA_real_,
      negative_transfer = as.integer(mt$ise > anchor_ise),
      monotonicity_violations = mt$monotonicity_violations,
      runtime_seconds = NA_real_, warning_flag = 0L,
      stringsAsFactors = FALSE
    )
  })
  oracle_rows <- list(
    data.frame(
      implementation_version = simulation_implementation_version,
      scenario_id = scenario$scenario_id, replicate = NA_integer_,
      seed = paste(mask$state, collapse = ","), M = nrow(corpus),
      p = scenario$p, x0 = scenario$x0, h = scenario$h,
      surrogate_quality = scenario$surrogate_code,
      verification_design = scenario$verification,
      error_distribution = "ai", q_learner = "full", m_learner = "full",
      pi_mode = "full", method = "Oracle_m",
      ise_raw = mean((oracle_full$F_full - target)^2),
      ise_final = mean((oracle_full$F_full - target)^2),
      ise = mean((oracle_full$F_full - target)^2),
      sup_raw = max(abs(oracle_full$F_full - target)),
      sup_final = max(abs(oracle_full$F_full - target)),
      sup_error = max(abs(oracle_full$F_full - target)),
      lower_tail_ise_raw = NA_real_, lower_tail_ise_final = NA_real_,
      lower_tail_ise = NA_real_, upper_tail_ise = NA_real_,
      upper_tail_ise_raw = NA_real_, upper_tail_ise_final = NA_real_,
      mse_q10 = NA_real_, mse_q50 = NA_real_, mse_q90 = NA_real_,
      lambda_hat = NA_real_, lambda_star = NA_real_,
      G_hat = NA_real_, H_hat = NA_real_,
      G_true = NA_real_, H_true = NA_real_, transfer_signal = NA_real_,
      negative_transfer = NA_integer_, monotonicity_violations = NA_integer_,
      runtime_seconds = NA_real_, warning_flag = 0L, stringsAsFactors = FALSE
    )
  )
  do.call(rbind, c(rows, oracle_rows))
}

ai_run_downstream <- function(root, corpus, scenario, truth, n_mask,
                              out_dir, cores = 1, master_seed = 20260812L,
                              force = FALSE) {
  force <- isTRUE(force) || identical(
    Sys.getenv("SALCDI_FORCE_CANONICAL_RERUN", "0"), "1"
  )
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  out_file <- file.path(out_dir, paste0(scenario$scenario_id,
                                        "_mask", n_mask, ".rds"))
  if (file.exists(out_file) && !force) {
    existing <- tryCatch(readRDS(out_file), error = function(e) NULL)
    current <- is.data.frame(existing) &&
      "implementation_version" %in% names(existing) &&
      identical(unique(existing$implementation_version),
                simulation_implementation_version)
    if (isTRUE(current)) return(out_file)
    stop("Existing AI result is not a canonical ",
         simulation_implementation_version,
         " object. Re-run this scenario with `force = TRUE`.", call. = FALSE)
  }
  learners <- make_learners(scenario)
  oracle_full <- ai_full_oracle(corpus, scenario, truth)
  states <- make_seed_states(scenario$scenario_id, n_mask, master_seed)
  worker <- function(j) {
    assign(".Random.seed", states[[j]], envir = globalenv())
    mask <- ai_mask(corpus, scenario$verification, scenario$p, seed = NULL,
                    confidence = corpus$C_AI)
    mask$state <- states[[j]]
    ai_downstream_one(corpus, scenario, truth, mask, learners, oracle_full)
  }
  if (cores == 1) {
    res <- lapply(seq_len(n_mask), worker)
  } else {
    cl <- parallel::makeCluster(cores)
    on.exit(parallel::stopCluster(cl))
    parallel::clusterExport(cl, "root", envir = environment())
    parallel::clusterEvalQ(cl, {
      pkgload::load_all(root, quiet = TRUE)
      source(file.path(root, "simulation", "config", "simulation_constants.R"))
      invisible(lapply(file.path(root, "simulation",
                                 simulation_source_files()), source))
      ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
      invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
    })
    parallel::clusterExport(cl, c("corpus", "scenario", "truth", "states",
                                  "learners", "oracle_full", "worker"),
                            envir = environment())
    res <- parallel::parLapply(cl, seq_len(n_mask), function(j) worker(j))
  }
  result <- do.call(rbind, res)
  rownames(result) <- NULL
  saveRDS(result, out_file)
  out_file
}

ai_run_bands <- function(root, corpus, scenario, truth, n_mask,
                         out_dir, cores = 1, master_seed = 20260813L,
                         force = FALSE) {
  force <- isTRUE(force) || identical(
    Sys.getenv("SALCDI_FORCE_CANONICAL_RERUN", "0"), "1"
  )
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  out_file <- file.path(out_dir, paste0(scenario$scenario_id,
                                        "_bands", n_mask, ".rds"))
  if (file.exists(out_file) && !force) {
    existing <- tryCatch(readRDS(out_file), error = function(e) NULL)
    current <- is.data.frame(existing) &&
      "implementation_version" %in% names(existing) &&
      identical(unique(existing$implementation_version),
                simulation_implementation_version)
    if (isTRUE(current)) return(out_file)
    stop("Existing AI band result is not a canonical ",
         simulation_implementation_version,
         " object. Re-run this scenario with `force = TRUE`.", call. = FALSE)
  }
  learners <- make_learners(scenario)
  states <- make_seed_states(scenario$scenario_id, n_mask, master_seed)
  worker <- function(j) {
    assign(".Random.seed", states[[j]], envir = globalenv())
    mask <- ai_mask(corpus, scenario$verification, scenario$p, seed = NULL,
                    confidence = corpus$C_AI)
    data <- ai_build_data(corpus, mask)
    est <- estimate_feasible(data, scenario, truth, learners, return_u = TRUE)
    idx <- metric_indices()
    target <- truth$fh
    rows <- lapply(intersect(c("X_anchor", "Adaptive"), names(est$influence)),
                   function(nm) {
      band <- multiplier_band(
        influence = est$influence[[nm]],
        center = est$F[[nm]],
        p = mean(data$pi),
        h = scenario$h,
        dimension = scenario$d,
        seed = master_seed + 1000L * j +
          match(nm, c("X_anchor", "Adaptive"))
      )
      cover <- target >= band$band_low & target <= band$band_high
      data.frame(
        implementation_version = simulation_implementation_version,
        scenario_id = scenario$scenario_id, replicate = j,
        seed = paste(states[[j]], collapse = ","),
        M = nrow(corpus), p = scenario$p, x0 = scenario$x0, h = scenario$h,
        surrogate_quality = scenario$surrogate_code,
        verification_design = scenario$verification,
        error_distribution = "ai", q_learner = "L1", m_learner = "L1",
        pi_mode = scenario$pi_mode, method = nm,
        simultaneous_coverage = as.integer(all(cover)),
        pointwise_coverage_q10 = as.integer(cover[idx$q[1L]]),
        pointwise_coverage_q50 = as.integer(cover[idx$q[2L]]),
        pointwise_coverage_q90 = as.integer(cover[idx$q[3L]]),
        integrated_band_width = mean(band$band_high - band$band_low),
        maximum_band_width = max(band$band_high - band$band_low),
        bootstrap_critical_value = band$critical_value,
        warning_flag = as.integer(any(!is.finite(band$band_low))),
        stringsAsFactors = FALSE
      )
    })
    do.call(rbind, rows)
  }
  if (cores == 1) {
    res <- lapply(seq_len(n_mask), worker)
  } else {
    cl <- parallel::makeCluster(cores)
    on.exit(parallel::stopCluster(cl))
    parallel::clusterExport(cl, "root", envir = environment())
    parallel::clusterEvalQ(cl, {
      pkgload::load_all(root, quiet = TRUE)
      source(file.path(root, "simulation", "config", "simulation_constants.R"))
      invisible(lapply(file.path(root, "simulation",
                                 simulation_source_files()), source))
      ai_r_dir <- file.path(root, "simulation", "ai_expert", "R")
      invisible(lapply(list.files(ai_r_dir, full.names = TRUE), source))
    })
    parallel::clusterExport(cl, c("corpus", "scenario", "truth", "states",
                                  "learners", "worker"), envir = environment())
    res <- parallel::parLapply(cl, seq_len(n_mask), function(j) worker(j))
  }
  result <- do.call(rbind, res)
  rownames(result) <- NULL
  saveRDS(result, out_file)
  out_file
}
