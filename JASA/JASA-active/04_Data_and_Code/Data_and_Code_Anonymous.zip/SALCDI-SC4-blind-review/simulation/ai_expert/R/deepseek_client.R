# DeepSeek API client (AI protocol sections 11-16).

ai_api_key <- function() {
  key <- Sys.getenv("DEEPSEEK_API_KEY", unset = "")
  if (!nzchar(key)) {
    stop("BLOCKED: DEEPSEEK_API_KEY is not set. Supply it as an environment ",
         "variable only; never paste the key into files or chat.", call. = FALSE)
  }
  key
}

ai_api_config <- function(path) {
  cfg <- yaml::read_yaml(path)
  cfg$endpoint <- sub("/+$", "", cfg$endpoint)
  cfg
}

ai_build_messages <- function(system_prompt, user_prompt) {
  list(
    list(role = "system", content = paste(system_prompt, collapse = "\n")),
    list(role = "user", content = paste(user_prompt, collapse = "\n"))
  )
}

ai_deepseek_transport <- function(url, key, body, timeout_s) {
  resp <- httr2::request(url) |>
    httr2::req_headers(Authorization = paste("Bearer", key),
                       "Content-Type" = "application/json") |>
    httr2::req_body_json(body) |>
    httr2::req_timeout(timeout_s) |>
    httr2::req_perform()
  list(raw_body = httr2::resp_body_string(resp),
       response_headers = httr2::resp_headers(resp))
}

ai_archive_failed_response <- function(failure_dir, request_hash, attempt,
                                       failure_type, raw_response,
                                       error_message = NA_character_) {
  if (is.null(failure_dir)) return(invisible(NULL))
  dir.create(failure_dir, recursive = TRUE, showWarnings = FALSE)
  safe_hash <- gsub("[^A-Za-z0-9_-]", "_", request_hash)
  path <- file.path(
    failure_dir, sprintf("%s_attempt%02d.json", safe_hash, attempt)
  )
  if (file.exists(path)) {
    collision <- 1L
    repeat {
      candidate <- file.path(
        failure_dir,
        sprintf("%s_attempt%02d_run%03d.json", safe_hash, attempt, collision)
      )
      if (!file.exists(candidate)) {
        path <- candidate
        break
      }
      collision <- collision + 1L
    }
  }
  record <- list(
    request_hash = request_hash, attempt = attempt,
    timestamp_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
    failure_type = failure_type, error_message = error_message,
    raw_response = raw_response
  )
  writeLines(jsonlite::toJSON(record, auto_unbox = TRUE, null = "null",
                              na = "null"), path)
  invisible(path)
}

ai_call_deepseek <- function(
    system_prompt, user_prompt, cfg, model = NULL, temperature = NULL,
    thinking = NULL, max_tokens = NULL, log_file = NULL, api_key = NULL,
    transport = ai_deepseek_transport, sleep = Sys.sleep,
    failure_dir = NULL, request_hash = NULL) {
  key <- api_key %||% ai_api_key()
  model <- model %||% cfg$model_primary
  temperature <- temperature %||% cfg$temperature
  thinking <- thinking %||% cfg$thinking
  max_tokens <- max_tokens %||% cfg$max_tokens
  body <- list(
    model = model,
    messages = ai_build_messages(system_prompt, user_prompt),
    temperature = temperature,
    stream = cfg$stream,
    response_format = list(type = cfg$response_format),
    max_tokens = max_tokens
  )
  if (isTRUE(thinking)) {
    body$thinking <- list(type = "enabled")
    body$reasoning_effort <- "high"
    body$temperature <- NULL
    body$max_tokens <- max(cfg$max_tokens, 4096)
  } else {
    body$thinking <- list(type = "disabled")
  }
  url <- file.path(cfg$endpoint, "chat", "completions")
  request_hash <- request_hash %||% digest::digest(
    jsonlite::toJSON(body, auto_unbox = TRUE, null = "null"), algo = "sha256"
  )
  failures <- list()
  for (attempt in seq_len(cfg$max_retries)) {
    response <- tryCatch(
      transport(url = url, key = key, body = body, timeout_s = cfg$timeout_s),
      error = function(e) e
    )
    failure_type <- NULL
    error_message <- NA_character_
    raw_response <- ""
    parsed_body <- NULL
    response_headers <- list()
    if (inherits(response, "error")) {
      failure_type <- "transport"
      error_message <- conditionMessage(response)
    } else {
      response_headers <- response$response_headers %||% list()
      if (!is.null(response$body)) {
        parsed_body <- response$body
        raw_response <- jsonlite::toJSON(
          response$body, auto_unbox = TRUE, null = "null"
        )
      } else {
        raw_response <- response$raw_body %||% ""
        parsed_body <- tryCatch(
          jsonlite::fromJSON(raw_response, simplifyVector = FALSE),
          error = function(e) NULL
        )
      }
      if (is.null(parsed_body)) {
        failure_type <- "response envelope JSON"
      } else {
        content <- tryCatch(
          parsed_body$choices[[1L]]$message$content %||% "",
          error = function(e) ""
        )
        validation <- ai_parse_response(content)
        if (isTRUE(validation$valid)) {
          return(list(
            status = "ok", attempt = attempt, body = parsed_body,
            response_headers = response_headers, content = content,
            parsed = validation$parsed, failures = failures,
            request_hash = request_hash, api_failure = FALSE
          ))
        }
        raw_response <- content
        failure_type <- if (identical(validation$errors, "invalid JSON")) {
          "invalid JSON"
        } else {
          "schema validation"
        }
        error_message <- paste(validation$errors, collapse = "; ")
      }
    }
    ai_archive_failed_response(
      failure_dir, request_hash, attempt, failure_type, raw_response,
      error_message
    )
    failures[[length(failures) + 1L]] <- list(
      attempt = attempt, failure_type = failure_type,
      error_message = error_message, raw_response = raw_response
    )
    if (attempt < cfg$max_retries) {
      sleep(cfg$retry_base_delay_s * 2^(attempt - 1))
    }
  }
  if (!is.null(log_file)) {
    cat(sprintf("API failure at %s after %d attempts: %s\n", Sys.time(),
                cfg$max_retries, failures[[length(failures)]]$failure_type),
        file = log_file, append = TRUE)
  }
  list(status = "failed", attempt = cfg$max_retries,
       error = failures[[length(failures)]], failures = failures,
       request_hash = request_hash, api_failure = TRUE)
}

`%||%` <- function(a, b) if (is.null(a)) b else a
