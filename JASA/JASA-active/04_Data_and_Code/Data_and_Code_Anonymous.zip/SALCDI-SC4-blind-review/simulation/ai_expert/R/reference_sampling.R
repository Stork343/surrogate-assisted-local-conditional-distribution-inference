# AI reference-sampling mechanisms V1-V5 (AI protocol section 32).

ai_review_pi <- function(corpus, design, p, x0 = 0, h = 0.3,
                         confidence = NULL) {
  if (!is.numeric(p) || length(p) != 1L || !is.finite(p) || p <= 0 || p >= 1) {
    stop("`p` must be a scalar strictly between zero and one.", call. = FALSE)
  }
  n <- nrow(corpus)
  if (design == "V1") {
    intensity <- rep(1, n)
  } else if (design == "V2") {
    u <- 1 - (confidence %||% rep(50, n)) / 100
    intensity <- salcdi::salcdi_calibrate_intensity(exp(1.5 * u))
  } else if (design == "V3") {
    intensity <- salcdi::salcdi_calibrate_intensity(
      exp(1.2 * (70 - corpus$S_AI) / 15)
    )
  } else if (design == "V4") {
    u <- 1 - (confidence %||% rep(50, n)) / 100
    intensity <- salcdi::salcdi_calibrate_intensity(
      exp(1.5 * u + 1.2 * (70 - corpus$S_AI) / 15)
    )
  } else if (design == "V5") {
    inside <- abs(corpus$X - x0) <= h
    p_in <- mean(inside)
    if (p_in >= 1) {
      stop("V5 requires observations outside the target neighborhood.",
           call. = FALSE)
    }
    c_out <- (1 - 0.25 * p_in) / (1 - p_in)
    intensity <- ifelse(inside, 0.25, c_out)
  } else {
    stop("Unknown review design `", design, "`.", call. = FALSE)
  }
  pi <- p * intensity
  if (max(pi) >= 1) {
    stop("The requested review fraction is incompatible with the design ",
         "intensity because at least one probability reaches one.",
         call. = FALSE)
  }
  if (abs(mean(pi) - p) > 1e-10) {
    stop("Review probabilities do not attain the registered mean budget.",
         call. = FALSE)
  }
  pi
}

ai_mask <- function(corpus, design, p, seed, confidence = NULL) {
  if (!is.null(seed)) {
    set.seed(seed)
  }
  pi <- ai_review_pi(corpus, design, p, confidence = confidence)
  r <- rbinom(nrow(corpus), 1, pi)
  list(r = r, pi = pi)
}

ai_mask_replications <- function(corpus, design, p, n_mask,
                                 master_seed = 20260812L) {
  set.seed(master_seed, kind = "L'Ecuyer-CMRG")
  rng <- .Random.seed
  out <- vector("list", n_mask)
  for (j in seq_len(n_mask)) {
    out[[j]] <- list(state = rng, rep = j)
    rng <- parallel::nextRNGSubStream(rng)
  }
  lapply(out, function(item) {
    assign(".Random.seed", item$state, envir = globalenv())
    ai_mask(corpus, design, p, seed = NULL, confidence = corpus$C_AI)
  })
}
