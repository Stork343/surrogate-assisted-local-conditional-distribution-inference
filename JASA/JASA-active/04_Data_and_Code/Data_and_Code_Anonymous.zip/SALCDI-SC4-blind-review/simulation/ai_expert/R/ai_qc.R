# AI module QC and audit helpers (AI protocol sections 46-48).

ai_qc_leakage <- function(corpus, dossiers) {
  terms <- c("reference score", "gold label", "expert score", "true score",
             "latent performance", "target outcome")
  hits <- lapply(seq_along(dossiers), function(i) {
    txt <- tolower(dossiers[[i]])
    terms[vapply(terms, grepl, logical(1), x = txt)]
  })
  n_hits <- sum(lengths(hits))
  list(pass = n_hits == 0L, n_hits = n_hits,
       forbidden_in_dossier = n_hits > 0L)
}

ai_audit_log <- function(root, file, entry) {
  path <- file.path(root, "simulation", "ai_expert", "audit", file)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  cat(sprintf("[%s] %s\n", format(Sys.time(), tz = "UTC"), entry),
      file = path, append = TRUE)
  invisible(path)
}

ai_api_failure_rate <- function(cache_dir) {
  csv <- file.path(cache_dir, "responses.csv")
  if (!file.exists(csv)) {
    return(list(rate = NA_real_, n = 0L))
  }
  tab <- utils::read.csv(csv, stringsAsFactors = FALSE)
  n_fail <- sum(tab$api_failure %in% c(TRUE, "TRUE", 1))
  list(rate = n_fail / max(1, nrow(tab)), n = nrow(tab), n_fail = n_fail)
}
