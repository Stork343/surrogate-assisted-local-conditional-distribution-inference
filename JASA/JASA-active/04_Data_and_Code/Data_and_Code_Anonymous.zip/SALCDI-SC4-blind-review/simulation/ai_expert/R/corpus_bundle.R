# Canonical physical separation of public dossier evidence and protected truth.

ai_evidence_columns <- c(
  "case_id", "X", "A", "D", "E1", "E2", "E3", "E4", "E5", "C", "Q"
)
ai_truth_columns <- c("case_id", "Theta", "Y_dag", "Y")

ai_sha256_file <- function(path) {
  if (!file.exists(path)) stop("Missing bundle file: ", path, call. = FALSE)
  digest::digest(file = path, algo = "sha256")
}

ai_frozen_case_ids <- function(path) {
  if (!file.exists(path)) return(NULL)
  lines <- readLines(path, warn = FALSE)
  unname(vapply(lines, function(line) {
    as.character(jsonlite::fromJSON(line)$case_id)
  }, character(1L)))
}

ai_reconstruct_frozen_corpus <- function(case_ids, seed) {
  case_ids <- as.character(case_ids)
  pool <- generate_population(ceiling(length(case_ids) * 2.2), seed = seed)
  idx <- match(case_ids, pool$case_id)
  if (anyNA(idx)) {
    stop("Frozen case registry contains identifiers absent from the seeded ",
         "population.", call. = FALSE)
  }
  pool[idx, , drop = FALSE]
}

ai_update_manifest <- function(path, row, key = "corpus_id") {
  if (file.exists(path)) {
    manifest <- utils::read.csv(path, stringsAsFactors = FALSE,
                                colClasses = "character")
    manifest <- manifest[manifest[[key]] != row[[key]], , drop = FALSE]
    manifest <- rbind(manifest, row)
  } else {
    manifest <- row
  }
  manifest <- manifest[order(manifest[[key]]), , drop = FALSE]
  utils::write.csv(manifest, path, row.names = FALSE)
  invisible(manifest)
}

ai_write_corpus_bundle <- function(corpus, corpus_dir, corpus_id,
                                   dossier_seed_base = 20260812L) {
  missing_columns <- setdiff(c(ai_evidence_columns, ai_truth_columns),
                             names(corpus))
  if (length(missing_columns)) {
    stop("Corpus bundle is missing: ", paste(missing_columns, collapse = ", "),
         call. = FALSE)
  }
  evidence_dir <- file.path(corpus_dir, "evidence")
  truth_dir <- file.path(corpus_dir, "truth")
  dossier_dir <- file.path(corpus_dir, "frozen_cases")
  dir.create(evidence_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(truth_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(dossier_dir, recursive = TRUE, showWarnings = FALSE)

  evidence_path <- file.path(evidence_dir,
                             paste0("corpus_", corpus_id, "_evidence.rds"))
  truth_path <- file.path(truth_dir,
                          paste0("corpus_", corpus_id, "_truth.rds"))
  dossier_path <- file.path(dossier_dir, paste0("corpus_", corpus_id, ".jsonl"))
  evidence <- corpus[, ai_evidence_columns, drop = FALSE]
  truth <- corpus[, ai_truth_columns, drop = FALSE]
  saveRDS(list(corpus_id = corpus_id, data = evidence), evidence_path)
  saveRDS(list(corpus_id = corpus_id, reference_version = ai_reference_version,
               data = truth), truth_path)
  write_dossiers_jsonl(corpus, dossier_path, seed_base = dossier_seed_base)

  dossier_row <- data.frame(
    corpus_id = corpus_id, n = nrow(corpus),
    dossier_file = file.path("frozen_cases", basename(dossier_path)),
    evidence_file = file.path("evidence", basename(evidence_path)),
    dossier_sha256 = ai_sha256_file(dossier_path),
    evidence_sha256 = ai_sha256_file(evidence_path),
    stringsAsFactors = FALSE
  )
  truth_row <- data.frame(
    corpus_id = corpus_id, n = nrow(corpus),
    reference_version = ai_reference_version,
    truth_file = basename(truth_path),
    truth_sha256 = ai_sha256_file(truth_path),
    stringsAsFactors = FALSE
  )
  ai_update_manifest(file.path(corpus_dir, "dossier_manifest.csv"),
                     dossier_row)
  ai_update_manifest(file.path(truth_dir, "truth_manifest.csv"), truth_row)
  invisible(list(dossier = dossier_row, truth = truth_row))
}

ai_load_corpus_bundle <- function(corpus_dir, corpus_id, include_truth = TRUE,
                                  verify_hashes = TRUE) {
  dossier_manifest_path <- file.path(corpus_dir, "dossier_manifest.csv")
  truth_manifest_path <- file.path(corpus_dir, "truth", "truth_manifest.csv")
  if (!file.exists(dossier_manifest_path) || !file.exists(truth_manifest_path)) {
    stop("Canonical AI corpus manifests are absent. Run WP-AI1 after the P0-C ",
         "repair; legacy corpus RDS files are invalid.", call. = FALSE)
  }
  dossier_manifest <- utils::read.csv(
    dossier_manifest_path, stringsAsFactors = FALSE, colClasses = "character"
  )
  truth_manifest <- utils::read.csv(
    truth_manifest_path, stringsAsFactors = FALSE, colClasses = "character"
  )
  dossier_row <- dossier_manifest[
    dossier_manifest$corpus_id == corpus_id, , drop = FALSE
  ]
  truth_row <- truth_manifest[
    truth_manifest$corpus_id == corpus_id, , drop = FALSE
  ]
  if (nrow(dossier_row) != 1L || nrow(truth_row) != 1L) {
    stop("Expected exactly one canonical bundle for corpus ", corpus_id, ".",
         call. = FALSE)
  }
  evidence_path <- file.path(corpus_dir, dossier_row$evidence_file)
  truth_path <- file.path(corpus_dir, "truth", truth_row$truth_file)
  dossier_path <- file.path(corpus_dir, dossier_row$dossier_file)
  if (isTRUE(verify_hashes)) {
    observed <- c(ai_sha256_file(dossier_path), ai_sha256_file(evidence_path),
                  ai_sha256_file(truth_path))
    expected <- c(dossier_row$dossier_sha256, dossier_row$evidence_sha256,
                  truth_row$truth_sha256)
    if (!identical(observed, expected)) {
      stop("Canonical AI corpus bundle failed SHA-256 verification.",
           call. = FALSE)
    }
  }
  evidence <- readRDS(evidence_path)$data
  if (!isTRUE(include_truth)) return(evidence)
  truth_object <- readRDS(truth_path)
  if (!identical(truth_object$reference_version, ai_reference_version)) {
    stop("AI corpus truth uses an obsolete expert-reference mechanism.",
         call. = FALSE)
  }
  truth <- truth_object$data
  idx <- match(evidence$case_id, truth$case_id)
  if (anyNA(idx) || anyDuplicated(truth$case_id)) {
    stop("Evidence and truth bundles do not have a one-to-one case mapping.",
         call. = FALSE)
  }
  out <- cbind(evidence, truth[idx, setdiff(names(truth), "case_id"),
                              drop = FALSE])
  attr(out, "reference_version") <- truth_object$reference_version
  out
}
