# AI response validation (AI protocol section 15).

ai_grade_for_score <- function(score) {
  if (score >= 85) "A" else if (score >= 70) "B" else if (score >= 55) "C" else "D"
}

ai_parse_response <- function(raw_text) {
  out <- tryCatch(jsonlite::fromJSON(raw_text), error = function(e) NULL)
  if (is.null(out)) {
    return(list(valid = FALSE, parsed = NULL, errors = "invalid JSON"))
  }
  if (!is.list(out) || is.null(names(out))) {
    return(list(valid = FALSE, parsed = out,
                errors = "response is not a JSON object"))
  }
  errs <- character(0)
  score_valid <- is.numeric(out$score) && length(out$score) == 1L &&
    is.finite(out$score) && out$score >= 0 && out$score <= 100
  if (!score_valid) {
    errs <- c(errs, "score out of range")
  }
  confidence_valid <- is.numeric(out$confidence) &&
    length(out$confidence) == 1L && is.finite(out$confidence) &&
    out$confidence >= 0 && out$confidence <= 100
  if (!confidence_valid) {
    errs <- c(errs, "confidence out of range")
  }
  if (!is.logical(out$review_needed) || length(out$review_needed) != 1L ||
      is.na(out$review_needed)) {
    errs <- c(errs, "review_needed not boolean")
  }
  grade_valid <- is.character(out$grade) && length(out$grade) == 1L &&
    !is.na(out$grade) && out$grade %in% c("A", "B", "C", "D")
  if (!grade_valid) {
    errs <- c(errs, "grade not in A/B/C/D")
  } else if (score_valid && out$grade != ai_grade_for_score(out$score)) {
    errs <- c(errs, "grade disagrees with score")
  }
  list(valid = length(errs) == 0L, parsed = out, errors = errs)
}
