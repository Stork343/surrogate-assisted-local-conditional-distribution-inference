# Synthetic evaluation population (AI protocol sections 4-7).

ai_clip <- function(x, lo = 0, hi = 100) pmin(pmax(x, lo), hi)

ai_reference_version <- "fixed-expert-bias-v2"

ai_latent <- function(x, eps) {
  70 + 5 * x - 3 * x^2 + (7 + 2 * abs(x)) * eps
}

ai_evidence <- function(theta, x, eta) {
  data.frame(
    E1 = ai_clip(theta - 5 * x + eta[, 1L]),
    E2 = ai_clip(theta + eta[, 2L]),
    E3 = ai_clip(theta - 4 * x + eta[, 3L]),
    E4 = ai_clip(theta + eta[, 4L]),
    E5 = ai_clip(theta + 3 * x + eta[, 5L])
  )
}

ai_reference <- function(ev, c_count, q_signal) {
  y_dag <- 0.30 * ev$E1 + 0.25 * ev$E2 + 0.15 * ev$E3 +
    0.15 * ev$E4 + 0.15 * ev$E5 - 2.5 * c_count + 4 * q_signal
  y_dag
}

ai_expert_panel <- function(y_dag, expert_sd = 3, expert_bias = c(-1, 0, 1),
                            seed = NULL, return_ratings = FALSE,
                            preserve_legacy_stream = TRUE) {
  if (!is.null(seed)) {
    set.seed(seed)
  }
  n <- length(y_dag)
  if (length(expert_bias) != 3L || any(!is.finite(expert_bias))) {
    stop("`expert_bias` must contain one fixed bias for each of three experts.",
         call. = FALSE)
  }
  # The pre-repair implementation sampled a unit-level common bias here.  Draw
  # and discard that vector so the already-frozen expert-noise stream is
  # preserved while the registered fixed expert biases are applied by column.
  if (isTRUE(preserve_legacy_stream)) {
    invisible(sample(expert_bias, n, replace = TRUE))
  }
  noise <- matrix(rnorm(3 * n, sd = expert_sd), ncol = 3)
  ratings <- sweep(noise, 1L, y_dag, "+")
  ratings <- sweep(ratings, 2L, expert_bias, "+")
  reference <- ai_clip(rowMeans(ratings))
  if (isTRUE(return_ratings)) {
    return(list(reference = reference, ratings = ratings,
                expert_bias = expert_bias))
  }
  reference
}

ai_simulate_reference_given_x <- function(x, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  x <- as.numeric(x)
  n <- length(x)
  eps <- rnorm(n)
  eta <- matrix(rnorm(5 * n, sd = 6), ncol = 5)
  theta <- ai_latent(x, eps)
  ev <- ai_evidence(theta, x, eta)
  lambda_c <- exp(-1.5 - 0.025 * (theta - 70) + 0.4 * x)
  c_count <- rpois(n, lambda_c)
  q_signal <- sample(c(-1, 0, 1), n, replace = TRUE,
                     prob = c(0.15, 0.70, 0.15))
  y_dag <- ai_reference(ev, c_count, q_signal)
  ai_expert_panel(y_dag, seed = if (is.null(seed)) NULL else seed + 1L)
}

generate_population <- function(n, seed, with_group = TRUE,
                                with_period = TRUE) {
  set.seed(seed)
  x <- runif(n, -1, 1)
  a <- rbinom(n, 1, 0.5)
  d <- rbinom(n, 1, 0.5)
  eps <- rnorm(n)
  eta <- matrix(rnorm(5 * n, sd = 6), ncol = 5)
  theta <- ai_latent(x, eps)
  ev <- ai_evidence(theta, x, eta)
  lambda_c <- exp(-1.5 - 0.025 * (theta - 70) + 0.4 * x)
  c_count <- rpois(n, lambda_c)
  q_signal <- sample(c(-1, 0, 1), n, replace = TRUE,
                     prob = c(0.15, 0.70, 0.15))
  y_dag <- ai_reference(ev, c_count, q_signal)
  y <- ai_expert_panel(y_dag, seed = seed + 1L)
  out <- data.frame(
    case_id = sprintf("CASE_%06d", seq_len(n)),
    X = x, A = a, D = d,
    E1 = ev$E1, E2 = ev$E2, E3 = ev$E3, E4 = ev$E4, E5 = ev$E5,
    C = c_count, Q = q_signal,
    Theta = theta, Y_dag = y_dag, Y = y
  )
  if (!with_group) out$A <- NULL
  if (!with_period) out$D <- NULL
  out
}

stratify_corpus <- function(pool, n, seed) {
  set.seed(seed)
  breaks <- quantile(pool$Y, probs = seq(0, 1, length.out = 11),
                     names = FALSE)
  decile <- findInterval(pool$Y, breaks, left.open = TRUE)
  decile <- pmin(decile, 10)
  per <- ceiling(n / 10)
  idx <- unlist(lapply(seq_len(10), function(k) {
    ids <- which(decile == k)
    if (length(ids) == 0) {
      return(integer(0))
    }
    sample(ids, min(per, length(ids)))
  }), use.names = FALSE)
  if (length(idx) < n) {
    extra <- sample(setdiff(seq_len(nrow(pool)), idx), n - length(idx))
    idx <- c(idx, extra)
  }
  pool[idx[seq_len(n)], , drop = FALSE]
}

generate_corpus <- function(n, seed) {
  pool <- generate_population(ceiling(n * 2.2), seed)
  stratify_corpus(pool, n, seed + 1000L)
}
