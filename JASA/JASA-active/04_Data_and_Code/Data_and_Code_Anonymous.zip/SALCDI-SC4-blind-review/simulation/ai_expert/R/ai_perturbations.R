# Controlled AI failure mechanisms AI0-AI10 (AI protocol section 29).

ai_perturb <- function(scores, corpus, code, x0 = 0, h = 0.3,
                       mu_s_x0 = NULL, q20 = NULL, q80 = NULL) {
  s <- scores
  switch(code,
    AI0 = s,
    AI1 = {
      m <- mean(s)
      m + 0.65 * (s - m)
    },
    AI2 = ai_clip(s + 7),
    AI3 = ai_clip(s + 8 * corpus$A),
    AI4 = {
      if (is.null(mu_s_x0)) stop("AI4 requires mu_s_x0.", call. = FALSE)
      local <- abs(corpus$X - x0) <= h
      s[local] <- 2 * mu_s_x0 - s[local]
      s
    },
    AI5 = {
      if (is.null(q20)) stop("AI5 requires conditional q20.", call. = FALSE)
      bad <- corpus$Y < q20
      s[bad] <- ai_clip(s[bad] + 12)
      s
    },
    AI6 = {
      if (is.null(q80)) stop("AI6 requires conditional q80.", call. = FALSE)
      top <- corpus$Y > q80
      m <- mean(s)
      s[top] <- m + 0.5 * (s[top] - m)
      s
    },
    AI7 = {
      drift <- corpus$D == 1
      s[drift] <- ai_clip(0.7 * s[drift] + 0.3 * 70 + 5)
      s
    },
    AI8 = {
      set.seed(20260812)
      b <- rbinom(length(s), 1, 0.05)
      s[b == 1] <- 100 - s[b == 1]
      s
    },
    AI9 = s,
    AI10 = {
      target <- abs(corpus$X - x0) <= h & corpus$A == 1
      s[target] <- ai_clip(s[target] + 10)
      s
    },
    stop("Unknown perturbation code `", code, "`.", call. = FALSE)
  )
}

ai_conditional_quantile_truth <- function(
    probs = c(0.2, 0.8), x_grid = seq(-1, 1, length.out = 101L),
    n_per_x = 20000L, seed = 20260811L, path = NULL) {
  probs <- as.numeric(probs)
  x_grid <- sort(unique(as.numeric(x_grid)))
  n_per_x <- as.integer(n_per_x)
  if (any(probs <= 0 | probs >= 1) || length(x_grid) < 2L ||
      n_per_x < 100L) {
    stop("Conditional-quantile truth requires interior probabilities, at ",
         "least two grid points, and at least 100 draws per grid point.",
         call. = FALSE)
  }
  x_mc <- rep(x_grid, each = n_per_x)
  y_mc <- ai_simulate_reference_given_x(x_mc, seed = seed)
  grid_id <- rep(seq_along(x_grid), each = n_per_x)
  quantiles <- vapply(seq_along(x_grid), function(j) {
    as.numeric(stats::quantile(y_mc[grid_id == j], probs = probs,
                               names = FALSE, type = 1))
  }, numeric(length(probs)))
  quantiles <- t(quantiles)
  colnames(quantiles) <- paste0("q", format(100 * probs, trim = TRUE))
  truth <- list(
    x_grid = x_grid, probs = probs, quantiles = quantiles,
    n_per_x = n_per_x, seed = seed,
    reference_version = ai_reference_version
  )
  if (!is.null(path)) {
    dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
    saveRDS(truth, path)
  }
  truth
}

ai_predict_conditional_quantiles <- function(truth, x) {
  if (!identical(truth$reference_version, ai_reference_version)) {
    stop("Conditional-quantile truth uses an obsolete expert-reference ",
         "mechanism.", call. = FALSE)
  }
  x <- as.numeric(x)
  out <- vapply(seq_len(ncol(truth$quantiles)), function(j) {
    stats::approx(truth$x_grid, truth$quantiles[, j], xout = x,
                  rule = 2, ties = "ordered")$y
  }, numeric(length(x)))
  colnames(out) <- colnames(truth$quantiles)
  out
}

ai_conditional_quantiles <- function(
    x, probs = c(0.2, 0.8), x_grid = seq(-1, 1, length.out = 101L),
    n_per_x = 20000L, seed = 20260811L, truth = NULL, path = NULL) {
  if (is.data.frame(x)) x <- x$X
  if (is.null(truth)) {
    if (!is.null(path) && file.exists(path)) {
      truth <- readRDS(path)
    } else {
      truth <- ai_conditional_quantile_truth(
        probs = probs, x_grid = x_grid, n_per_x = n_per_x,
        seed = seed, path = path
      )
    }
  }
  ai_predict_conditional_quantiles(truth, x)
}
