# SALCDI — JASA Theory & Methods research project

Working title: **Surrogate-Assisted Local Conditional Distribution Inference with Scarce Reference Outcomes**

Primary target: **Journal of the American Statistical Association — Theory and Methods**.

This repository is the single source of truth for the manuscript, supplement, R implementation, simulations, applications, reproducibility materials, and project governance. Research decisions are recorded rather than inferred from old drafts or chat history.

## Project principles

1. Statistical correctness precedes novelty claims.
2. Every central claim is linked to a proof, computation, literature source, or empirical result in `docs/CLAIM_LEDGER.md`.
3. Main-text claims remain stable unless a recorded decision changes them.
4. Computational work is written as reusable R functions first and analysis scripts second.
5. No table, figure, or reported number is edited manually after generation.
6. JASA reproducibility requirements are treated as design constraints from project day one.
7. Blinded and unblinded manuscripts share the same section files.
8. Writing is concise, declarative, specific, and free of boilerplate, translationese, defensive padding, and inflated novelty language.

## Start here

- `PROJECT_CHARTER.md` — scope, target journal, success criteria.
- `STATUS.md` — current state and next gate.
- `docs/JASA_REQUIREMENTS.md` — verified official requirements and items to re-check at submission.
- `docs/SUBMISSION_GATES.md` — project gates from theory to submission.
- `docs/THEORY_TRACKER.md` — theorem/proof status.
- `docs/CLAIM_LEDGER.md` — manuscript claim control.
- `docs/RISK_REGISTER.md` — research and submission risks.
- `docs/WRITING_STYLE.md` — JASA-oriented prose rules.
- `docs/CODE_STANDARD.md` — R implementation rules.
- `logs/REVISION_LOG.md` — manuscript change history.
- `docs/IMPLEMENTATION_REPAIR_STATUS.md` — current correspondence-repair gate
  and the invalid-for-claims status of pre-fix numerical results.
- `review/5_6_pro/REVIEW_HANDOFF.md` — evidence-first review instructions and
  the self-contained simulation/application result bundle for the next GPT-5.6
  Pro review.

## Reproducibility entry point

The final workflow entry point is `reproduce.R`, which delegates to the
dry-run-first canonical recomputation plan. The pre-fix `targets` graph is
retired because it treated derived CSV files as independent evidence sources.

R is not bundled with this scaffold. Run `scripts/00_setup.R` in a local R installation to create the project library and verify dependencies before executing the workflow.

## Reproducibility quickstart (for reviewers)

- All formal reproducibility materials are in [`reproducibility/`](reproducibility/README.md).
- `reproducibility/seed_registry.R` builds the 119-scenario seed registry.
- `reproducibility/result_registry.R` selects and hashes the only formal source
  objects accepted by the evidence pipeline.
- `reproducibility/build_manuscript_evidence.R` builds paired uncertainty,
  two main numeric tables, figure data, and three main evidence figures.
- `reproducibility/validate_frozen_results.R` validates 119 registered
  simulations, 115 AI downstream scenarios, six AI band objects, two
  application objects, and their SHA-256 registry.
- `reproducibility/capture_environment.R` captures the session and dependency snapshot.
- `reproducibility/machine_tables/` contains:
  - `table1_oracle_mechanism.csv`
  - `table2_feasible.csv`
  - `table3_scarcity.csv`
  - `table4_bands.csv`
  - `table5_epa_primary.csv`
  - `table6_vitaldb_primary.csv`
  - `table7_ai_primary.csv`
  - `table8_paired_uncertainty.csv`
  - `table9_simulation_headline.csv`
  - `table10_application_primary.csv`
  - `figure2_transfer_geometry.csv`
  - `figure2_vanishing_curvature.csv`
  - `figure_scarcity_scaling.csv`
  - `figure_band_diagnostics.csv`
  - `figure3_application_frontiers.csv`

Review command sequence:

```sh
Rscript reproducibility/run_correspondence_gate.R .
Rscript reproduce.R 4 all
```

The second command is a dry run. Formal execution and post-run validation are
documented in `docs/CANONICAL_RECOMPUTATION_PLAN.md`.

## File inventory

See `PROJECT_TREE.txt` for the current tracked-file inventory.
