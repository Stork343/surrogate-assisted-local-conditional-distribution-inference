#' Local adaptive conditional CDF estimate
#'
#' @param q Numeric vector or matrix of X-anchored augmentation values,
#'   with units in rows and thresholds in columns.
#' @param m Numeric vector or matrix of full-surrogate augmentation values
#'   with the same dimensions as `q`.
#' @param lambda Scalar borrowing coefficient in \eqn{[0, 1]}.
#' @param z Numeric vector or matrix of threshold indicators.
#' @param r Numeric 0/1 vector of reference-observation indicators.
#' @param pi Numeric vector of verification probabilities in \eqn{(0, 1]}.
#' @param weights Numeric local weights with one value per observation and
#'   nonzero sum.
#'
#' @return A numeric vector with one local conditional CDF estimate per
#'   threshold.
#' @export
salcdi_local_adaptive_cdf <- function(q, m, lambda, z, r, pi, weights) {
  a <- salcdi_adaptive_borrow(q, m, lambda) # nolint
  u <- salcdi_augmented_signal(z, r, pi, a) # nolint
  salcdi_local_cdf(u, weights) # nolint
}
