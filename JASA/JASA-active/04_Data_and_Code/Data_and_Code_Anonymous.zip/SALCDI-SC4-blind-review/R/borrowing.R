#' Oracle scalar borrowing coefficient
#'
#' @param g Numeric scalar corresponding to the local alignment term G.
#' @param h Numeric nonnegative scalar corresponding to the local movement term H.
#' @param tol Nonnegative tolerance used to treat H as zero.
#'
#' @return A scalar in [0, 1].
#' @export
salcdi_oracle_lambda <- function(g, h, tol = sqrt(.Machine$double.eps)) {
  if (length(g) != 1L || length(h) != 1L || !is.finite(g) || !is.finite(h)) {
    stop("`g` and `h` must be finite numeric scalars.", call. = FALSE)
  }
  if (h < -tol) {
    stop("`h` must be nonnegative.", call. = FALSE)
  }
  if (h <= tol) {
    return(0)
  }
  min(1, max(0, g / h))
}

#' Net integrated-variance gain from full surrogate borrowing
#'
#' @param g Numeric scalar G.
#' @param h Numeric scalar H.
#'
#' @return The quantity 2G - H. Positive values favor full borrowing.
#' @export
salcdi_full_borrow_gain <- function(g, h) {
  if (length(g) != 1L || length(h) != 1L || !is.finite(g) || !is.finite(h)) {
    stop("`g` and `h` must be finite numeric scalars.", call. = FALSE)
  }
  2 * g - h
}

#' Adaptive surrogate borrowing path
#'
#' @param q Numeric vector or matrix of X-anchored augmentation values.
#' @param m Numeric vector or matrix of full-surrogate augmentation values.
#' @param lambda Scalar borrowing coefficient in \eqn{[0, 1]}.
#'
#' @return The convex combination \eqn{q + \lambda(m - q)} with the same
#'   dimensions as the inputs.
#' @export
salcdi_adaptive_borrow <- function(q, m, lambda) {
  if (!is.numeric(lambda) || length(lambda) != 1L || is.na(lambda) ||
        lambda < 0 || lambda > 1) {
    stop("`lambda` must be a finite scalar in [0, 1].", call. = FALSE)
  }
  q_matrix <- is.matrix(q)
  m_matrix <- is.matrix(m)
  if (q_matrix || m_matrix) {
    q <- as.matrix(q)
    m <- as.matrix(m)
    if (!identical(dim(q), dim(m))) {
      stop("`q` and `m` must have the same dimensions.", call. = FALSE)
    }
  } else {
    q <- as.numeric(q)
    m <- as.numeric(m)
    if (length(q) != length(m)) {
      stop("`q` and `m` must have the same length.", call. = FALSE)
    }
  }
  if (any(!is.finite(q)) || any(!is.finite(m))) {
    stop("`q` and `m` must contain finite values.", call. = FALSE)
  }
  q + lambda * (m - q)
}
