#' Threshold indicator signals
#'
#' @param y Numeric vector of reference outcomes.
#' @param tau Numeric vector of thresholds.
#'
#' @return A numeric 0/1 matrix with units in rows and one column per
#'   threshold, containing \eqn{1(Y \le \tau)}.
#' @export
salcdi_threshold_signals <- function(y, tau) {
  y <- as.numeric(y)
  tau <- as.numeric(tau)
  if (length(y) == 0L || any(!is.finite(y))) {
    stop("`y` must contain finite numeric values.", call. = FALSE)
  }
  if (length(tau) == 0L || any(!is.finite(tau))) {
    stop("`tau` must contain finite numeric values.", call. = FALSE)
  }
  z <- 1 * (outer(y, tau, "<="))
  dimnames(z) <- list(NULL, as.character(tau))
  z
}
