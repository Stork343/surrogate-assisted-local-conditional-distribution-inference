#' Borrowing gain estimates
#'
#' @param d Numeric matrix with units in rows and thresholds in columns,
#'   containing the surrogate movement \eqn{D_y=\widehat m_y-\widehat q_y}.
#' @param zq Numeric matrix with the same dimensions as `d`, containing the
#'   centered threshold signals \eqn{I(Y\le y)-\widehat q_y}.
#' @param v Numeric vector of local borrow weights \eqn{v_{h,i}}.
#' @param r Numeric 0/1 vector of reference-observation indicators.
#' @param pi Numeric vector of verification probabilities in \eqn{(0, 1]}.
#'
#' @return A list with scalar `G_hat` and `H_hat` computed on the supplied
#'   sample.
#' @export
salcdi_gain_estimates <- function(d, zq, v, r, pi) {
  d <- as.matrix(d)
  zq <- as.matrix(zq)
  v <- as.numeric(v)
  r <- as.numeric(r)
  pi <- as.numeric(pi)
  n <- nrow(d)
  if (ncol(d) != ncol(zq)) {
    stop("`d` and `zq` must have the same number of thresholds.", call. = FALSE)
  }
  if (length(v) != n || length(r) != n || length(pi) != n) {
    stop("`v`, `r`, and `pi` must have one value per row of `d`.", call. = FALSE)
  }
  if (any(!is.finite(d)) || any(!is.finite(zq))) {
    stop("`d` and `zq` must contain finite values.", call. = FALSE)
  }
  if (any(!is.finite(v))) {
    stop("`v` must contain finite values.", call. = FALSE)
  }
  if (any(!(r %in% c(0, 1)))) {
    stop("`r` must contain only 0 and 1.", call. = FALSE)
  }
  if (any(!is.finite(pi)) || any(pi <= 0) || any(pi > 1)) {
    stop("`pi` must be finite and lie in (0, 1].", call. = FALSE)
  }
  h_hat <- mean(v * rowMeans(d^2))
  g_hat <- mean(v * (r / pi) * rowMeans(d * zq))
  list(G_hat = g_hat, H_hat = h_hat)
}

#' Estimated scalar borrowing coefficient
#'
#' @param g_hat Numeric scalar estimate of \eqn{G_h}.
#' @param h_hat Numeric scalar estimate of \eqn{H_h}.
#' @param floor Positive denominator floor for \eqn{\widehat H_h}.
#'
#' @return The projection of \eqn{\widehat G_h/\widehat H_h} onto
#'   \eqn{[0, 1]} with the specified denominator floor.
#' @export
salcdi_estimated_lambda <- function(g_hat, h_hat, floor = 1e-8) {
  if (length(floor) != 1L || !is.finite(floor) || floor <= 0) {
    stop("`floor` must be a positive finite scalar.", call. = FALSE)
  }
  if (length(g_hat) != 1L || length(h_hat) != 1L ||
        !is.finite(g_hat) || !is.finite(h_hat)) {
    stop("`g_hat` and `h_hat` must be finite numeric scalars.", call. = FALSE)
  }
  min(1, max(0, g_hat / max(h_hat, floor)))
}

#' Cross-validated shrinkage coefficient
#'
#' @param g_hat Numeric scalar estimate of \eqn{G_h}.
#' @param h_hat Numeric scalar estimate of \eqn{H_h}.
#' @param grid Numeric vector of candidate coefficients in \eqn{[0, 1]}.
#'
#' @return The grid value minimizing \eqn{\lambda^2\widehat H_h -
#'   2\lambda\widehat G_h}.
#' @export
salcdi_cv_shrinkage_lambda <- function(g_hat, h_hat,
                                       grid = seq(0, 1, by = 0.2)) {
  if (!is.numeric(grid) || length(grid) == 0L || any(!is.finite(grid)) ||
        any(grid < 0) || any(grid > 1)) {
    stop("`grid` must contain finite values in [0, 1].", call. = FALSE)
  }
  loss <- grid^2 * h_hat - 2 * grid * g_hat
  grid[which.min(loss)]
}
