#' Deterministic nested split plan
#'
#' @param n Number of observations.
#' @param seed Integer random seed.
#' @param proportions Length-three vector for nuisance, gain, and evaluation shares.
#'
#' @return Data frame with observation index and split label.
#' @export
salcdi_split_plan <- function(n, seed, proportions = c(0.5, 0.25, 0.25)) {
  if (length(n) != 1L || n < 3 || n != as.integer(n)) {
    stop("`n` must be an integer of at least 3.", call. = FALSE)
  }
  if (length(proportions) != 3L || any(proportions <= 0)) {
    stop("`proportions` must contain three positive values.", call. = FALSE)
  }
  proportions <- proportions / sum(proportions)
  set.seed(seed)
  ord <- sample.int(n)
  cuts <- cumsum(round(n * proportions[1:2]))
  cuts[1] <- min(max(cuts[1], 1L), n - 2L)
  cuts[2] <- min(max(cuts[2], cuts[1] + 1L), n - 1L)
  split <- character(n)
  split[ord[seq_len(cuts[1])]] <- "nuisance"
  split[ord[seq.int(cuts[1] + 1L, cuts[2])]] <- "gain"
  split[ord[seq.int(cuts[2] + 1L, n)]] <- "evaluation"
  data.frame(id = seq_len(n), split = split, stringsAsFactors = FALSE)
}
