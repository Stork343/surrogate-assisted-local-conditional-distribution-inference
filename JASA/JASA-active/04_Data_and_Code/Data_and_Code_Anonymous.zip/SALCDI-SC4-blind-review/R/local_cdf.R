#' Local kernel weights
#'
#' @param x Numeric vector or matrix of target-defining covariates.
#' @param x0 Numeric target point.
#' @param h Positive scalar bandwidth or vector matching the columns of `x`.
#' @param kernel Kernel family, either `"gaussian"` or `"epanechnikov"`.
#'
#' @return Nonnegative weights summing to one.
#' @export
salcdi_local_weights <- function(x, x0, h,
                                 kernel = c("gaussian", "epanechnikov")) {
  kernel <- match.arg(kernel)
  x <- as.matrix(x)
  x0 <- as.numeric(x0)
  if (ncol(x) != length(x0)) {
    stop("`x0` must match the number of columns in `x`.", call. = FALSE)
  }
  if (length(h) == 1L) {
    h <- rep(h, ncol(x))
  }
  if (length(h) != ncol(x) || any(!is.finite(h)) || any(h <= 0)) {
    stop("`h` must be positive and match the dimension of `x`.", call. = FALSE)
  }
  w <- .salcdi_kernel_values(x, x0, h, kernel)
  total <- sum(w)
  if (!is.finite(total) || total <= 0) {
    stop("Local weights are numerically degenerate.", call. = FALSE)
  }
  w / total
}

#' Local conditional CDF from augmented threshold signals
#'
#' @param u Numeric matrix with rows as units and columns as thresholds.
#' @param weights Nonnegative local weights that sum to one.
#'
#' @return Numeric vector with one local estimate per threshold.
#' @export
salcdi_local_cdf <- function(u, weights) {
  u <- as.matrix(u)
  weights <- as.numeric(weights)
  if (nrow(u) != length(weights)) {
    stop("`weights` must have one value per row of `u`.", call. = FALSE)
  }
  if (any(!is.finite(weights))) {
    stop("`weights` must be finite.", call. = FALSE)
  }
  sw <- sum(weights)
  if (!is.finite(sw) || abs(sw) <= sqrt(.Machine$double.eps)) {
    stop("`weights` must have a nonzero sum.", call. = FALSE)
  }
  drop(crossprod(weights / sw, u))
}

#' Local linear effective weights
#'
#' @param x Numeric vector or matrix of target-defining covariates.
#' @param x0 Numeric target point.
#' @param h Positive scalar bandwidth or vector matching the columns of `x`.
#' @param tol Tolerance for the local design matrix condition.
#'
#' @return Numeric effective weights of the local linear smoother at `x0`,
#'   normalized to sum to one. Weights may be negative.
#' @export
salcdi_local_linear_weights <- function(x, x0, h, tol = 1e-12) {
  x <- as.matrix(x)
  x0 <- as.numeric(x0)
  n <- nrow(x)
  p <- ncol(x)
  if (ncol(x) != length(x0)) {
    stop("`x0` must match the number of columns in `x`.", call. = FALSE)
  }
  if (length(h) == 1L) {
    h <- rep(h, p)
  }
  if (length(h) != p || any(!is.finite(h)) || any(h <= 0)) {
    stop("`h` must be positive and match the dimension of `x`.", call. = FALSE)
  }
  if (n < p + 1L) {
    stop("At least one more observation than covariates is required.",
         call. = FALSE)
  }
  z <- sweep(x, 2L, x0, "-")
  z <- sweep(z, 2L, h, "/")
  design <- cbind(1, z)
  kernel_weights <- exp(-0.5 * rowSums(z * z))
  gram <- crossprod(design, design * kernel_weights)
  if (!is.finite(rcond(gram)) || rcond(gram) < tol) {
    stop("Local linear design is numerically degenerate.", call. = FALSE)
  }
  rhs <- t(design * kernel_weights)
  weights <- drop((solve(gram) %*% rhs)[1L, ])
  if (any(!is.finite(weights))) {
    stop("Local linear weights are numerically unstable.", call. = FALSE)
  }
  weights / sum(weights)
}
