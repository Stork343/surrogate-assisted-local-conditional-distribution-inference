# Raw product-kernel values using the manuscript's unscaled convention
# K_h(X-x0) = K((X-x0)/h).
.salcdi_kernel_values <- function(x, x0, h,
                                  kernel = c("gaussian", "epanechnikov")) {
  kernel <- match.arg(kernel)
  x <- as.matrix(x)
  x0 <- as.numeric(x0)
  if (!nrow(x)) stop("`x` must contain at least one row.", call. = FALSE)
  if (ncol(x) != length(x0)) {
    stop("`x0` must match the number of columns in `x`.", call. = FALSE)
  }
  if (length(h) == 1L) h <- rep(as.numeric(h), ncol(x))
  h <- as.numeric(h)
  if (length(h) != ncol(x) || any(!is.finite(h)) || any(h <= 0)) {
    stop("`h` must be positive and match the dimension of `x`.", call. = FALSE)
  }
  z <- sweep(sweep(x, 2L, x0, "-"), 2L, h, "/")
  if (kernel == "gaussian") {
    return(exp(-0.5 * rowSums(z^2)))
  }
  component <- 0.75 * pmax(0, 1 - z^2) * (abs(z) <= 1)
  apply(component, 1L, prod)
}

#' Calibrate a bounded relative sampling intensity
#'
#' @param raw Positive unnormalized intensities.
#' @param lower,upper Bounds applied after multiplying `raw` by a common
#'   calibration constant.
#' @param target Required finite-sample mean after clipping.
#' @param tolerance Root-finding tolerance.
#'
#' @return Bounded intensities whose arithmetic mean equals `target` up to the
#'   requested tolerance.
#' @export
salcdi_calibrate_intensity <- function(raw, lower = 0.5, upper = 1.5,
                                       target = 1, tolerance = 1e-12) {
  raw <- as.numeric(raw)
  if (!length(raw) || any(!is.finite(raw)) || any(raw <= 0)) {
    stop("`raw` must contain positive finite values.", call. = FALSE)
  }
  if (!is.finite(lower) || !is.finite(upper) || lower < 0 ||
      upper <= lower || !is.finite(target) || target < lower ||
      target > upper) {
    stop("Bounds and target are incompatible.", call. = FALSE)
  }
  objective <- function(constant) {
    mean(pmin(pmax(constant * raw, lower), upper)) - target
  }
  if (abs(objective(0)) <= tolerance) return(rep(target, length(raw)))
  upper_constant <- 1 / min(raw)
  while (objective(upper_constant) < 0) upper_constant <- 2 * upper_constant
  constant <- stats::uniroot(
    objective, interval = c(0, upper_constant), tol = tolerance
  )$root
  calibrated <- pmin(pmax(constant * raw, lower), upper)
  residual <- target - mean(calibrated)
  if (abs(residual) > 10 * tolerance) {
    stop("Bounded-intensity calibration did not reach the target mean.",
         call. = FALSE)
  }
  calibrated
}

#' Gaussian log-squared-residual bias correction
#'
#' @return The constant `-(digamma(1/2) + log(2))` that converts the expected
#'   log of a squared standard-Gaussian residual back to log variance.
#' @export
salcdi_gaussian_log_square_correction <- function() {
  -(digamma(0.5) + log(2))
}

#' Manuscript-normalized local gain weights
#'
#' @param x Numeric vector or matrix of target-defining covariates from one
#'   gain fold.
#' @param x0 Numeric target point.
#' @param h Positive scalar bandwidth or vector matching the columns of `x`.
#' @param pi Verification probabilities for the same gain-fold observations.
#' @param kernel Kernel family.
#'
#' @return A list with `weights`, the fold kernel mean `mu_hat`, raw `kernel`
#'   values, and the bandwidth volume `h_volume`.
#' @export
salcdi_gain_weights <- function(x, x0, h, pi,
                                kernel = c("epanechnikov", "gaussian")) {
  kernel <- match.arg(kernel)
  x <- as.matrix(x)
  pi <- as.numeric(pi)
  if (length(pi) != nrow(x) || any(!is.finite(pi)) ||
      any(pi <= 0) || any(pi > 1)) {
    stop("`pi` must contain one value in (0, 1] per row of `x`.",
         call. = FALSE)
  }
  h_vector <- if (length(h) == 1L) rep(as.numeric(h), ncol(x)) else
    as.numeric(h)
  kernel_values <- .salcdi_kernel_values(x, x0, h_vector, kernel)
  mu_hat <- mean(kernel_values)
  if (!is.finite(mu_hat) || mu_hat <= sqrt(.Machine$double.eps)) {
    stop("The gain-fold kernel mean is numerically degenerate.",
         call. = FALSE)
  }
  h_volume <- prod(h_vector)
  weights <- h_volume * kernel_values^2 / mu_hat^2 * (1 / pi - 1)
  list(
    weights = weights,
    mu_hat = mu_hat,
    kernel = kernel_values,
    h_volume = h_volume
  )
}

#' Three-role rotation indices
#'
#' @param fold_id Vector assigning every observation to one of exactly three
#'   folds.
#' @param rotation Integer in `1:3` identifying the evaluation fold in that
#'   rotation.
#'
#' @return A list of disjoint `nuisance`, `gain`, and `evaluation` indices and
#'   their fold labels.
#' @export
salcdi_three_role_rotation <- function(fold_id, rotation) {
  if (anyNA(fold_id) || !length(fold_id)) {
    stop("`fold_id` must assign every observation to a fold.", call. = FALSE)
  }
  labels <- sort(unique(fold_id))
  if (length(labels) != 3L) {
    stop("Exactly three fold labels are required.", call. = FALSE)
  }
  if (length(rotation) != 1L || !rotation %in% 1:3) {
    stop("`rotation` must be one of 1, 2, or 3.", call. = FALSE)
  }
  evaluation_label <- labels[[rotation]]
  nuisance_label <- labels[[(rotation %% 3L) + 1L]]
  gain_label <- labels[[((rotation + 1L) %% 3L) + 1L]]
  list(
    nuisance = which(fold_id == nuisance_label),
    gain = which(fold_id == gain_label),
    evaluation = which(fold_id == evaluation_label),
    labels = c(
      nuisance = nuisance_label,
      gain = gain_label,
      evaluation = evaluation_label
    )
  )
}

#' Canonical fold-specific local process aggregation
#'
#' @param u_list Named list of augmented-signal matrices. Each matrix has one
#'   row per observation and one column per threshold; row `i` must contain the
#'   pseudo-outcome constructed for the rotation in which `i` is evaluated.
#' @param x Numeric vector or matrix of target-defining covariates.
#' @param fold_id Three-fold assignment. Every observation is evaluated once in
#'   its own fold.
#' @param x0 Numeric target point.
#' @param h Positive scalar bandwidth or vector matching `x`.
#' @param kernel Kernel family.
#'
#' @return A list containing combined raw processes `F`, fold objects, and
#'   observation-level fold-specific influence matrices.
#' @export
salcdi_crossfit_local_process <- function(
    u_list, x, fold_id, x0, h,
    kernel = c("epanechnikov", "gaussian")) {
  kernel <- match.arg(kernel)
  if (!is.list(u_list) || !length(u_list) || is.null(names(u_list)) ||
      any(!nzchar(names(u_list)))) {
    stop("`u_list` must be a nonempty named list.", call. = FALSE)
  }
  x <- as.matrix(x)
  n <- nrow(x)
  if (length(fold_id) != n || anyNA(fold_id)) {
    stop("`fold_id` must have one nonmissing value per row of `x`.",
         call. = FALSE)
  }
  labels <- sort(unique(fold_id))
  if (length(labels) != 3L) {
    stop("Exactly three evaluation folds are required.", call. = FALSE)
  }
  matrices <- lapply(u_list, as.matrix)
  threshold_count <- unique(vapply(matrices, ncol, integer(1L)))
  if (length(threshold_count) != 1L ||
      any(vapply(matrices, nrow, integer(1L)) != n) ||
      any(!vapply(matrices, function(z) all(is.finite(z)), logical(1L)))) {
    stop("All augmented-signal matrices must be finite and have common dimensions.",
         call. = FALSE)
  }

  influence <- lapply(matrices, function(z) {
    matrix(NA_real_, nrow = n, ncol = ncol(z))
  })
  names(influence) <- names(matrices)
  fold_objects <- vector("list", length(labels))

  for (position in seq_along(labels)) {
    label <- labels[[position]]
    eval_idx <- which(fold_id == label)
    kernel_values <- .salcdi_kernel_values(
      x[eval_idx, , drop = FALSE], x0, h, kernel
    )
    mu_hat <- mean(kernel_values)
    if (!is.finite(mu_hat) || mu_hat <= sqrt(.Machine$double.eps)) {
      stop("An evaluation-fold kernel mean is numerically degenerate.",
           call. = FALSE)
    }
    fold_F <- lapply(matrices, function(z) {
      drop(crossprod(kernel_values, z[eval_idx, , drop = FALSE])) /
        sum(kernel_values)
    })
    for (method in names(matrices)) {
      centered <- sweep(
        matrices[[method]][eval_idx, , drop = FALSE],
        2L, fold_F[[method]], "-"
      )
      influence[[method]][eval_idx, ] <-
        centered * (kernel_values / mu_hat)
    }
    fold_objects[[position]] <- list(
      fold_label = label,
      eval_idx = eval_idx,
      rho = length(eval_idx) / n,
      kernel = kernel_values,
      mu_hat = mu_hat,
      F = fold_F
    )
  }

  combined <- lapply(names(matrices), function(method) {
    Reduce(
      `+`,
      lapply(fold_objects, function(fold) fold$rho * fold$F[[method]])
    )
  })
  names(combined) <- names(matrices)
  list(
    F = combined,
    folds = fold_objects,
    influence = influence,
    fold_id = fold_id,
    kernel = kernel
  )
}

#' CDF shape-correction stages
#'
#' @param f Numeric raw CDF grid.
#'
#' @return A list containing `raw`, `[0,1]`-clipped, and increasing-rearranged
#'   values.
#' @export
salcdi_shape_correct_cdf <- function(f) {
  f <- as.numeric(f)
  if (!length(f) || any(!is.finite(f))) {
    stop("`f` must contain finite numeric values.", call. = FALSE)
  }
  clipped <- pmin(pmax(f, 0), 1)
  list(raw = f, clipped = clipped, rearranged = sort(clipped))
}

#' Multiplier band from fold-specific influence contributions
#'
#' @param influence Numeric matrix with one row per observation and one column
#'   per threshold, as returned by `salcdi_crossfit_local_process()`.
#' @param center Combined raw CDF process aligned with the columns of
#'   `influence`.
#' @param p Overall reference fraction.
#' @param h Bandwidth scalar or vector.
#' @param dimension Localization dimension when `h` is scalar.
#' @param n_boot Number of Rademacher multiplier draws.
#' @param level Confidence level.
#' @param seed Integer seed.
#' @param cluster Optional cluster identifier. A common multiplier is applied
#'   to the sum of influence contributions within each cluster.
#'
#' @return Raw and rearranged band endpoints, the multiplier critical value,
#'   stochastic normalization, and the resampling metadata needed to reproduce
#'   the band exactly.
#' @export
salcdi_multiplier_band <- function(
    influence, center, p, h, dimension = 1L, n_boot = 999L,
    level = 0.95, seed = 1L, cluster = NULL) {
  influence <- as.matrix(influence)
  center <- as.numeric(center)
  n <- nrow(influence)
  if (!n || ncol(influence) != length(center) ||
      any(!is.finite(influence)) || any(!is.finite(center))) {
    stop("`influence` and `center` must be finite and threshold-aligned.",
         call. = FALSE)
  }
  if (length(p) != 1L || !is.finite(p) || p <= 0 || p > 1) {
    stop("`p` must be a scalar in (0, 1].", call. = FALSE)
  }
  if (length(dimension) != 1L || dimension < 1L ||
      dimension != as.integer(dimension)) {
    stop("`dimension` must be a positive integer.", call. = FALSE)
  }
  h <- as.numeric(h)
  if (!length(h) || any(!is.finite(h)) || any(h <= 0)) {
    stop("`h` must contain positive finite values.", call. = FALSE)
  }
  h_volume <- if (length(h) == 1L) h^as.integer(dimension) else prod(h)
  if (length(n_boot) != 1L || n_boot < 1L || n_boot != as.integer(n_boot) ||
      length(level) != 1L || !is.finite(level) || level <= 0 || level >= 1) {
    stop("Invalid multiplier count or confidence level.", call. = FALSE)
  }
  if (is.null(cluster)) {
    contributions <- influence
  } else {
    if (length(cluster) != n || anyNA(cluster)) {
      stop("`cluster` must have one nonmissing value per observation.",
           call. = FALSE)
    }
    contributions <- rowsum(influence, group = as.character(cluster),
                            reorder = FALSE)
  }

  set.seed(as.integer(seed), kind = "L'Ecuyer-CMRG")
  xi <- matrix(
    sample(c(-1, 1), n_boot * nrow(contributions), replace = TRUE),
    nrow = n_boot, ncol = nrow(contributions)
  )
  scale <- sqrt(p * h_volume / n)
  process <- scale * (xi %*% contributions)
  supremum <- apply(process, 1L, function(z) max(abs(z)))
  critical_value <- unname(stats::quantile(supremum, level, names = FALSE))
  half_width <- critical_value / sqrt(n * p * h_volume)
  low <- center - half_width
  high <- center + half_width
  list(
    center = center,
    band_low = low,
    band_high = high,
    band_low_rearranged = salcdi_monotone_cdf(low),
    band_high_rearranged = salcdi_monotone_cdf(high),
    critical_value = critical_value,
    half_width = half_width,
    process_scale = scale,
    n_boot = as.integer(n_boot),
    level = level,
    seed = as.integer(seed),
    construction = "unstudentized_raw_supremum"
  )
}
