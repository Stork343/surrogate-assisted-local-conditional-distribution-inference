#' Monotone local CDF correction
#'
#' @param f Numeric vector of local conditional CDF estimates evaluated at
#'   increasing thresholds.
#'
#' @return The increasing rearrangement of the `[0,1]`-clipped values on the
#'   same threshold grid.
#' @export
salcdi_monotone_cdf <- function(f) {
  salcdi_shape_correct_cdf(f)$rearranged
}

#' Isotonic CDF sensitivity correction
#'
#' @param f Numeric vector of CDF-grid values.
#'
#' @return A clipped least-squares isotonic regression. This is a sensitivity
#'   method and is not the manuscript's increasing rearrangement.
#' @export
salcdi_isotonic_cdf <- function(f) {
  f <- as.numeric(f)
  if (!length(f) || any(!is.finite(f))) {
    stop("`f` must contain finite numeric values.", call. = FALSE)
  }
  clipped <- pmin(pmax(f, 0), 1)
  if (length(clipped) == 1L) return(clipped)
  stats::isoreg(seq_along(clipped), clipped)$yf
}

#' Local conditional quantile by CDF inversion
#'
#' @param f Numeric nondecreasing vector of local conditional CDF estimates.
#' @param tau Numeric strictly increasing vector of thresholds aligned with
#'   `f`.
#' @param probs Numeric vector of probabilities in \eqn{[0, 1]}.
#'
#' @return A numeric vector containing the first threshold at which the CDF
#'   attains each requested probability, with endpoint clamping when the finite
#'   grid does not attain the probability.
#' @export
salcdi_local_quantile <- function(f, tau, probs) {
  f <- as.numeric(f)
  tau <- as.numeric(tau)
  probs <- as.numeric(probs)
  tol <- 1e-12
  if (length(f) != length(tau)) {
    stop("`f` and `tau` must have the same length.", call. = FALSE)
  }
  if (length(f) < 2L) {
    stop("At least two thresholds are required.", call. = FALSE)
  }
  if (any(!is.finite(f)) || any(!is.finite(tau))) {
    stop("`f` and `tau` must contain finite values.", call. = FALSE)
  }
  if (any(diff(tau) <= 0)) {
    stop("`tau` must be strictly increasing.", call. = FALSE)
  }
  if (any(diff(f) < -tol)) {
    stop("`f` must be nondecreasing; use `salcdi_monotone_cdf` first.",
         call. = FALSE)
  }
  if (any(!is.finite(probs)) || any(probs < 0) || any(probs > 1)) {
    stop("`probs` must be finite and lie in [0, 1].", call. = FALSE)
  }
  vapply(probs, function(p) {
    attained <- which(f >= p - tol)
    if (length(attained)) tau[[attained[[1L]]]] else tau[[length(tau)]]
  }, numeric(1L))
}

#' Interpolated conditional quantile sensitivity summary
#'
#' @inheritParams salcdi_local_quantile
#'
#' @return A linearly interpolated inverse-CDF summary. This is not the strict
#'   left inverse used by the manuscript estimator.
#' @export
salcdi_interpolated_quantile <- function(f, tau, probs) {
  f <- as.numeric(f)
  tau <- as.numeric(tau)
  probs <- as.numeric(probs)
  tol <- 1e-12
  if (length(f) != length(tau) || length(f) < 2L ||
      any(!is.finite(f)) || any(!is.finite(tau)) || any(diff(tau) <= 0) ||
      any(diff(f) < -tol) || any(!is.finite(probs)) ||
      any(probs < 0) || any(probs > 1)) {
    stop("Invalid CDF grid or probabilities.", call. = FALSE)
  }
  out <- numeric(length(probs))
  for (k in seq_along(probs)) {
    p <- probs[[k]]
    if (p <= f[[1L]] + tol) {
      out[[k]] <- tau[[1L]]
    } else if (p >= f[[length(f)]] - tol) {
      out[[k]] <- tau[[length(tau)]]
    } else {
      j <- which(f >= p)[[1L]]
      if (f[[j]] - f[[j - 1L]] <= tol) {
        out[[k]] <- tau[[j - 1L]]
      } else {
        out[[k]] <- tau[[j - 1L]] + (p - f[[j - 1L]]) *
          (tau[[j]] - tau[[j - 1L]]) / (f[[j]] - f[[j - 1L]])
      }
    }
  }
  out
}
