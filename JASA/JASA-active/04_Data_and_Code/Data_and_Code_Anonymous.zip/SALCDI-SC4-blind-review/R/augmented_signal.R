#' Augmented threshold signal
#'
#' @param z Numeric vector or matrix of threshold indicators or bounded
#'   threshold outcomes, with units in rows and thresholds in columns.
#' @param r Numeric 0/1 vector indicating observed reference outcomes.
#' @param pi Numeric vector of verification probabilities in (0, 1].
#' @param a Numeric vector with one augmentation value per row of `z`, or a
#'   matrix with the same dimensions as `z`.
#'
#' @return A numeric vector when `z` is a vector, and a matrix with the same
#'   dimensions as `z` otherwise.
#' @export
salcdi_augmented_signal <- function(z, r, pi, a) {
  was_vector <- is.null(dim(z))
  z <- as.matrix(z)
  n <- nrow(z)
  r <- as.numeric(r)
  pi <- as.numeric(pi)
  if (any(!is.finite(z))) {
    stop("`z` must contain finite values.", call. = FALSE)
  }
  if (length(r) != n || length(pi) != n) {
    stop("`r` and `pi` must have one value per row of `z`.", call. = FALSE)
  }
  if (any(!is.finite(pi)) || any(pi <= 0) || any(pi > 1)) {
    stop("`pi` must be finite and lie in (0, 1].", call. = FALSE)
  }
  if (any(!(r %in% c(0, 1)))) {
    stop("`r` must contain only 0 and 1.", call. = FALSE)
  }
  a_matches <- (is.matrix(a) && identical(dim(a), dim(z))) || length(a) == n
  if (!a_matches || any(!is.finite(a))) {
    stop(
      "`a` must be finite and match `z` as a matrix or one value per row.",
      call. = FALSE
    )
  }
  u <- a + (r / pi) * (z - a)
  if (was_vector) drop(u) else u
}
