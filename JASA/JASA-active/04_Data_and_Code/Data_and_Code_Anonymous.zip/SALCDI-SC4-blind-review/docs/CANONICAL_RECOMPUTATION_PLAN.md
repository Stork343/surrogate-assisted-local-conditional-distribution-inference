# Canonical recomputation plan

The formal recomputation is complete. Every selected object has implementation
version `salcdi-canonical-p0d-v2`; `CANONICAL_RESULTS_READY` is active and
`PRE_FIX_RESULTS_ARCHIVED` identifies only the obsolete audit snapshot.

## Dry-run preflight

From `salcdi-jasa/`:

```sh
Rscript reproducibility/run_correspondence_gate.R .
Rscript reproducibility/run_canonical_recomputation.R . 4 all
```

The second command prints the ordered plan and never executes it.

## Formal execution

Formal execution overwrites exact pre-fix final filenames with versioned
canonical objects. The pre-fix audit remains recoverable at commit `ccab24d`
and in the external frozen store.

```sh
SALCDI_CONFIRM_FULL_RECOMPUTATION=YES \
Rscript reproducibility/run_canonical_recomputation.R . 4 all --execute
```

The stages can also be run separately by replacing `all` with `simulation`,
`application`, or `ai`. The AI stage reuses the 5,997 valid frozen DeepSeek
responses and does not call the API.

## Finalization after all stages

```sh
SALCDI_ALLOW_CANONICAL_FINALIZATION=1 \
Rscript reproducibility/validate_frozen_results.R .

SALCDI_ALLOW_CANONICAL_FINALIZATION=1 \
Rscript reproducibility/build_manuscript_evidence.R .
```

The generated machine tables have been reviewed. `claim_object_map.csv` and all
15 manuscript markers are `READY`; the H1--H8 audit is stored in
`reproducibility/machine_tables/hypothesis_audit.csv`.
