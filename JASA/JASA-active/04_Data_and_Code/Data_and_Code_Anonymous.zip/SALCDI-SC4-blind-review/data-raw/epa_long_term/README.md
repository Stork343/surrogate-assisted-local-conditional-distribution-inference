# EPA long-term air-sensor evaluation data

The primary public application uses the U.S. Environmental Protection
Agency Office of Research and Development dataset *Long term performance of
six air sensors across the United States*.

- Catalog: <https://catalog.data.gov/dataset/dataset-long-term-performance-of-six-air-sensors-across-the-united-states>
- Processed-data DOI: <https://doi.org/10.23719/1531918>
- Direct archive: <https://pasteur.epa.gov/uploads/10.23719/1531918/FigureProcessedData.zip>
- Peer-reviewed study: <https://doi.org/10.3390/s25041265>
- EPA license and disclaimer: <https://pasteur.epa.gov/license/sciencehub-license.html>
- Acquisition date: 2026-08-13
- Archive size: 33,294,005 bytes
- SHA-256: `da096a4953ed8878931fe791774b9ac057341e55e888cf603a265c235049d2f3`

`analysis/04_public_application.R` downloads the archive when absent, checks
the SHA-256 digest, and extracts the clean processed CSV. The archive and
extracted files are ignored by version control; the analysis does not
redistribute the source data.

## Analysis mapping

The main analysis selects the uncorrected PurpleAir branch
`Make_ID == "PAR"` and aggregates collocated hourly values to site-days over
the concurrent evaluation period, 2019-07-22 through 2021-01-01.

- (Y): daily mean `PM25_Ref`, the collocated reference-monitor PM2.5 value;
- (S): daily mean `PM25_sens`, the PurpleAir PM2.5 reading;
- (X): daily mean `RH_sens`, the humidity reported by the sensor;
- cluster: calendar week;
- (R): a reproducibly generated reference-retention indicator with known
  probability.

The original processed data contain paired sensor and reference readings.
The scarce-reference setting is therefore a designed review-budget
experiment, not a claim that reference measurements were naturally missing.
