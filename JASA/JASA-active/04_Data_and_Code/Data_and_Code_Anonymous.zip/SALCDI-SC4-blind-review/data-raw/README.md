# Raw data policy

Raw public data may be acquired here by scripted download/preparation during development, but do not commit confidential third-party data.

Every dataset must have:

- provenance;
- acquisition date/version;
- license/access conditions;
- immutable raw copy or scripted retrieval;
- cleaning script;
- data dictionary.

The current public application is documented in
`data-raw/epa_long_term/README.md`. Raw and extracted EPA files are obtained
from the official source by `analysis/04_public_application.R` and are not
tracked in the repository.
