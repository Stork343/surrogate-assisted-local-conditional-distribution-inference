simulation_root <- if (dir.exists("simulation")) "." else file.path("..", "..")
simulation_helpers_available <- file.exists(file.path(
  simulation_root, "simulation", "config", "simulation_constants.R"
))
if (simulation_helpers_available) {
  source(file.path(simulation_root, "simulation", "config",
                   "simulation_constants.R"), local = TRUE)
  source_simulation_environment(simulation_root)
}

test_that("scenario manifest fields are mapped without partial matching", {
  skip_if_not(simulation_helpers_available)
  scenarios <- read_scenario_manifest(simulation_root)
  expect_true(length(scenarios) > 0L)
  expect_true(all(vapply(scenarios, function(scenario) {
    identical(scenario[["verification"]], scenario[["verification_design"]]) &&
      identical(scenario[["error_dist"]], scenario[["error_distribution"]])
  }, logical(1L))))
})

test_that("multivariate localization targets serialize to one auditable row", {
  skip_if_not(simulation_helpers_available)
  metadata <- simulation_x0_metadata(c(-0.25, 0.5))
  expect_identical(metadata$x0, -0.25)
  expect_identical(metadata$x0_coordinates, "-0.25,0.5")
  expect_identical(metadata$x0_dimension, 2L)
  expect_error(simulation_x0_metadata(numeric()), "at least one")
})

test_that("bounded verification intensity is calibrated after clipping", {
  skip_if_not(simulation_helpers_available)
  set.seed(1)
  x <- matrix(runif(5000, -1, 1), ncol = 1L)
  s <- dgp_mu(x) + dgp_sigma(x) * rnorm(5000) + 0.8 * rnorm(5000)
  e <- verification_e0(x, s, 0.8, "R2")
  expect_equal(mean(e), 1, tolerance = 0.02)
  expect_true(all(e >= 0.5 & e <= 1.5))
})

test_that("scenario identifiers produce unique deterministic RNG streams", {
  skip_if_not(simulation_helpers_available)
  a1 <- make_seed_states("scenario-A", 3L)
  a2 <- make_seed_states("scenario-A", 3L)
  b <- make_seed_states("scenario-B", 3L)
  expect_identical(a1, a2)
  expect_false(identical(a1[[1L]], b[[1L]]))
  keys <- vapply(c(a1, b), paste, collapse = ",", character(1L))
  expect_false(anyDuplicated(keys) > 0L)
})

test_that("candidate path selection is identical for truth and estimation", {
  skip_if_not(simulation_helpers_available)
  q <- matrix(c(0.1, 0.3, 0.6, 0.2, 0.4, 0.7), nrow = 2L,
              byrow = TRUE)
  m <- q + 0.25
  x <- matrix(c(-0.1, 0.1), ncol = 1L)
  clipped_scenario <- list(m_scenario = "M4", m_est_clip = TRUE)
  raw_scenario <- list(m_scenario = "M4", m_est_clip = FALSE)
  clipped <- select_candidate_path(m, q, clipped_scenario, x, 0, 0.3,
                                   1:3, "gaussian")
  raw <- select_candidate_path(m, q, raw_scenario, x, 0, 0.3,
                               1:3, "gaussian")
  expect_identical(clipped$mode, "clipped")
  expect_identical(raw$mode, "raw")
  expect_equal(clipped$values, pmin(pmax(raw$values, 0), 1))
  expect_false(identical(clipped$path_signature, raw$path_signature))
})

test_that("M4 truth uses the selected clipped or raw path consistently", {
  skip_if_not(simulation_helpers_available)
  base <- list(
    scenario_id = "M4-test", module = "oracle_mechanism", M = 1000L,
    p = 0.1, x0 = 0, h = 0.3, tau_s = 0.8,
    verification = "R1", error_dist = "gaussian", discrete = FALSE,
    d = 1L, pi_mode = "known", m_scenario = "M4",
    candidate_scale = NULL, m_local_reversal = FALSE,
    m_tail_failure = FALSE
  )
  clipped <- base
  clipped$m_est_clip <- TRUE
  raw <- base
  raw$m_est_clip <- FALSE
  tau <- truth_thresholds(0, "gaussian")
  clipped_truth <- truth_g_h(clipped, tau, n_truth = 30000L,
                             chunk_size = 30000L)
  raw_truth <- truth_g_h(raw, tau, n_truth = 30000L,
                         chunk_size = 30000L)
  expect_false(isTRUE(all.equal(clipped_truth$H, raw_truth$H)))
  expect_equal(clipped_truth$transfer_signal,
               2 * clipped_truth$G - clipped_truth$H)
  expect_equal(raw_truth$transfer_signal, 2 * raw_truth$G - raw_truth$H)
})

test_that("local and tail failures transform gain and evaluation paths identically", {
  skip_if_not(simulation_helpers_available)
  q <- matrix(0.3, nrow = 4L, ncol = 5L)
  m <- matrix(0.6, nrow = 4L, ncol = 5L)
  x <- matrix(c(-0.6, -0.1, 0.1, 0.6), ncol = 1L)
  local_scenario <- list(m_local_reversal = TRUE, m_tail_failure = FALSE)
  tail_scenario <- list(m_local_reversal = FALSE, m_tail_failure = TRUE)
  local_first <- apply_candidate_path_stress(
    m, q, local_scenario, x, x0 = 0, h = 0.3,
    threshold_levels = seq(0.1, 0.9, length.out = 5L)
  )
  local_second <- apply_candidate_path_stress(
    m, q, local_scenario, x, x0 = 0, h = 0.3,
    threshold_levels = seq(0.1, 0.9, length.out = 5L)
  )
  expect_identical(local_first, local_second)
  expect_true(all(local_first[2:3, ] < q[2:3, ]))

  tail <- apply_candidate_path_stress(
    m, q, tail_scenario, x, x0 = 0, h = 0.3,
    threshold_levels = seq(0.1, 0.9, length.out = 5L)
  )
  expect_true(all(tail[, 1L] < q[, 1L]))
  expect_equal(tail[, 3:5], m[, 3:5])
})

test_that("domain-shift scenario uses independent training and evaluation samples", {
  skip_if_not(simulation_helpers_available)
  scenario <- list(
    M = 60L, tau_s = 0.8, train_tau_s = 1.2, x0 = 0, h = 0.3,
    verification = "R1", p = 0.2, error_dist = "gaussian",
    discrete = FALSE, d = 1L, pi_mode = "known"
  )
  samples <- make_domain_shift_samples(scenario)
  expect_equal(nrow(samples$evaluation$x), scenario$M)
  expect_equal(nrow(samples$training$x), scenario$M)
  expect_false(identical(samples$evaluation$x, samples$training$x))
  expect_false(identical(samples$evaluation$s, samples$training$s))
})

test_that("discrete truth is defined on the observed category scale", {
  skip_if_not(simulation_helpers_available)
  tau <- truth_thresholds(0, "gaussian", discrete = TRUE)
  expect_equal(tau, 1:10)
  q <- truth_q0_discrete_matrix(matrix(c(-0.5, 0, 0.5), ncol = 1L), tau)
  expect_equal(dim(q), c(3L, 10L))
  expect_true(all(apply(q, 1L, function(z) all(diff(z) >= 0))))
  expect_equal(q[, 10L], rep(1, 3), tolerance = 1e-14)
})

test_that("discrete q and m agree with direct latent Monte Carlo", {
  skip_if_not(simulation_helpers_available)
  set.seed(44)
  n <- 40000L
  x0 <- 0.2
  tau <- 1:10
  y_star <- dgp_mu(x0) + dgp_sigma(x0) * rnorm(n)
  y <- findInterval(y_star, simulation_discrete_cuts) + 1L
  empirical_q <- vapply(tau, function(j) mean(y <= j), numeric(1L))
  analytic_q <- drop(truth_q0_discrete_matrix(matrix(x0, ncol = 1L), tau))
  expect_equal(empirical_q, analytic_q, tolerance = 0.01)

  s0 <- 0.7
  sig2 <- dgp_sigma(x0)^2
  kappa <- sig2 / (sig2 + 0.8^2)
  conditional_mean <- dgp_mu(x0) + kappa * (s0 - dgp_mu(x0))
  conditional_sd <- sqrt(sig2 * (1 - kappa))
  latent <- rnorm(n, conditional_mean, conditional_sd)
  y_conditional <- findInterval(latent, simulation_discrete_cuts) + 1L
  empirical_m <- vapply(tau, function(j) mean(y_conditional <= j), numeric(1L))
  analytic_m <- drop(truth_m0_discrete_matrix(
    matrix(x0, ncol = 1L), s0, tau, tau_s = 0.8
  ))
  expect_equal(empirical_m, analytic_m, tolerance = 0.01)
})

test_that("Gaussian learner uses corrected log variance and valid prediction length", {
  skip_if_not(simulation_helpers_available)
  expect_equal(gaussian_log_square_correction(),
               -(digamma(0.5) + log(2)), tolerance = 1e-14)
  set.seed(7)
  n <- 80L
  x <- matrix(runif(n, -1, 1), ncol = 1L)
  y <- 1 + x[, 1L] + rnorm(n)
  r <- rep(1L, n)
  fit <- fit_gaussian_q(y, x, rep(0, n), r,
                        pi = rep(0.5, n), family = "misspecified")
  prediction <- fit$predict(c(-1, 0, 1), matrix(c(-0.5, 0, 0.5), ncol = 1L))
  expect_equal(dim(prediction), c(3L, 3L))
  expect_true(isTRUE(fit$uses_ipw))
})

test_that("fitted-path oracle is computed on independent truth data", {
  skip_if_not(simulation_helpers_available)
  set.seed(12)
  n <- 120L
  x <- matrix(runif(n, -1, 1), ncol = 1L)
  y <- dgp_mu(x) + dgp_sigma(x) * rnorm(n)
  s <- y + 0.8 * rnorm(n)
  r <- rbinom(n, 1, 0.5)
  q_fit <- fit_gaussian_q(y, x, s, r, pi = rep(0.5, n))
  m_fit <- fit_gaussian_m(y, x, s, r, pi = rep(0.5, n))
  scenario <- list(
    scenario_id = "oracle-test", M = n, tau_s = 0.8, x0 = 0, h = 0.3,
    verification = "R1", p = 0.5, error_dist = "gaussian",
    discrete = FALSE, d = 1L, pi_mode = "known",
    m_local_reversal = FALSE, m_tail_failure = FALSE
  )
  tau <- seq(-1, 1, length.out = 11L)
  oracle_data <- make_fitted_oracle_sample(scenario, n = 500L, seed = 99L)
  result <- fitted_path_oracle(
    q_fit, m_fit, scenario, tau, oracle_data = oracle_data
  )
  expect_true(all(is.finite(unlist(result[c("G", "H", "lambda")]))))
  expect_true(result$lambda >= 0 && result$lambda <= 1)
  expect_identical(result$source, "independent_truth_sample")
})
