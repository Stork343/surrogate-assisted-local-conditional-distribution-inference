test_that("threshold signals are binary indicators", {
  z <- salcdi_threshold_signals(y = c(1, 2, 3), tau = c(1.5, 2, 5))
  expect_equal(
    unname(z),
    matrix(c(1, 0, 0, 1, 1, 0, 1, 1, 1), nrow = 3)
  )
})

test_that("threshold signals validate inputs", {
  expect_error(salcdi_threshold_signals(y = c(1, NA), tau = c(0, 1)))
  expect_error(salcdi_threshold_signals(y = 1:3, tau = numeric()))
})
