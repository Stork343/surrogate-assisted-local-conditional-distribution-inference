helper_path <- file.path("analysis", "vitaldb_application_helpers.R")
if (!file.exists(helper_path)) {
  helper_path <- file.path("..", "..", "analysis", "vitaldb_application_helpers.R")
}
helpers_available <- file.exists(helper_path)
if (helpers_available) source(helper_path, local = TRUE)

test_that("VitalDB verification probabilities are calibrated", {
  skip_if_not(helpers_available, "repository-only application helpers are unavailable")
  data <- data.frame(s = c(85, 90, 95, 98, 100))
  random <- vitaldb_verification_probabilities(data, 0.1, "random")
  selective <- vitaldb_verification_probabilities(data, 0.1, "selective")
  expect_equal(random, rep(0.1, 5))
  expect_equal(mean(selective), 0.1, tolerance = 1e-10)
  expect_true(all(selective >= 0.05 - 1e-12 & selective <= 0.15 + 1e-12))
  expect_gt(selective[1], selective[5])
})

test_that("VitalDB masks are nested across budgets and target-independent", {
  skip_if_not(helpers_available, "repository-only application helpers are unavailable")
  data <- data.frame(s = seq(90, 100, length.out = 200))
  low <- draw_vitaldb_reference_mask(
    data, 0.1, "random", replicate = 7L, seed_base = 20260814L
  )
  high <- draw_vitaldb_reference_mask(
    data, 0.2, "random", replicate = 7L, seed_base = 20260814L
  )
  expect_equal(low$uniforms, high$uniforms)
  expect_true(all(low$r <= high$r))
  expect_equal(low$seed, high$seed)
  expect_true(vitaldb_masks_are_nested(
    data, c(0.05, 0.1, 0.2, 0.4), c("random", "selective"),
    replicates = 1:5, seed_base = 20260814L
  ))
})

test_that("VitalDB fold allocation is deterministic and balanced", {
  skip_if_not(helpers_available, "repository-only application helpers are unavailable")
  ids <- as.character(seq_len(101))
  first <- vitaldb_balanced_folds(ids)
  second <- vitaldb_balanced_folds(ids)
  expect_equal(first, second)
  expect_lte(max(table(first)) - min(table(first)), 1)
  expect_setequal(unique(first), 1:3)
})

test_that("VitalDB KNN CDF predictions are finite and monotone", {
  skip_if_not(helpers_available, "repository-only application helpers are unavailable")
  set.seed(11)
  n <- 120
  x <- stats::rnorm(n)
  s <- 96 + x + stats::rnorm(n)
  y <- pmin(100, pmax(70, round(s + stats::rnorm(n))))
  r <- stats::rbinom(n, 1, 0.5)
  pi <- rep(0.5, n)
  fit <- vitaldb_fit_knn_cdf(
    y, x, s, r, pi, seq_len(n), tau = 70:99,
    include_s = TRUE, k_candidates = c(15L, 30L), min_verified = 20L
  )
  prediction <- fit$predict(x[1:10], s[1:10])
  expect_equal(dim(prediction), c(10L, 30L))
  expect_true(all(is.finite(prediction)))
  expect_true(all(prediction > 0 & prediction < 1))
  expect_true(all(apply(prediction, 1L, function(z) all(diff(z) >= 0))))
})

test_that("VitalDB application uses the canonical fold process", {
  skip_if_not(helpers_available, "repository-only application helpers are unavailable")
  set.seed(20260817)
  n <- 300L
  elapsed <- runif(n, 10, 300)
  x <- log1p(elapsed)
  s <- pmin(100, pmax(70, round(94 + 0.3 * x + rnorm(n, sd = 2))))
  y <- pmin(100, pmax(70, round(s + rnorm(n, sd = 2))))
  data <- data.frame(
    subjectid = sprintf("S%04d", seq_len(n)),
    x = x, s = s, y = y,
    stringsAsFactors = FALSE
  )
  folds <- vitaldb_balanced_folds(data$subjectid, k = 3L)
  fit <- fit_one_vitaldb_mask(
    data, p = 0.5, design = "random", replicate = 1L,
    seed_base = 20260817L, target_minutes = c(30, 75), h = 0.8,
    tau = 70:99, folds = folds, k_candidates = c(15L, 30L),
    min_verified = 20L, return_u = TRUE
  )

  target <- fit$targets[[1L]]
  expect_length(target$fold_process, 3L)
  expect_true(all(vapply(target$influence, function(z) all(is.finite(z)),
                         logical(1L))))
  manual <- Reduce(
    `+`,
    lapply(target$fold_process, function(fold) {
      fold$rho * fold$F$Adaptive
    })
  )
  expect_equal(target$raw_estimates$Adaptive, manual, tolerance = 1e-14)
  expect_true(all(c("ise_raw", "ise_final", "sup_raw", "sup_final") %in%
                    names(fit$metrics)))
})

test_that("formal VitalDB entry point loads the implementation version", {
  root <- if (dir.exists("analysis")) "." else file.path("..", "..")
  script <- file.path(root, "analysis", "05_third_party_application.R")
  skip_if_not(file.exists(script))
  text <- paste(readLines(script, warn = FALSE), collapse = "\n")
  expect_match(
    text,
    'source\\(file.path\\(root, "simulation", "config", "simulation_constants.R"\\)\\)',
    perl = TRUE
  )
})
