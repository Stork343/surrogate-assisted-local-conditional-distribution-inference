test_that("gain estimates match direct means", {
  d <- matrix(c(0.1, 0.2, 0.3, 0.4), nrow = 2)
  zq <- matrix(c(0.5, -0.1, 0.7, 0.2), nrow = 2)
  v <- c(2, 3)
  r <- c(1, 0)
  pi <- c(0.5, 0.5)
  out <- salcdi_gain_estimates(d, zq, v, r, pi)
  expect_equal(out$H_hat, mean(v * rowMeans(d^2)))
  expect_equal(out$G_hat, mean(v * (r / pi) * rowMeans(d * zq)))
})

test_that("gain estimates respect the verification correction", {
  d <- matrix(1, nrow = 3, ncol = 2)
  zq <- matrix(0.5, nrow = 3, ncol = 2)
  v <- rep(1, 3)
  out <- salcdi_gain_estimates(d, zq, v, r = c(1, 0, 0), pi = c(0.5, 0.5, 0.5))
  expect_equal(out$G_hat, 1 / 3)
})

test_that("estimated lambda applies the denominator floor", {
  expect_equal(salcdi_estimated_lambda(1, 0, floor = 1e-8), 1)
  expect_equal(salcdi_estimated_lambda(-1, 1, floor = 1e-8), 0)
  expect_equal(salcdi_estimated_lambda(1, 2, floor = 1e-8), 0.5)
  expect_equal(salcdi_estimated_lambda(1, 1e-10, floor = 1e-8), 1)
})

test_that("cv shrinkage minimizes the quadratic gain loss", {
  grid <- seq(0, 1, by = 0.2)
  expect_equal(salcdi_cv_shrinkage_lambda(0.75, 1, grid), 0.8)
  expect_error(salcdi_cv_shrinkage_lambda(1, 1, grid = c(-0.1, 0.5)))
})
