test_that("oracle lambda respects boundaries", {
  expect_equal(salcdi_oracle_lambda(-1, 2), 0)
  expect_equal(salcdi_oracle_lambda(1, 2), 0.5)
  expect_equal(salcdi_oracle_lambda(3, 2), 1)
  expect_equal(salcdi_oracle_lambda(1, 0), 0)
})

test_that("full-borrowing gain equals 2G-H", {
  expect_equal(salcdi_full_borrow_gain(2, 3), 1)
  expect_lt(salcdi_full_borrow_gain(1, 3), 0)
})
