test_that("augmented signal returns augmentation when reference is absent", {
  z <- c(0, 1)
  r <- c(0, 0)
  pi <- c(0.2, 0.5)
  a <- c(0.3, 0.7)
  expect_equal(salcdi_augmented_signal(z, r, pi, a), a)
})

test_that("augmented signal applies inverse-probability correction", {
  expect_equal(
    salcdi_augmented_signal(z = 1, r = 1, pi = 0.5, a = 0.25),
    1.75
  )
})
