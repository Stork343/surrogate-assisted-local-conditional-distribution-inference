recompute_root <- if (dir.exists("reproducibility")) "." else file.path("..", "..")
recompute_file <- file.path(recompute_root, "reproducibility",
                            "run_canonical_recomputation.R")
recompute_available <- file.exists(recompute_file)
if (recompute_available) source(recompute_file, local = TRUE)

test_that("formal recomputation plan is complete and contains no API scoring", {
  skip_if_not(recompute_available)
  plan <- canonical_recomputation_commands(recompute_root, cores = 3L)
  counts <- table(plan$stage)
  expect_equal(as.integer(counts), c(6L, 2L, 10L))
  expect_equal(names(counts), c("ai", "application", "simulation"))
  expect_false(any(grepl("score_primary|api_smoke|behavior_batch", plan$script)))
  expect_true(any(grepl("09_salcdii_analysis", plan$script)))
  expect_true(any(grepl("04_public_application", plan$script)))
})
