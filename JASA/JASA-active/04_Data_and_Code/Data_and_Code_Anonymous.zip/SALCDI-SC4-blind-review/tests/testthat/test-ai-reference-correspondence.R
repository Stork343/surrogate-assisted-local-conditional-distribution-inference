ai_project_root <- if (dir.exists("simulation/ai_expert/R")) {
  "."
} else {
  file.path("..", "..")
}
ai_helper_dir <- file.path(ai_project_root, "simulation", "ai_expert", "R")
ai_helpers_available <- dir.exists(ai_helper_dir)

if (ai_helpers_available) {
  ai_test_env <- new.env(parent = globalenv())
  ai_helper_files <- c(
    "generate_population.R", "generate_dossier.R", "corpus_bundle.R",
    "reference_sampling.R", "ai_perturbations.R", "validate_ai_output.R",
    "deepseek_client.R"
  )
  invisible(lapply(file.path(ai_helper_dir, ai_helper_files), sys.source,
                   envir = ai_test_env))
}

test_that("expert-panel biases are fixed by expert and preserve the frozen noise stream", {
  skip_if_not(ai_helpers_available)
  n <- 8L
  y_dag <- seq(35, 70, length.out = n)
  seed <- 912L
  observed <- ai_test_env$ai_expert_panel(
    y_dag, expert_sd = 3, expert_bias = c(-1, 0, 1), seed = seed,
    return_ratings = TRUE
  )

  set.seed(seed)
  invisible(sample(c(-1, 0, 1), n, replace = TRUE))
  noise <- matrix(rnorm(3 * n, sd = 3), ncol = 3)
  expected_ratings <- sweep(noise, 1L, y_dag, "+")
  expected_ratings <- sweep(expected_ratings, 2L, c(-1, 0, 1), "+")

  expect_equal(observed$ratings, expected_ratings)
  expect_equal(observed$reference,
               ai_test_env$ai_clip(rowMeans(expected_ratings)))
})

test_that("AI review designs use the registered mean budget", {
  skip_if_not(ai_helpers_available)
  set.seed(21)
  corpus <- data.frame(
    X = runif(2000, -1, 1),
    S_AI = pmin(pmax(rnorm(2000, 70, 14), 0), 100)
  )
  confidence <- runif(nrow(corpus), 5, 95)
  for (p in c(0.025, 0.05, 0.1, 0.2, 0.4)) {
    for (design in paste0("V", 1:5)) {
      pi <- ai_test_env$ai_review_pi(corpus, design, p,
                                     confidence = confidence)
      expect_equal(mean(pi), p, tolerance = 1e-10,
                   info = paste("mean budget", design, p))
      expect_true(all(pi > 0 & pi < 1), info = paste(design, p))
      if (design %in% paste0("V", 1:4)) {
        expect_true(all(pi >= 0.5 * p & pi <= 1.5 * p),
                    info = paste(design, p))
      }
    }
  }

  p <- 0.2
  inside <- abs(corpus$X) <= 0.3
  pi_v5 <- ai_test_env$ai_review_pi(corpus, "V5", p,
                                    confidence = confidence)
  expect_equal(unique(pi_v5[inside]), 0.25 * p)
})

test_that("AI5 and AI6 thresholds are conditional on each observation's X", {
  skip_if_not(ai_helpers_available)
  x <- c(-0.8, 0, 0.8)
  q <- ai_test_env$ai_conditional_quantiles(
    x, probs = c(0.2, 0.8), x_grid = x, n_per_x = 6000L,
    seed = 20260811L
  )
  expect_equal(dim(q), c(length(x), 2L))
  expect_named(as.data.frame(q), c("q20", "q80"))
  expect_true(length(unique(round(q[, "q20"], 1))) > 1L)
  expect_true(length(unique(round(q[, "q80"], 1))) > 1L)
  expect_true(all(q[, "q20"] < q[, "q80"]))

  direct <- vapply(seq_along(x), function(j) {
    y <- ai_test_env$ai_simulate_reference_given_x(
      rep(x[j], 30000L), seed = 20260900L + j
    )
    as.numeric(stats::quantile(y, c(0.2, 0.8), type = 1))
  }, numeric(2L))
  expect_equal(unname(q), unname(t(direct)), tolerance = 1.2)
})

test_that("frozen dossier JSONL physically excludes protected truth", {
  skip_if_not(ai_helpers_available)
  corpus <- data.frame(
    case_id = "CASE_000001", X = 0.1, A = 1, D = 0,
    E1 = 70, E2 = 71, E3 = 72, E4 = 73, E5 = 74,
    C = 0, Q = 1, Theta = 75, Y_dag = 73, Y = 72
  )
  path <- tempfile(fileext = ".jsonl")
  ai_test_env$write_dossiers_jsonl(corpus, path, seed_base = 10L)
  entry <- jsonlite::fromJSON(readLines(path, warn = FALSE))
  expect_setequal(names(entry), c("case_id", "dossier"))
  expect_false(any(c("Theta", "Y_dag", "Y") %in% names(entry)))
})

test_that("canonical corpus bundle separates evidence and protected truth", {
  skip_if_not(ai_helpers_available)
  skip_if_not_installed("digest")
  corpus <- ai_test_env$generate_population(25L, seed = 330L)
  corpus_dir <- tempfile("ai-corpus-")
  ai_test_env$ai_write_corpus_bundle(corpus, corpus_dir, "T",
                                     dossier_seed_base = 91L)
  evidence <- ai_test_env$ai_load_corpus_bundle(
    corpus_dir, "T", include_truth = FALSE
  )
  complete <- ai_test_env$ai_load_corpus_bundle(corpus_dir, "T")
  expect_false(any(c("Theta", "Y_dag", "Y") %in% names(evidence)))
  expect_true(all(c("Theta", "Y_dag", "Y") %in% names(complete)))
  expect_equal(complete$Y, corpus$Y)
  expect_identical(attr(complete, "reference_version"),
                   ai_test_env$ai_reference_version)
})

test_that("invalid model JSON is retried identically and archived", {
  skip_if_not(ai_helpers_available)
  attempts <- 0L
  request_bodies <- character()
  valid <- jsonlite::toJSON(list(
    score = 82, confidence = 70, review_needed = FALSE, grade = "B"
  ), auto_unbox = TRUE)
  transport <- function(url, key, body, timeout_s) {
    attempts <<- attempts + 1L
    request_bodies <<- c(
      request_bodies,
      jsonlite::toJSON(body, auto_unbox = TRUE, null = "null")
    )
    content <- c("not-json", "{\"score\": 200}", valid)[attempts]
    list(
      body = list(
        choices = list(list(
          message = list(content = content), finish_reason = "stop"
        )),
        usage = list(prompt_tokens = 10L, completion_tokens = 8L)
      ),
      response_headers = list()
    )
  }
  cfg <- list(
    endpoint = "https://example.invalid", model_primary = "mock",
    temperature = 0, thinking = FALSE, max_tokens = 20L, stream = FALSE,
    response_format = "json_object", max_retries = 3L,
    retry_base_delay_s = 0, timeout_s = 1
  )
  failure_dir <- tempfile("ai-failures-")
  result <- ai_test_env$ai_call_deepseek(
    "system", "user", cfg, api_key = "test-key", transport = transport,
    sleep = function(seconds) invisible(NULL), failure_dir = failure_dir,
    request_hash = "fixed-request"
  )

  expect_identical(attempts, 3L)
  expect_length(unique(request_bodies), 1L)
  expect_identical(result$status, "ok")
  expect_identical(result$attempt, 3L)
  expect_equal(result$parsed$score, 82)
  archived <- list.files(failure_dir, pattern = "\\.json$", full.names = TRUE)
  expect_length(archived, 2L)
  archive_rows <- lapply(archived, jsonlite::fromJSON)
  expect_setequal(vapply(archive_rows, `[[`, character(1L), "failure_type"),
                  c("invalid JSON", "schema validation"))
})

test_that("permanent invalid JSON is flagged only after all attempts", {
  skip_if_not(ai_helpers_available)
  attempts <- 0L
  transport <- function(url, key, body, timeout_s) {
    attempts <<- attempts + 1L
    list(
      body = list(choices = list(list(
        message = list(content = "not-json"), finish_reason = "stop"
      ))),
      response_headers = list()
    )
  }
  cfg <- list(
    endpoint = "https://example.invalid", model_primary = "mock",
    temperature = 0, thinking = FALSE, max_tokens = 20L, stream = FALSE,
    response_format = "json_object", max_retries = 3L,
    retry_base_delay_s = 0, timeout_s = 1
  )
  failure_dir <- tempfile("ai-permanent-failure-")
  result <- ai_test_env$ai_call_deepseek(
    "system", "user", cfg, api_key = "test-key", transport = transport,
    sleep = function(seconds) invisible(NULL), failure_dir = failure_dir,
    request_hash = "permanent-failure"
  )
  expect_identical(attempts, 3L)
  expect_identical(result$status, "failed")
  expect_true(result$api_failure)
  expect_length(list.files(failure_dir, pattern = "\\.json$"), 3L)
})
