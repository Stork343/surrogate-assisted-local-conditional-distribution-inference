test_that("local linear weights sum to one", {
  set.seed(1)
  x <- rnorm(40)
  w <- salcdi_local_linear_weights(x, x0 = 0, h = 1)
  expect_equal(sum(w), 1)
})

test_that("local linear weights reproduce linear functions", {
  x <- seq(-2, 2, length.out = 40)
  x0 <- 0.3
  w <- salcdi_local_linear_weights(x, x0 = x0, h = 0.8)
  y <- 1 - 0.5 * x
  expect_equal(sum(w * y), 1 - 0.5 * x0, tolerance = 1e-10)
})

test_that("local linear weights support multivariate targets", {
  set.seed(2)
  x <- matrix(rnorm(100), ncol = 2)
  x0 <- c(0.2, -0.1)
  w <- salcdi_local_linear_weights(x, x0 = x0, h = c(1, 0.8))
  expect_equal(sum(w), 1)
  y <- 2 + x[, 1] - 3 * x[, 2]
  expect_equal(sum(w * y), 2 + x0[1] - 3 * x0[2], tolerance = 1e-8)
})

test_that("local linear weights reject degenerate designs", {
  expect_error(salcdi_local_linear_weights(rep(0, 5), x0 = 0, h = 1))
  expect_error(salcdi_local_linear_weights(1, x0 = 0, h = 1))
})

test_that("local CDF accepts signed local linear weights", {
  u <- matrix(c(0, 1, 1), nrow = 3)
  w <- salcdi_local_linear_weights(c(0, 1, 2), x0 = 0.5, h = 1)
  f <- salcdi_local_cdf(u, w)
  expect_length(f, 1)
  expect_true(is.finite(f))
})
