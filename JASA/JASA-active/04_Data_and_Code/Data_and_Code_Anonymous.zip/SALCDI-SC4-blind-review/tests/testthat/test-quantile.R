test_that("monotone correction preserves monotone input", {
  f <- c(0.1, 0.35, 0.9, 1)
  expect_equal(salcdi_monotone_cdf(f), f)
})

test_that("increasing rearrangement sorts clipped grid values", {
  f <- c(0.2, 0.1, 0.6)
  expect_equal(salcdi_monotone_cdf(f), c(0.1, 0.2, 0.6))
})

test_that("quantile inversion is exact on a linear CDF", {
  tau <- seq(0, 1, length.out = 21)
  expect_equal(
    salcdi_local_quantile(f = tau, tau = tau, probs = c(0.25, 0.5, 0.75)),
    c(0.25, 0.5, 0.75)
  )
})

test_that("quantile inversion is the strict left inverse", {
  tau <- c(0, 2, 5)
  f <- c(0, 0.5, 1)
  expect_equal(salcdi_local_quantile(f, tau, 0.75), 5)
})

test_that("quantile inversion uses the first threshold attaining probability", {
  tau <- c(-2, 0, 3)
  f <- c(0, 0.5, 1)
  expect_equal(salcdi_local_quantile(f, tau, c(0, 1, 0.2)), c(-2, 3, 0))
})

test_that("interpolated quantile remains available as a sensitivity summary", {
  tau <- c(0, 2, 5)
  f <- c(0, 0.5, 1)
  expect_equal(salcdi_interpolated_quantile(f, tau, 0.75), 3.5)
})

test_that("quantile inversion returns the left edge on flat regions", {
  tau <- c(0, 1, 2, 3)
  f <- c(0, 0.5, 0.5, 1)
  expect_equal(salcdi_local_quantile(f, tau, 0.5), 1)
})

test_that("quantile inversion validates inputs", {
  tau <- c(0, 1, 2)
  f <- c(0.1, 0.05, 0.9)
  expect_error(salcdi_local_quantile(f, tau, 0.5))
  expect_error(salcdi_local_quantile(c(0.1, 0.9), tau, 0.5))
  expect_error(salcdi_local_quantile(c(0.1, 0.5, 0.9), c(1, 0, 2), 0.5))
  expect_error(salcdi_local_quantile(c(0.1, 0.5, 0.9), tau, 1.5))
})
