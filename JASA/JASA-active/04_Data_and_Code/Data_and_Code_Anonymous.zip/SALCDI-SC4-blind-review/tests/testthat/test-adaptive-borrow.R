test_that("adaptive borrow interpolates between anchors", {
  q <- c(0.2, 0.4)
  m <- c(0.8, 0.6)
  expect_equal(salcdi_adaptive_borrow(q, m, 0), q)
  expect_equal(salcdi_adaptive_borrow(q, m, 1), m)
  expect_equal(salcdi_adaptive_borrow(q, m, 0.5), c(0.5, 0.5))
})

test_that("adaptive borrow supports threshold matrices", {
  q <- matrix(c(0.2, 0.3, 0.4, 0.5), nrow = 2)
  m <- q + 0.1
  out <- salcdi_adaptive_borrow(q, m, 0.5)
  expect_equal(out, q + 0.05)
})

test_that("adaptive borrow validates the coefficient", {
  q <- c(0.2, 0.4)
  m <- c(0.8, 0.6)
  expect_error(salcdi_adaptive_borrow(q, m, 1.1))
  expect_error(salcdi_adaptive_borrow(q, m, -0.1))
  expect_error(salcdi_adaptive_borrow(q, m, NA_real_))
  expect_error(salcdi_adaptive_borrow(q, m[1], 0.5))
})
