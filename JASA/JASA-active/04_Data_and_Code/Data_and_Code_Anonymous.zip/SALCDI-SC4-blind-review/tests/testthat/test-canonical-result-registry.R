registry_root <- if (dir.exists("reproducibility")) "." else file.path("..", "..")
registry_file <- file.path(registry_root, "reproducibility", "result_registry.R")
registry_selector <- file.path(registry_root, "simulation", "summarize",
                               "result_selector.R")
registry_available <- file.exists(registry_file) && file.exists(registry_selector)
if (registry_available) {
  source(registry_selector, local = TRUE)
  source(registry_file, local = TRUE)
}

make_registry_frame <- function(id, n, version) {
  data.frame(
    implementation_version = version, scenario_id = id,
    replicate = seq_len(n), seed = paste0("seed-", seq_len(n))
  )
}

test_that("unified registry selects only versioned formal source objects", {
  skip_if_not(registry_available)
  skip_if_not_installed("digest")
  root <- tempfile("registry-")
  dirs <- c(
    "simulation/config", "simulation/output", "simulation/summarize",
    "simulation/ai_expert/config", "simulation/ai_expert/results/raw",
    "analysis/output/public_application", "analysis/output/vitaldb_application"
  )
  invisible(lapply(file.path(root, dirs), dir.create, recursive = TRUE))
  file.copy(registry_selector,
            file.path(root, "simulation/summarize/result_selector.R"))
  version <- "salcdi-canonical-p0d-v1"
  writeLines(paste0("simulation_implementation_version <- \"", version, "\""),
             file.path(root, "simulation/config/simulation_constants.R"))
  write.csv(data.frame(
    scenario_id = "S1", module = "feasible", level = "C_secondary"
  ), file.path(root, "simulation/config/scenario_manifest.csv"), row.names = FALSE)
  saveRDS(make_registry_frame("S1", 1000L, version),
          file.path(root, "simulation/output/S1_rep1000.rds"))
  write.csv(data.frame(
    scenario_id = c("A1", "B1"), block = c("A", "B")
  ), file.path(root, "simulation/ai_expert/config/ai_scenarios.csv"),
  row.names = FALSE)
  saveRDS(make_registry_frame("A1", 2000L, version),
          file.path(root, "simulation/ai_expert/results/raw/A1_mask2000.rds"))
  saveRDS(make_registry_frame("B1", 2000L, version),
          file.path(root, "simulation/ai_expert/results/raw/B1_mask2000.rds"))
  band_ids <- c(
    "AIBAND_V1_p0.10_raw", "AIBAND_V1_p0.05_raw",
    "AIBAND_V5_p0.10_raw", "AIBAND_V4_p0.10_raw",
    "AIBAND_V1_p0.10_AI4", "AIBAND_V1_p0.10_AI8"
  )
  for (id in band_ids) {
    saveRDS(
      make_registry_frame(id, 500L, version),
      file.path(
        root, "simulation/ai_expert/results/raw",
        paste0(id, "_bands500.rds")
      )
    )
  }
  application <- function(rows) list(
    implementation_version = version,
    metrics = data.frame(
      implementation_version = rep(version, rows),
      replicate = rep(seq_len(500L), length.out = rows)
    )
  )
  saveRDS(application(36000L), file.path(
    root, "analysis/output/public_application/epa_public_application.rds"
  ))
  saveRDS(application(48000L), file.path(
    root, "analysis/output/vitaldb_application/vitaldb_application.rds"
  ))

  registry <- build_canonical_result_registry(root)
  expect_equal(nrow(registry), 11L)
  expect_setequal(registry$artifact_id, c(
    "simulation:S1", "ai:A1", "ai:B1", "application:epa",
    "application:vitaldb", paste0("ai_band:", band_ids)
  ))
  expect_true(all(nchar(registry$sha256) == 64L))
  expect_true(all(!grepl("^/", registry$path)))
  expect_equal(
    registry_relative_path(
      file.path(normalizePath(root), "analysis", "output", "artifact.rds"),
      root
    ),
    "analysis/output/artifact.rds"
  )

  obsolete <- readRDS(file.path(
    root, "simulation/ai_expert/results/raw/A1_mask2000.rds"
  ))
  obsolete$implementation_version <- "pre-fix"
  saveRDS(obsolete, file.path(
    root, "simulation/ai_expert/results/raw/A1_mask2000.rds"
  ))
  expect_error(build_canonical_result_registry(root), "obsolete")
})
