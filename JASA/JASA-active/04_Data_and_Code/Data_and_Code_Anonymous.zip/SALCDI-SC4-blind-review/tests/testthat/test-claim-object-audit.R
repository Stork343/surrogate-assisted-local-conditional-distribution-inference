claim_root <- if (dir.exists("reproducibility")) "." else file.path("..", "..")
claim_audit_file <- file.path(claim_root, "reproducibility",
                              "audit_claim_object_map.R")
claim_audit_available <- file.exists(claim_audit_file)
if (claim_audit_available) source(claim_audit_file, local = TRUE)

test_that("every numerical claim has a unique ready manuscript marker", {
  skip_if_not(claim_audit_available)
  map <- audit_claim_object_map(claim_root)
  expect_equal(nrow(map), 15L)
  expect_false(anyDuplicated(map$claim_id) > 0L)
  expect_true(all(map$status == "READY"))
})
