test_that("split plan is deterministic and exhaustive", {
  a <- salcdi_split_plan(20, seed = 123)
  b <- salcdi_split_plan(20, seed = 123)
  expect_equal(a, b)
  expect_equal(sort(a$id), 1:20)
  expect_setequal(unique(a$split), c("nuisance", "gain", "evaluation"))
})
