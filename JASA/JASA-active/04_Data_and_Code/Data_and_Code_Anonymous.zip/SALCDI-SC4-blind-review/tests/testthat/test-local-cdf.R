test_that("local weights sum to one", {
  w <- salcdi_local_weights(c(-1, 0, 1), x0 = 0, h = 1)
  expect_equal(sum(w), 1)
  expect_true(all(w >= 0))
})

test_that("epanechnikov weights match the kernel formula", {
  x <- c(-0.5, 0, 0.5, 2)
  w <- salcdi_local_weights(x, x0 = 0, h = 1, kernel = "epanechnikov")
  raw <- 0.75 * (1 - x^2)
  raw[abs(x) > 1] <- 0
  expect_equal(w, raw / sum(raw))
})

test_that("epanechnikov weights are product kernels in two dimensions", {
  u <- c(-0.5, 0.2, 1.2)
  v <- c(-0.8, 0.5)
  x <- cbind(rep(u, each = 2), rep(v, times = 3))
  w <- salcdi_local_weights(x, x0 = c(0, 0), h = c(1, 1),
                            kernel = "epanechnikov")
  k1 <- 0.75 * (1 - x[, 1]^2) * (abs(x[, 1]) <= 1)
  k2 <- 0.75 * (1 - x[, 2]^2) * (abs(x[, 2]) <= 1)
  expect_equal(w, k1 * k2 / sum(k1 * k2))
})

test_that("local CDF is a weighted column mean", {
  u <- matrix(c(0, 1, 1, 1), nrow = 2, byrow = TRUE)
  f <- salcdi_local_cdf(u, c(0.25, 0.75))
  expect_equal(f, c(0.75, 1))
})
