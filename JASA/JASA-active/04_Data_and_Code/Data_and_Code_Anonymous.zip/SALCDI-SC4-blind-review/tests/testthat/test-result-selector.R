selector_path <- file.path("simulation", "summarize", "result_selector.R")
if (!file.exists(selector_path)) {
  selector_path <- file.path("..", "..", "simulation", "summarize",
                             "result_selector.R")
}
selector_available <- file.exists(selector_path)
if (selector_available) source(selector_path, local = TRUE)

test_that("canonical selector requires exactly one final object per scenario", {
  skip_if_not(selector_available)
  root <- tempfile("selector-")
  dir.create(file.path(root, "simulation", "config"), recursive = TRUE)
  dir.create(file.path(root, "simulation", "output"), recursive = TRUE)
  manifest <- data.frame(
    scenario_id = c("A", "B"),
    module = c("feasible", "bands"),
    level = c("C_secondary", "C_secondary"),
    stringsAsFactors = FALSE
  )
  write.csv(manifest, file.path(root, "simulation", "config",
                                "scenario_manifest.csv"), row.names = FALSE)
  writeLines(c(
    "simulation_implementation_version <- \"salcdi-canonical-p0d-v1\"",
    "simulation_boot_b <- 4999L"
  ), file.path(root, "simulation", "config", "simulation_constants.R"))
  saveRDS(data.frame(
    implementation_version = "salcdi-canonical-p0d-v1",
    scenario_id = "A", replicate = seq_len(1000L)
  ),
          file.path(root, "simulation", "output", "A_rep1000.rds"))
  saveRDS(data.frame(
    implementation_version = "smoke", scenario_id = "A", replicate = 1:200
  ),
          file.path(root, "simulation", "output", "A_rep200.rds"))
  saveRDS(data.frame(
    implementation_version = "salcdi-canonical-p0d-v1",
    scenario_id = "B", replicate = seq_len(1000L),
    band_result_version = "salcdi-band-repro-v1",
    multiplier_seed = seq_len(1000L), multiplier_draws = 4999L,
    band_construction = "unstudentized_raw_supremum",
    verified_support_min_fold = 10L
  ),
          file.path(root, "simulation", "output", "B_band_rep1000.rds"))

  selected <- select_final_result_files(root)
  expect_equal(basename(selected$level), "A_rep1000.rds")
  expect_equal(basename(selected$band), "B_band_rep1000.rds")

  file.copy(
    file.path(root, "simulation", "output", "A_rep1000.rds"),
    file.path(root, "simulation", "output", "A_copy_rep1000.rds")
  )
  selected_again <- select_final_result_files(root)
  expect_equal(basename(selected_again$level), "A_rep1000.rds")
  unlink(file.path(root, "simulation", "output", "A_rep1000.rds"))
  expect_error(select_final_result_files(root), "exactly one final")
})

test_that("canonical selector rejects obsolete objects with final filenames", {
  skip_if_not(selector_available)
  root <- tempfile("selector-version-")
  dir.create(file.path(root, "simulation", "config"), recursive = TRUE)
  dir.create(file.path(root, "simulation", "output"), recursive = TRUE)
  write.csv(data.frame(
    scenario_id = "A", module = "feasible", level = "C_secondary"
  ), file.path(root, "simulation", "config", "scenario_manifest.csv"),
  row.names = FALSE)
  writeLines(
    c(
      "simulation_implementation_version <- \"salcdi-canonical-p0d-v1\"",
      "simulation_boot_b <- 4999L"
    ),
    file.path(root, "simulation", "config", "simulation_constants.R")
  )
  saveRDS(data.frame(scenario_id = "A", replicate = seq_len(1000L)),
          file.path(root, "simulation", "output", "A_rep1000.rds"))
  expect_error(select_final_result_files(root), "provenance fields")
})

test_that("canonical simulation objects contain one row per replicate and method", {
  skip_if_not(selector_available)
  project_root <- if (dir.exists(file.path("simulation", "output"))) {
    "."
  } else {
    file.path("..", "..")
  }
  skip_if_not(dir.exists(file.path(project_root, "simulation", "output")))

  selected <- select_final_result_files(project_root, validate_objects = TRUE)
  for (index in seq_len(nrow(selected$registry))) {
    specification <- selected$registry[index, ]
    result <- readRDS(specification$path[[1L]])
    key <- paste(result$replicate, result$method, sep = "|")
    expect_false(
      anyDuplicated(key) > 0L,
      info = paste("duplicate replicate-method rows in", specification$scenario_id)
    )
    expect_true(
      all(table(result$method) == specification$replications),
      info = paste("incomplete method grid in", specification$scenario_id)
    )
    expect_equal(
      nrow(result),
      specification$replications * length(unique(result$method)),
      info = paste("unexpected row count in", specification$scenario_id)
    )
  }
})

test_that("Figure 2 borrowing ranges use one Adaptive value per replication", {
  skip_if_not(selector_available)
  project_root <- if (dir.exists(file.path("simulation", "output"))) {
    "."
  } else {
    file.path("..", "..")
  }
  machine_path <- file.path(
    project_root, "reproducibility", "machine_tables",
    "figure2_transfer_geometry.csv"
  )
  skip_if_not(file.exists(machine_path))
  skip_if_not(dir.exists(file.path(project_root, "simulation", "output")))

  selected <- select_final_result_files(project_root, validate_objects = TRUE)
  keep <-
    selected$registry$module == "oracle_mechanism" &
    grepl(
      "^M[1-8]_R[12](_unclip)?$",
      selected$registry$scenario_id
    )
  specifications <- selected$registry[
    keep, , drop = FALSE
  ]
  figure_data <- read.csv(machine_path, stringsAsFactors = FALSE)
  expect_equal(nrow(specifications), 18L)
  expect_equal(nrow(figure_data), 18L)

  for (index in seq_len(nrow(specifications))) {
    specification <- specifications[index, ]
    result <- readRDS(specification$path[[1L]])
    draws <- unique(result[
      result$method == "Adaptive",
      c("scenario_id", "replicate", "lambda_hat"),
      drop = FALSE
    ])
    observed <- figure_data[
      figure_data$scenario_id == specification$scenario_id,
      , drop = FALSE
    ]
    expect_equal(nrow(draws), specification$replications)
    expect_equal(nrow(observed), 1L)
    expect_lt(
      abs(observed$lambda_hat - mean(draws$lambda_hat)),
      1e-14
    )
    expect_equal(
      observed$lambda_q10,
      unname(quantile(draws$lambda_hat, 0.10, type = 7L)),
      tolerance = 1e-14
    )
    expect_equal(
      observed$lambda_q90,
      unname(quantile(draws$lambda_hat, 0.90, type = 7L)),
      tolerance = 1e-14
    )
    expect_equal(observed$lambda_replications, specification$replications)
  }
})
