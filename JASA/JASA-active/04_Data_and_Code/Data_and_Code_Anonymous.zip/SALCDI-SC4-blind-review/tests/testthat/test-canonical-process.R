test_that("three-role rotations are disjoint and cover evaluation once", {
  fold_id <- rep(1:3, each = 4)
  rotations <- lapply(1:3, function(k) {
    salcdi_three_role_rotation(fold_id, k)
  })

  for (roles in rotations) {
    expect_length(intersect(roles$nuisance, roles$gain), 0L)
    expect_length(intersect(roles$nuisance, roles$evaluation), 0L)
    expect_length(intersect(roles$gain, roles$evaluation), 0L)
    expect_setequal(
      c(roles$nuisance, roles$gain, roles$evaluation),
      seq_along(fold_id)
    )
  }
  expect_equal(sort(unlist(lapply(rotations, `[[`, "evaluation"))),
               seq_along(fold_id))
})

test_that("canonical process combines fold-specific local ratios", {
  x <- matrix(c(0, 0.9, 0, 0.9, 0.5, 0.5), ncol = 1L)
  fold_id <- rep(1:3, each = 2L)
  u <- matrix(c(0, 0, 1, 1, 0.3, 0.3), ncol = 1L)

  fit <- salcdi_crossfit_local_process(
    list(Adaptive = u), x = x, fold_id = fold_id,
    x0 = 0, h = 1, kernel = "epanechnikov"
  )

  manual_fold <- vapply(1:3, function(k) {
    idx <- which(fold_id == k)
    weights <- salcdi_local_weights(x[idx, , drop = FALSE], 0, 1,
                                    "epanechnikov")
    salcdi_local_cdf(u[idx, , drop = FALSE], weights)
  }, numeric(1L))
  manual <- mean(manual_fold)

  expect_equal(fit$F$Adaptive, manual, tolerance = 1e-14)
  expect_equal(vapply(fit$folds, `[[`, numeric(1L), "rho"), rep(1 / 3, 3))
  expect_equal(sort(unlist(lapply(fit$folds, `[[`, "eval_idx"))), 1:6)

  global <- salcdi_local_cdf(
    u, salcdi_local_weights(x, 0, 1, "epanechnikov")
  )
  expect_false(isTRUE(all.equal(fit$F$Adaptive, global)))
})

test_that("fold-specific influence uses its own denominator and center", {
  x <- matrix(c(0, 0.7, -0.2, 0.8, -0.5, 0.1), ncol = 1L)
  fold_id <- rep(1:3, each = 2L)
  u <- matrix(seq(0.1, 0.6, by = 0.1), ncol = 1L)

  fit <- salcdi_crossfit_local_process(
    list(Anchor = u), x = x, fold_id = fold_id,
    x0 = 0, h = 1, kernel = "epanechnikov"
  )

  for (fold in fit$folds) {
    idx <- fold$eval_idx
    expected <- fold$kernel / fold$mu_hat *
      (u[idx, 1L] - fold$F$Anchor[1L])
    expect_equal(fit$influence$Anchor[idx, 1L], expected,
                 tolerance = 1e-14)
  }
})

test_that("gain weights implement the manuscript normalization", {
  x <- matrix(c(-0.25, 0, 0.25), ncol = 1L)
  pi <- c(0.1, 0.2, 0.4)
  result <- salcdi_gain_weights(x, x0 = 0, h = 0.5, pi = pi)
  kernel <- 0.75 * (1 - (x[, 1L] / 0.5)^2)
  mu_hat <- mean(kernel)
  expected <- 0.5 * kernel^2 / mu_hat^2 * (1 / pi - 1)
  expect_equal(result$weights, expected, tolerance = 1e-14)
  expect_equal(result$mu_hat, mu_hat, tolerance = 1e-14)

  x2 <- rbind(c(-0.25, 0), c(0, 0), c(0.25, 0.25))
  result2 <- salcdi_gain_weights(x2, x0 = c(0, 0), h = 0.5, pi = pi)
  z <- x2 / 0.5
  kernel2 <- apply(0.75 * pmax(0, 1 - z^2) * (abs(z) <= 1), 1, prod)
  expected2 <- 0.5^2 * kernel2^2 / mean(kernel2)^2 * (1 / pi - 1)
  expect_equal(result2$weights, expected2, tolerance = 1e-14)
})

test_that("multiplier process uses supplied fold-specific influence", {
  influence <- matrix(
    c(-1, 0.5, 1, -0.5, -0.5, 1, 0.5, -1),
    nrow = 4L, byrow = TRUE
  )
  center <- c(0.3, 0.7)
  p <- 0.2
  h <- 0.5
  n_boot <- 25L
  seed <- 19L

  result <- salcdi_multiplier_band(
    influence, center, p = p, h = h, n_boot = n_boot,
    level = 0.8, seed = seed
  )

  set.seed(seed, kind = "L'Ecuyer-CMRG")
  xi <- matrix(sample(c(-1, 1), n_boot * nrow(influence), replace = TRUE),
               nrow = n_boot)
  process <- sqrt(p * h / nrow(influence)) * (xi %*% influence)
  manual_critical <- unname(quantile(
    apply(process, 1L, function(z) max(abs(z))), 0.8, names = FALSE
  ))
  expect_equal(result$critical_value, manual_critical, tolerance = 1e-14)
  expect_equal(
    result$half_width,
    manual_critical / sqrt(nrow(influence) * p * h),
    tolerance = 1e-14
  )
  expect_identical(result$seed, seed)
  expect_identical(result$n_boot, n_boot)
  expect_identical(result$construction, "unstudentized_raw_supremum")
})

test_that("cluster multiplier aggregates influence before drawing multipliers", {
  influence <- matrix(c(1, -1, 2, -2, -1, 1, -2, 2), nrow = 4L,
                      byrow = TRUE)
  cluster <- c("A", "A", "B", "B")
  individual <- salcdi_multiplier_band(
    influence, c(0.4, 0.6), p = 0.2, h = 0.5,
    n_boot = 20L, seed = 7L
  )
  clustered <- salcdi_multiplier_band(
    influence, c(0.4, 0.6), p = 0.2, h = 0.5,
    n_boot = 20L, seed = 7L, cluster = cluster
  )
  expect_false(isTRUE(all.equal(individual$critical_value,
                                clustered$critical_value)))
})
