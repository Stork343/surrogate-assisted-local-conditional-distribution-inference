helper_path <- file.path("analysis", "public_application_helpers.R")
if (!file.exists(helper_path)) {
  helper_path <- file.path("..", "..", "analysis", "public_application_helpers.R")
}
epa_helpers_available <- file.exists(helper_path)
if (epa_helpers_available) source(helper_path, local = TRUE)

test_that("EPA application uses the canonical fold process", {
  skip_if_not(epa_helpers_available,
              "repository-only application helpers are unavailable")
  set.seed(20260817)
  n <- 360L
  x <- runif(n, -1, 1)
  y <- 0.4 * x + rnorm(n, sd = 0.5)
  data <- data.frame(
    x = x,
    y = y,
    s = y + rnorm(n, sd = 0.35),
    week = rep(sprintf("W%03d", 1:90), each = 4L),
    Location = rep(c("A", "B", "C"), length.out = n),
    month = rep(c("M1", "M2", "M3", "M4"), length.out = n),
    stringsAsFactors = FALSE
  )
  tau <- seq(-1.5, 1.5, length.out = 21L)
  fit <- fit_one_epa_mask(
    data, tau, x0 = 0, h = 0.8, p = 0.5, design = "random",
    replicate = 1L, seed_base = 20260817L, return_u = TRUE
  )

  expect_length(fit$fold_process, 3L)
  expect_true(all(vapply(fit$influence, function(z) all(is.finite(z)),
                         logical(1L))))
  manual <- Reduce(
    `+`,
    lapply(fit$fold_process, function(fold) {
      fold$rho * fold$F$Adaptive
    })
  )
  expect_equal(fit$estimates$Adaptive, manual, tolerance = 1e-14)
  expect_true(all(c("ise_raw", "ise_final", "sup_raw", "sup_final") %in%
                    names(fit$metrics)))
})

test_that("EPA masks and folds are invariant to the caller's RNG kind", {
  skip_if_not(epa_helpers_available,
              "repository-only application helpers are unavailable")

  original_kind <- RNGkind()
  original_had_seed <- exists(
    ".Random.seed", envir = .GlobalEnv, inherits = FALSE
  )
  if (original_had_seed) {
    original_seed <- get(
      ".Random.seed", envir = .GlobalEnv, inherits = FALSE
    )
  }
  on.exit({
    do.call(RNGkind, as.list(original_kind))
    if (original_had_seed) {
      assign(".Random.seed", original_seed, envir = .GlobalEnv)
    } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
      rm(".Random.seed", envir = .GlobalEnv)
    }
  }, add = TRUE)

  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(20260817L)
  n <- 360L
  x <- runif(n, -1, 1)
  y <- 0.4 * x + rnorm(n, sd = 0.5)
  data <- data.frame(
    x = x, y = y, s = y + rnorm(n, sd = 0.35),
    week = rep(sprintf("W%03d", 1:90), each = 4L),
    Location = rep(c("A", "B", "C"), length.out = n),
    month = rep(c("M1", "M2", "M3", "M4"), length.out = n),
    stringsAsFactors = FALSE
  )
  tau <- seq(-1.5, 1.5, length.out = 21L)

  run_under_kind <- function(kind) {
    RNGkind(kind, "Inversion", "Rejection")
    set.seed(73021L)
    kind_before <- RNGkind()
    seed_before <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    fit <- fit_one_epa_mask(
      data, tau, x0 = 0, h = 0.8, p = 0.5, design = "random",
      replicate = 1L, seed_base = 20260817L, return_u = TRUE
    )
    expect_identical(RNGkind(), kind_before)
    expect_identical(
      get(".Random.seed", envir = .GlobalEnv, inherits = FALSE), seed_before
    )
    fit
  }

  fit_mersenne <- run_under_kind("Mersenne-Twister")
  fit_lecuyer <- run_under_kind("L'Ecuyer-CMRG")
  expect_identical(fit_mersenne$r, fit_lecuyer$r)
  expect_identical(fit_mersenne$fold_id, fit_lecuyer$fold_id)
  expect_equal(
    fit_mersenne$estimates$Adaptive,
    fit_lecuyer$estimates$Adaptive,
    tolerance = 0
  )
  expect_equal(fit_mersenne$lambda_hat, fit_lecuyer$lambda_hat, tolerance = 0)
})
